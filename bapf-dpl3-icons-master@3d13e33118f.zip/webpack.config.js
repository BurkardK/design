const path = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const webpack = require('webpack');
const { merge } = require('webpack-merge');
const SVGSpritemapPlugin = require('svg-spritemap-webpack-plugin');

// 'svgo-loader'
const commonConfig = {
    output: {
        path: path.resolve(__dirname, "public")
    },
    module: {
        rules: [
            /*            {
                            test: /\.svg$/,
                            loader: 'svg-sprite-loader',
                            options: {

                            }

                        },*/
            {
                test: /\.scss$/,
                use: [MiniCssExtractPlugin.loader, "css-loader", "sass-loader"]
            },
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: ["babel-loader"]
            }
        ]
    },
    plugins: [
        new MiniCssExtractPlugin(),
        new HtmlWebpackPlugin({
            template: path.resolve(__dirname, "src", "index.html")
        }),
        new SVGSpritemapPlugin('src/images/svg/*.svg',
            {
                styles: path.join(__dirname, 'src/scss/_sprites.scss')
            })
    ],
};

const productionConfig = {
    entry: {
        index: path.resolve(__dirname, "src", "js", "all-dev.js")
    },
};

const developmentConfig = {
    entry: {
        index: path.resolve(__dirname, "src", "js", "all-dev.js")
    },
    devtool:"source-map",
    target: "web",
    plugins: [ new webpack.HotModuleReplacementPlugin() ],
    optimization: {
        splitChunks: { chunks: "all" }
    },
    devServer: {
        port: 3333,
        static: {directory: path.join(__dirname, "public")},
        hot: true,
    }
};

module.exports = (env, args) => {
    switch(args.mode) {
        case 'development':
            return merge(commonConfig, developmentConfig);
        case 'production':
            return merge(commonConfig, productionConfig);
        default:
            throw new Error('No matching configuration was found!');
    }
}
