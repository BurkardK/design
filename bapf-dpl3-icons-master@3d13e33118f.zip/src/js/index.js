import '../scss/styles.scss';
import '@design/bapf-pattern-library/assets/js/core'
console.log('index js')
