import './index';
import './second';
console.log('all-dev');
