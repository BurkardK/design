/*!
 * @design/bapf-pattern-library v3.6.0 | 11.04.2024
 *
 */