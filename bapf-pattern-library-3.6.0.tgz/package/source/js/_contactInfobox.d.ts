/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _contactInfobox.js */
/**
 * Pattern: Kontaktinfobox
 * steuert Anzeige der Öffnungszeiten
 * @constructor
 * @param {HTMLElement} element - Kontaktinfobox Pattern, default: .ba-contact-infobox
 */
export class BaContactInfobox {
    constructor(element: any);
    domEl: any;
    /**
     * Anzeige der Öffnungszeiten initialisieren
     */
    init(): void;
    /**
     * Schaltet die Öffungszeiten für Screenreader ein/aus.
     * @param {NodeList} elems
     * @param {boolean} isOpen
     */
    setAriaHidden(elems: NodeList, isOpen: boolean): void;
    /**
     * Zeigt den Status des Heutigen Tages ('Geöffnet', 'Öffnet demnächst', 'Schließt demnächst', 'Geschlossen')
     * @param {Date} date 'der Jetzige Zeitpunkt'
     * @param {HTMLElement} todayTime das Heutige Zeitfeld aus der Öffnungszeiten Liste
     * @param openingTimeTable die Öffnungszeiten Liste
     */
    showOpenText(date: Date, todayTime: HTMLElement, openingTimeTable: any): void;
    /**
     * Prüft, ob aktuelles DateTime im Zeitraum 'geöffnet' liegt
     * @param {Date} date 'der Jetzige Zeitpunkt'
     * @param {Date} openTime 'Date mit der Öffnungszeit'
     * @param {Date} closingTime 'Date mit der Schließungszeit'
     * @return {Boolean}
     */
    isOpen(date: Date, openTime: Date, closingTime: Date): boolean;
    /**
     * Berechnet ob es 'demnächst Öffnet / Schließt' oder nicht
     * @param {Date} date 'der Jetzige Zeitpunkt'
     * @param {{closingMorningTime:Date,openingEveningTime:Date,closingEveningTime:Date,openMorningTime:Date}} openingTimeObject 'Date mit den Öffnungs- und Schließungszeiten'
     * @param {Boolean} open 'gibt an ob jetzt grade Offen ist'
     * @param {Boolean} hasEveningTime 'gibt an ob Heute auch am Nachmitag Öffnungszeiten existieren'
     * @return {Boolean}
     */
    timeframe(date: Date, openingTimeObject: {
        closingMorningTime: Date;
        openingEveningTime: Date;
        closingEveningTime: Date;
        openMorningTime: Date;
    }, open: boolean, hasEveningTime: boolean): boolean;
    /**
     * Befuellt den Heutigen Tag mit dem Status in allen Kontaktinfoboxen auf der Seite
     * @param todayTime das Heutige Zeitfeld aus der Öffnungszeiten Liste
     * @param {String} text 'ein String mit dem Text'
     * @param {String} status 'ein String mit dem Status'
     */
    fillStatus(todayTime: any, text: string, status: string): void;
}
