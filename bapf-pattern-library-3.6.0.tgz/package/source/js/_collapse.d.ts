/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _collapse.js */
/**
 * Pattern: collapsible / Ausklappbarer Inhaltsbereich
 * erweitert BS Collapse um A11y-Helfer
 * @constructor
 * @param {HTMLElement} element - Collapse Pattern, default: .ba-collapsible
 */
export class BaCollapse {
    constructor(element: any);
    domEl: any;
    /**
     * A11y-Helfer für Collapse initialisieren
     * Eventlistener erstellen (funktioniert auch für dynamische Elemente)
     */
    init(): void;
    /**
     * Aria-Label aktualisieren
     * ergänzt aria-label im jeweiligen Zustand (eingeklappt und ausgeklappt)
     * @param {HTMLElement} target - e.target auf Klick
     */
    updateAriaLabel(target: HTMLElement): void;
}
