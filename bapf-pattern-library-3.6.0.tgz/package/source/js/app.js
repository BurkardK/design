/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | app.js */
import '../sass/core.scss';
import {BaGlobals} from './_globals';

/**
 * Bootstrap, seitenübergreifende Scripte und Funktionen der DPL3 initialisieren
 */
BaGlobals.init();


