/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _utilities.js */
export class Utilities {

  /**
   * Berechnet die Breite des Elements über den Margin
   * @param {HTMLElement} el
   * @return {number} Breite über Margin
   */
  static outerWidth (el) {
    let width = el.offsetWidth;
    const style = getComputedStyle(el);

    width += parseInt(style.marginLeft) + parseInt(style.marginRight);
    return width;
  }

  /**
   * Überprüft ob das Element versteckt ist oder sich in einem versteckten Container befindet
   * @param {HTMLElement} el
   * @return {boolean}
   */
  static isHidden (el) {
    return !(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
  }

  /**
   * Erstellt ein DOM-Element, setzt optionale Attribute und Text
   * @param {string} nodeName example 'div'
   * @param {object | undefined} attrsList Beispiel: {'class': 'class1 class2', 'type': 'button'}
   * @param {string | undefined} text
   * @return {HTMLElement}
   */
  static createElem (nodeName, attrsList, text) {
    const node = document.createElement(nodeName);
    if (attrsList && attrsList.length > 0) {
      attrsList.forEach((elem) => {
        const attr = Object.keys(elem)[0];
        const val = elem[attr];
        node.setAttribute(attr.replace('__', '-'), val);
      });
    }

    if (text) {
      node.append(text);
    }
    return node;
  }

  /**
   * Gibt alle fokusierbaren Elemente zurück
   * @param {HTMLElement} element Root Element
   * @return {Array}
   */
  static getFocusableElements (element) {
    const arrFocusables = [];
    element.querySelectorAll('a[href], button, input:not([type=hidden]), textarea, select, details, [tabindex]:not([tabindex="-1"])').forEach((elem) => arrFocusables.push(elem));
    return arrFocusables.filter(el => !el.hasAttribute('disabled') && !el.getAttribute('aria-hidden'));
  }

  /**
   * Get first focusable element
   * Gibt das erste fokusierbare Element zurück
   * @param {HTMLElement} element Root Element
   * @return {HTMLElement}
   */
  static getFirstFocusable (element) {
    const focusables = this.getFocusableElements(element);
    return focusables.length ? focusables[0] : element;
  }

  /**
   * Gibt das BA Header DOM-Element aus der WebComponent ShadowDOM (hydriert oder nicht) oder aus dem statischen DOM zurück
   * @return {Promise<any>}
   */
  static async getHeader () {
    return new Promise(resolve => {

      // Suche nach dem Header als WebComponent
      const headerComponent = document.querySelector('bahf-header') || document.querySelector('bahf-header-v5') || null;
      if (headerComponent) {

        // Element ist bereits hydriert und als Header im ShadowDOM
        /* istanbul ignore next */
        if (headerComponent.classList.contains('hydrated')) {
          const shadowRoot = /** @type {ShadowRoot} */ (headerComponent.shadowRoot);
          const headerElem = /** @type {HTMLElement | null} */ (shadowRoot.querySelector('.ba-header') || null);
          resolve(headerElem);
        }

        // Das Element ist noch nicht hydriert, warte auf stencil init / hydration
        /* istanbul ignore next */
        try {
          const observer = new MutationObserver((mutations) => {
            mutations.forEach(mu => {
              const muTarget = /** @type {HTMLElement} */ (mu.target);
              if (muTarget.classList.contains('hydrated')) {
                observer.disconnect();
                const muTargetShadowRoot = /** @type {ShadowRoot} */ (muTarget.shadowRoot);
                const headerElem = /** @type {HTMLElement | null} */ (muTargetShadowRoot.querySelector('.ba-header') || null);
                resolve(headerElem);
              }
            });
          });
          observer.observe(headerComponent, {
            attributes     : true,
            attributeFilter: ['class'],
          });
        } catch (e) {
          console.log('MutationObserver nicht unterstützt, bitte Browser updaten.'); //NOSONAR
        }
      }

      // Suche nach dem Header als DOM-Element
      else {
        resolve(document.querySelector('.ba-header') || null);
      }
    });
  }

  /**
   * Gibt das initialisierte Pattern zurück
   * @param {HTMLElement} element Pattern-Element
   * @return {Promise<any>}
   */
  static async getInitializedPattern (element) {
    return new Promise((resolve) => {

      if (!element) {
        resolve(null);
        return;
      }

      // Element ist bereits initialisiert
      if (element && element.hasAttribute('data-initialized')) {
        resolve(element);
        return;
      }

      // Warte bis das Element initialisiert wurde (Pattern.init())
      try {
        const observer = new MutationObserver((mutations) => {
          mutations.forEach(mu => {
            const muTarget = /** @type {HTMLElement} */ (mu.target);
            if (muTarget.hasAttribute('data-initialized')) {
              observer.disconnect();
              resolve(mu.target);
            }
          });
        });
        observer.observe(element, {
          attributes     : true,
          attributeFilter: ['data-initialized'],
        });
      } catch (e) {
        /* istanbul ignore next */
        console.log('MutationObserver nicht unterstützt, bitte Browser updaten.', e); //NOSONAR
      }
    });
  }

  /**
   * Überprüfe ob der Browser passive Event Listener unterstützt
   * @returns {boolean}
   */
  static supportsPassiveEvent () {
    let supportsPassive = false;
    try {
      const opts = Object.defineProperty({}, 'passive', {
        get: function () {
          supportsPassive = true;
        }
      });
      window.addEventListener('testPassive', null, opts);
      window.removeEventListener('testPassive', null, opts);
    } catch (e) {}
    return supportsPassive;
  }

  /**
   * Füge eine Navigation über Pfeiltasten/Tab hinzu (beispielsweise für Toolbars)
   * @param {HTMLElement} container Toolbar Root-Element
   * @param {NodeListOf<HTMLElement>} items Toolbar Button-Elemente
   */
  static addArrowKeyNavigation (container, items) {
    let next = 0;

    // Schließe Einträge der Tab Navigation aus
    const updateTabIndex = () => {
      items.forEach((item, i) => {
        i === next ? item.removeAttribute('tabindex') : item.setAttribute('tabindex', '-1');
      });
    };
    updateTabIndex();

    // move cursor focus via arrow/home/end keys
    // Bewegt den Cursor Fokus via Pfeiltasten/Home/End
    container.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
        e.stopPropagation();
        e.preventDefault();
        next = next === 0 ? items.length - 1 : next - 1;
      } else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
        e.stopPropagation();
        e.preventDefault();
        next = next === items.length - 1 ? 0 : next + 1;
      } else if (e.key === 'Home') {
        e.stopPropagation();
        e.preventDefault();
        next = 0;
      } else if (e.key === 'End') {
        e.stopPropagation();
        e.preventDefault();
        next = items.length - 1;
      }
      items[next].focus({ preventScroll: true });
      updateTabIndex();
    });
  }

  /**
   * Überprüft ob ein Element innerhalb des sichtbaren Bereichs liegt
   * @param {HTMLElement} element
   * @return {boolean}
   */
  static isInViewport (element) {
    const elemPosition = element.getBoundingClientRect();
    const checkTopLeft = elemPosition.top >= 0 && elemPosition.left >= 0;
    const windowHeight = window.innerHeight || document.documentElement.clientHeight;
    const windowWidth = window.innerWidth || document.documentElement.clientWidth;
    return (checkTopLeft && elemPosition.bottom <= windowHeight && elemPosition.right <= windowWidth);
  }

  /**
   * Überprüft, ob aktueller Browser Safari ist (iOS, MacOS)
   * @returns {boolean}
   */
  static isSafari () {
    const userAgent = navigator.userAgent.toLowerCase();
    return !userAgent.includes('chrome') && userAgent.includes('safari');
  }
}
