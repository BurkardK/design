/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _dropdown.js */
/**
 * Pattern: Dropdown
 * erweitert Dropdown-Funktionalität
 * @constructor
 * @param {HTMLElement} element - Dropdown Pattern, default: .dropdown
 */
export class BaDropdown {
  constructor (element) {
    /* istanbul ignore next */
    if (element.hasAttribute('data-initialized')) return;

    this.domEl = element;
    this.initFocus();

    this.domEl.setAttribute('data-initialized', 'true');
  }

  /**
   * Fügt einen Event Handler hinzu, der den Fokus auf das aktive Element setzt
   */
  initFocus () {
    this.domEl.addEventListener('shown.bs.dropdown', () => {
      const listElem = this.domEl.querySelector('.dropdown-menu');
      // Setzt den Fokus auf den aktiven Eintrag
      let firstLink = listElem.querySelector('.active:not(.disabled) a');
      if (!firstLink) {
        // Setzt den Fokus auf den ersten, nicht ausgeschalteten Eintrag
        if (listElem.tagName === 'UL') {
          firstLink = listElem.querySelector('li:not(.disabled) a');
        } else {
          firstLink = listElem.querySelector('a:not(.disabled)');
        }
      }
      firstLink.focus({ preventScroll: true });
      // Bootstrap ignoriert Pfeil Hoch/Runter Events, wir müssen es mit keyup versuchen
      this.domEl.addEventListener('keyup', () => {
        document.body.classList.add('ba-keyboard-mode');
      });
    });
  }
}
