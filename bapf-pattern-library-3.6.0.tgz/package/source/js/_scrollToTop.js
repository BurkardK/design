/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _scrollToTop.js */
'use strict';

/**
 * Pattern: Scroll-To-Top Button
 * @constructor
 * @param {HTMLElement} element - Button
 */
export class BaScrollToTop {

  constructor (element) {
    /* istanbul ignore next */
    if (element.hasAttribute('data-initialized')) return;

    this.domEl = element;
    this.init();

    this.domEl.setAttribute('data-initialized', 'true');
  }

  /**
   * Initialisiert den Scroll-To-Top Button
   */
  init () {
    this.domEl.addEventListener('click', (e) => {
      e.preventDefault();
      window.scroll({top: 0, behavior: 'smooth'});
    });

    this.updateScrollBtn(this.domEl);

    window.addEventListener('resize', () => {
      this.updateScrollBtn(this.domEl);
    });
    window.addEventListener('scroll', () => {
      this.updateScrollBtn(this.domEl);
    });
  }

  /**
   * Versteckt oder zeigt scrollToTop Button abhängig von scroll Position
   * @param {HTMLElement} $scrollBtn Scroll-to-top button
   */
  updateScrollBtn ($scrollBtn) {
    const minScrollOffset = 200;
    window.scrollY >= minScrollOffset ? $scrollBtn.classList.add('visible') : $scrollBtn.classList.remove('visible');
  }
}
