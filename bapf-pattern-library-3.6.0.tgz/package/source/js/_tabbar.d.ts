/**
 * Pattern: Tabbar
 * Initialisiert Tabbar-Navigation
 * @constructor
 * @param {HTMLElement} element - TabBar Pattern, default: .ba-tabbar
 */
export class BaTabbar {
    constructor(element: any);
    scrollFactor: number;
    domEl: any;
    leftPos: number;
    listWidth: number;
    viewportWidth: number;
    viewport: any;
    marker: any;
    list: any;
    items: any;
    links: any;
    controls: {
        prev: {
            el: any;
            title: any;
        };
        next: {
            el: any;
            title: any;
        };
    };
    /**
     * Initialisiert die Tabbar, wenn sichtbar
     */
    initVisibilityChange(): void;
    /**
     * Elemente vermessen, Marker positionieren
     */
    initUI(): void;
    /**
     * Aktionen und Handler initialisieren
     */
    initActions(): void;
    /**
     * Links/rechts Scrollbuttons initialisieren und aus Tab-Index entfernen
     */
    initControls(): void;
    /**
     * A11y: reagieren auf Größenänderungen durch interaktive User-Anpassungen (letter-spacing, font-size, ...)
     * Prüfschritt 1.4.12a Textabstände anpassbar (AA)
     */
    initItemResizeObserver(): void;
    /**
     * Verwendung als Tabs initialisieren
     */
    initTabs(): void;
    /**
     * Auf Größenänderungen und Orientationchange des Browsers reagieren
     */
    initResize(): void;
    /**
     * Touch-Steuerung für Mobile initialisieren
     */
    initTouch(): void;
    /**
     * Touchpad-/MightyMouse-Steuerung initialisieren
     */
    initTouchPad(): void;
    /**
     * Tabbar im sichtbaren Bereich verschieben: links, rechts oder Pixelposition
     * @param {string} direction - Mögliche Werte: 'prev', 'next'
     */
    slide(direction: string): void;
    /**
     * Ausrichtung, Overflow, Position und Buttonzustände aktualisieren
     * (initial, nach Resize, nach sichtbarmachen, ...)
     */
    updateUI(): void;
    /**
     * Testen, ob neue Slider-Position korrekt im Viewport liegt,
     * dann auf neue Position sliden und Controls aktualisieren
     */
    updateSlidePos(): void;
    /**
     * Scrollbuttons je nach Scrollposition de/aktivieren
     */
    updateControlStatus(): void;
    /**
     * Prüfen, ob Tabbar größer ist als sichtbarer Bereich
     */
    updateOverflow(): void;
    /**
     * Eintrag in den sichtbaren Bereich schieben
     * @param {HTMLElement} el - Tabbar-Item
     */
    moveIntoViewport(el: HTMLElement): void;
    /**
     * Größe und Position des hover-Markers setzen
     * @param {HTMLElement} el - Tabbar-Item, das markiert werden soll
     */
    setMarker(el: HTMLElement): void;
    /**
     * Bevor Elemente vermessen werden können, muss die Tabbar sichtbar sein
     */
    startMeasure(): void;
    /**
     * Nach dem Vermessen kann Tabbar wieder unsichtbar werden, wenn sie es vorher war
     */
    endMeasure(): void;
    /**
     * Setzt den Tab mit tabId active
     * @param {string} tabId
     * @param {boolean} showPanel
     */
    setActive(tabId: string, showPanel?: boolean): void;
}
