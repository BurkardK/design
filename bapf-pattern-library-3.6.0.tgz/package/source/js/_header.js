/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _header.js */
import { Utilities } from './_utilities';

/**
 * Pattern: Header
 * Initialisiert die Header-Funktionen
 * @constructor
 * @param {HTMLElement} element - Header Element, default: .ba-header
 */
export class BaHeader {

  constructor (element) {
    /* istanbul ignore next */
    if (element.hasAttribute('data-initialized')) return;

    this.domEl = element;
    this.initScrollHeader();
    this.initBootstrap();
    this.initListeners();

    this.domEl.setAttribute('data-initialized', 'true');
  }

  /**
   * Initialisiert Bootstrap-Methoden für Menus und Dropdown
   */
  initBootstrap () {
    // flyouts
    this.domEl.querySelectorAll('.ba-flyout-collapse.collapse').forEach((collapseEl) => {
      this.toggleOnClick(collapseEl, this.domEl);
    });

    // Flyout Collapsibles
    this.domEl.querySelectorAll('.ba-flyout-collapse.collapse .collapse').forEach((collapseEl) => {
      const flyoutEl = collapseEl.closest('.ba-flyout-collapse.collapse');
      this.toggleOnClick(collapseEl, flyoutEl);
    });

    // Dropdown Sprache (data-bs-toggle="dropdown" darf nicht entfernt werden!)
    this.domEl.querySelectorAll('[data-bs-toggle="dropdown"]').forEach((triggerEl) => {
      triggerEl.bsDropdown = (/** @type{any} */(window)).dpl.bs.Dropdown.getInstance(triggerEl) || new (/** @type{any} */(window)).dpl.bs.Dropdown(triggerEl, {
        offset   : '0,4',
        autoClose: true
      });
      triggerEl.addEventListener('keydown', (e) => {
        if (e.key === 'Space' || e.keyCode === 32) {
          e.preventDefault();
          triggerEl.bsDropdown.toggle();
        }
      });
    });
  }

  /**
   * Toggle Menu auf Klick
   * @param {HTMLElement} collapseElement
   * @param {HTMLElement} parentElem
   */
  toggleOnClick (collapseElement, parentElem) {
    const options = {
      toggle: false,
      parent: parentElem
    };

    (/** @type{any} */(collapseElement)).bsCollapse = (/** @type{any} */(window)).dpl.bs.Collapse.getInstance(collapseElement) || new (/** @type{any} */(window)).dpl.bs.Collapse(collapseElement, options);
    const triggerEl = this.domEl.querySelector(`[data-bs-target="#${collapseElement.getAttribute('id')}"]`);
    triggerEl.addEventListener('click', () => {
      (/** @type{any} */(collapseElement)).bsCollapse.toggle();
    });
  }

  /**
   * Setzt Höhe und Style des Headers abhängig von Scroll-Position
   */
  initScrollHeader () {
    if (!this.domEl) return;
    const that = this;
    const mobileHeaderHeight = 53;
    const desktopHeaderOffset = 32;
    let currentScrollTop = window.scrollY;
    let to = null;

    window.addEventListener('scroll', () => {
      const newScrollTop = window.scrollY;
      const scrolled = newScrollTop - currentScrollTop;
      if (Math.abs(scrolled) < 5) return;
      currentScrollTop = newScrollTop;
      const isMobile = window.getComputedStyle(this.domEl).getPropertyValue('position') === 'fixed';
      if (isMobile) {
        /* istanbul ignore next */
        if (currentScrollTop < mobileHeaderHeight || document.querySelectorAll('.ba-flyout-collapse.show').length || this.domEl.querySelectorAll('.ba-flyout-collapse.show').length) {
          setHidden(false);
          return;
        }
        /* istanbul ignore next */
        if (scrolled > 0) { // Scroll down
          setHidden(true);
        } else { // Scroll nach oben
          setHidden(false);
        }
      } else {
        if (currentScrollTop > desktopHeaderOffset) { // Header ist sticky
          setHidden(true);
        } else { // Scroll nach oben
          setHidden(false);
        }
      }

      // .ba-hidden setzen für .ba-header und alle .ba-header-element
      function setHidden (on) {
        const shadowEls = that.domEl.querySelectorAll('.ba-header-element');
        if (on) {
          that.domEl.classList.add('ba-hidden');
          shadowEls.forEach((shadowEl) => {
            shadowEl.classList.add('ba-hidden');
          });
        } else {
          that.domEl.classList.remove('ba-hidden');
          shadowEls.forEach((shadowEl) => {
            shadowEl.classList.remove('ba-hidden');
          });
        }
      }

      // Höhe des Menu-Flyouts aktualisieren, um darin zu scrollen
      clearTimeout(to);
      to = setTimeout(() => {
        this.updateMenuHeight();
      }, 100);
    }, Utilities.supportsPassiveEvent() ? { passive: true } : false);
  }

  /**
   * Initialisiert Events für Header
   * Events: click, keydown, resize, hide.bs.collapse, shown.bs.collapse
   */
  initListeners () {
    // Ein Click außerhalb des Flyout schließt Flyout ba-flyout-collapse
    document.addEventListener('click', (e) => {
      const target = e.composedPath()[0];
      if (!target.closest('.ba-flyout-container')) {
        this.closeFlyouts();
      }
    });

    // Ein Focus außerhalb des Flyouts schließt Flyout ba-flyout-collapse
    document.addEventListener('focusin', (e) => {
      const target = e.composedPath()[0];
      if (!target.closest('.ba-flyout-container')) {
        this.closeFlyouts();
      }
    });

    // Esc-Taste schließt Flyout
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' || e.keyCode === 27) {
        this.closeFlyouts();
      }
    });

    // Menu-Height berechnen nach Resize
    window.addEventListener('resize', () => {
      this.updateMenuHeight();
    });

    // Focus auf letzten Menu-Entry setzen nach schließen des Flyouts
    this.domEl.addEventListener('hide.bs.collapse', (e) => {
      const menu = e.composedPath()[0];
      let focusedElement = document.activeElement;
      /* istanbul ignore next */
      if (document.activeElement.shadowRoot) {
        focusedElement = document.activeElement.shadowRoot.activeElement;
      }
      if (menu.classList.contains('ba-flyout-collapse') && menu.contains(focusedElement)) {
        const control = this.domEl.querySelector(`.ba-menu-entry[aria-controls=${menu.id}]`);
        if (control) control.focus();
      }
    });

    // Verfügbare Menu-Höhe einstellen
    this.domEl.addEventListener('shown.bs.collapse', (e) => {
      const menu = e.composedPath()[0];
      if (menu.classList.contains('ba-flyout-collapse')) {
        this.updateMenuHeight();
      }
    });
  }

  /**
   * Update Flyout-Höhe beim Ausklappen.
   * Wenn Flyout größer ist als Viewport, muss im Flyout gescrollt werden, dazu muss max-height korrekt gesetzt werden
   */
  updateMenuHeight () {
    const openMenu = this.domEl.querySelector('.ba-flyout-collapse.show');
    if (!openMenu) return;
    const menuContainer = openMenu.querySelector('.ba-flyout');
    if (!menuContainer) return;
    const menuTop = menuContainer.getBoundingClientRect().top;
    /* istanbul ignore next */
    const viewportHeight = Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0);
    menuContainer.style.maxHeight = (viewportHeight - menuTop) + 'px';
  }

  /**
   * Alle offenen Flyout-Menus und Collapsibles schließen
   */
  closeFlyouts () {
    this.domEl.querySelectorAll('.show').forEach((elem) => {
      if (elem && elem.bsCollapse) elem.bsCollapse.hide();
    });
  }
}


