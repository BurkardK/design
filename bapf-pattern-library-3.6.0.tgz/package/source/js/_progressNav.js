/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _progressNav.js */
/**
 * Pattern: Fortschritts-Navigation vertikal/horizontal
 * Initialisiert mobile Interaktion für Navigationseinträge
 * @constructor
 * @param {HTMLElement} element - Progress-Nav Pattern, default: .ba-progress-nav
 */
export class BaProgressNav {

  constructor(element) {
    /* istanbul ignore next */
    if (element.hasAttribute('data-initialized')) return;

    this.domEl = element;
    this.init();

    this.domEl.setAttribute('data-initialized', 'true');
  }

  /**
   * Auf- und zuklappen der progress nav mobile
   */
  init() {
    const that = this;
    const btnSteps = this.domEl.querySelector('.ba-toggle-progress');
    const labelNav = this.domEl.getAttribute('aria-label') || 'Fortschrittsnavigation';
    const navEntries = this.domEl.querySelector('.ba-naventries');
    const txtShow = this.domEl.querySelector('.ba-progress-open').textContent;
    const txtClose = this.domEl.querySelector('.ba-progress-close').textContent;

    btnSteps.setAttribute('aria-label', `${labelNav} ${txtShow}`);
    btnSteps.addEventListener('click', (e) => {
      e.preventDefault();
      const transitionTime = 500;
      const container = that.domEl.querySelector('.ba-progress-steps');

      if (container.classList.contains('ba-progress-open')) {
        container.classList.remove('ba-progress-open');
        container.classList.add('ba-progress-closing');
        btnSteps.setAttribute('aria-label', `${labelNav} ${txtShow}`);
        navEntries.removeAttribute('tabindex');
        setTimeout(function () {
          container.classList.remove('ba-progress-closing');
        }, transitionTime);
      } else {
        container.classList.add('ba-progress-open');
        btnSteps.setAttribute('aria-label', `${labelNav} ${txtClose}`);
        const nextFocus = container.querySelector('.ba-naventries li:not(:active) a') || navEntries;
        if (nextFocus === navEntries) {
          navEntries.setAttribute('tabindex', '0');
        }
        nextFocus.focus();
      }
    });
  }
}
