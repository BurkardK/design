/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _textareaCounter.js */
import { Utilities } from './_utilities';

/**
 * Pattern: Textarea-Counter
 * @constructor
 * @param {HTMLElement} element Pattern-Container
 * @param {Object} options Optionen
 */
export class BaTextareaCounter {

  constructor (element, options) {
    /* istanbul ignore next */
    if (element.hasAttribute('data-initialized')) return;

    this.domEl = element;
    this.max = parseInt(this.domEl.getAttribute('maxlength'));
    this.srAnnounceInterval = this.max > 300 ? 100 : 50; // Zeichenzähler im Screenreader alle X Zeichen ausgeben
    this.hasOverflow = false;

    this.options = {
      templateCounter  : (count, max) => `${count} / ${max}`, // Ausgabe-Template für Hilfstext
      templateCounterSR: (count, max) => max - count === 0 ? 'Keine Zeichen mehr erlaubt' : `Noch ${max - count} Zeichen erlaubt`, // Ausgabe-Template für Screen Reader Hilfstext
      templateOverflow : (max) => `Der Inhalt überschreitet die Anzahl der erlaubten Zeichen. Der Text wurde auf ${max} Zeichen gekürzt.`, // Ausgabe-Template für Overflow-Warnung
    };

    /* istanbul ignore next */
    if (options) {
      this.setOptions(options)
    }

    this.init();
  }

  /**
   * Fügt die Live Region und ein Counter Display hinzu und registriert verschiedene Events
   */
  init () {
    this.addLiveRegion();
    this.addCounterDisplay();
    this.counterDisplay.innerHTML = this.options.templateCounter(this.domEl.value.length, this.max);

    // Fokussieren: Verfügbare Zeichen im Screenreader ausgeben (zeitverzögert nach Ausgabe des Labels)
    this.domEl.addEventListener('focus', () => {
      setTimeout(() => this.updateLiveRegion(this.options.templateCounterSR(this.domEl.value.length, this.max)), 300);
    });

    // Drop: Overflow erkennen
    this.domEl.addEventListener('drop', (e) => {
      this.hasOverflow = false;
      const dropData = e.dataTransfer;
      /* istanbul ignore else */
      if (dropData && dropData.getData('text').length + this.domEl.value.length > this.max) {
        this.hasOverflow = true;
      }
    });

    // Einfügen: Overflow erkennen
    /* istanbul ignore next */
    this.domEl.addEventListener('paste', (e) => {
      this.hasOverflow = false;
      const clipboardData = (e.clipboardData || window.clipboardData);
      if (clipboardData && clipboardData.getData('text').length + this.domEl.value.length > this.max) {
        this.hasOverflow = true;
      }
    });

    // Eingabe: Bei Overflow Warnung, ansonsten Counter ausgeben
    this.domEl.addEventListener('input', (e) => {
      // Workaround Safari-Bug: 'input'-Event wird in Safari auch ausgelöst, wenn maxlenght überschritten wird
      /* istanbul ignore next */
      if (Utilities.isSafari() && !e.data && !e.inputType.includes('delete') && !e.inputType.includes('history')) {
        e.preventDefault();
        return;
      }
      if (this.hasOverflow) {
        this.announceOverflow();
        this.hasOverflow = false;
      } else {
        this.announceCounter(['insertFromPaste', 'insertFromDrop', 'insertFromPasteAsQuotation'].includes(e.inputType)); // bei Paste/Drop Zeichenzähler auf jeden Fall auch im Screenreader ausgeben
      }
    });

    // Tastendruck, wenn keine Zeichen mehr verfügbar sind: Warnung vor Overflow
    this.domEl.addEventListener('keydown', () => {
      /* istanbul ignore else */
      if (this.domEl.value.length === this.max) this.announceOverflow();
    });

    // Live-Region leeren beim Verlassen des Feldes
    this.domEl.addEventListener('blur', () => {
      this.updateLiveRegion('');
    });

    this.domEl.setAttribute('data-initialized', 'true');
  }

  /**
   * Überschreibt die vorhandenen Optionen mit Einträgen aus options
   * @param {Object} options
   */
  setOptions (options) {
    /* istanbul ignore else */
    if (options) {
      this.options = { ...this.options, ...options };
    }
  }

  /**
   * Overflow-Warnung ausgeben
   */
  announceOverflow () {
    this.liveRegion.setAttribute('role', 'alert');
    this.liveRegion.setAttribute('aria-live', 'assertive');
    this.setWarning(true);
    this.counterDisplay.innerHTML = this.options.templateOverflow(this.max);
    this.liveRegion.textContent = '';
    setTimeout(() => {
      if (this.domEl.value.length === this.max) this.liveRegion.textContent = this.options.templateOverflow(this.max);
    }, 100);
  }

  /**
   * Counter ausgeben
   * @param {boolean} force Erzwingt die Ausgabe der verfügbaren Zeichen im Screenreader unabhängig von der Anzahl
   */
  announceCounter (force) {
    this.liveRegion.setAttribute('role', 'status');
    this.liveRegion.setAttribute('aria-live', 'polite');
    this.setWarning(false);
    this.counterDisplay.innerHTML = this.options.templateCounter(this.domEl.value.length, this.max);
    // Verfügbare Zeichen im Screenreader ausgeben bei 50%, 10 Zeichen und den letzten 5 Zeichen (oder aktuelle Zahl über force)
    /* istanbul ignore next */
    if (force || this.domEl.value.length % this.srAnnounceInterval === 0 || this.max - this.domEl.value.length === 10 || this.max - this.domEl.value.length <= 5) {
      this.updateLiveRegion(this.options.templateCounterSR(this.domEl.value.length, this.max));
    } else {
      this.updateLiveRegion('');
    }
  }

  /**
   * Feldauszeichnung "Warnung" setzen
   * @param {boolean} on Fügt die Klasse ba-warning hinzu (true) oder entfernt sie (false)
   */
  setWarning (on) {
    if (on) {
      this.domEl.classList.add('ba-warning');
      this.counterDisplay.classList.add('ba-warning');
    } else {
      this.domEl.classList.remove('ba-warning');
      this.counterDisplay.classList.remove('ba-warning');
    }
  }

  /**
   * Counter-Ausgabe hinzufügen
   */
  addCounterDisplay () {
    this.counterDisplay = document.createElement('div');
    this.counterDisplay.classList.add('form-text');
    this.domEl.after(this.counterDisplay);
  }

  /**
   * Live-Region für Screenreader hinzufügen
   */
  addLiveRegion () {
    this.liveRegion = document.createElement('div');
    this.liveRegion.classList.add('sr-only');
    this.liveRegion.setAttribute('aria-live', 'polite');
    this.liveRegion.setAttribute('aria-atomic', 'true');
    this.liveRegion.setAttribute('role', 'status');
    this.domEl.after(this.liveRegion);
  }

  /**
   * Live-Region aktualisieren
   * @param {string} content Neuer Inhalt der Live-Region
   */
  updateLiveRegion (content) {
    if (content !== this.liveRegion.textContent) {
      this.liveRegion.textContent = content;
    }
  }
}
