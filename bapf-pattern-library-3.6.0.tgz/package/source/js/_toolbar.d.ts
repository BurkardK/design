/**
 * Pattern: Toolbar
 * Initialisiert Toolbar-Navigation
 * @constructor
 * @param {HTMLElement} element - Toolbar, default: [role="toolbar"]
 */
export class BaToolbar {
    constructor(element: any);
}
