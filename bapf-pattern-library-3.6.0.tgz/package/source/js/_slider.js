/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _slider.js */
import {Utilities} from './_utilities';

/**
 * Pattern: Slider
 * @constructor
 * @param {HTMLElement} element - Slider Pattern, default: .ba-slider
 */
export class BaSlider {

  constructor(element) {
    /* istanbul ignore next */
    if (element.hasAttribute('data-initialized')) return;

    this.domEl = element;
    this.track = /** @type {HTMLElement} */ (this.domEl.querySelector('.ba-slide-track'));
    this.slides = /** @type {NodeListOf<HTMLElement>} */ (this.track.querySelectorAll('.ba-slide'));
    this.prevText = this.domEl.getAttribute('data-prev-text') || 'vorheriges Bild';
    this.nextText = this.domEl.getAttribute('data-next-text') || 'nächstes Bild';
    this.currentText = this.domEl.getAttribute('data-current-text') || '';
    this.indexText = this.domEl.getAttribute('data-index-text') || 'Bild {1} von {2}';
    this.currentMarker = null;
    this.prev = null;
    this.next = null;
    this.liveRegion = null;
    this.dots = /** @type {HTMLElement | null} */ (null);
    this.current = 0;
    this.left = '0';
    this.max = this.slides.length - 1;

    this.track.style.width = (this.slides.length * 100) + '%';
    this.track.setAttribute('id', `${this.domEl.getAttribute('id')}-track`);
    this.slides.forEach((elem, idx) => elem.setAttribute('id', `${this.domEl.getAttribute('id')}-slide-${(idx + 1).toString()}`))

    this.addLiveRegion();
    this.addPrevNext();
    this.addDots();

    this.resizeSlider();
    this.initTouch();
    this.slide(0, true, false, true);

    window.addEventListener('resize', () => {
      this.resizeSlider();
      this.slide(this.current, true);
    });
    this.initArrowKeys();
    this.initLiveRegion();
    this.initVisibilityChange();
    setTimeout(() => {
      this.resizeSlider();
    }, 100);
    this.domEl.setAttribute('data-initialized', 'true');
  }

  /**
   * Liveregion für Screenreader hinzufügen
   */
  addLiveRegion() {
    const liveRegionElem = document.createElement('div');
    liveRegionElem.classList.add('sr-only');
    liveRegionElem.setAttribute('aria-live', 'off');
    liveRegionElem.setAttribute('aria-atomic', 'true');
    liveRegionElem.setAttribute('aria-hidden', 'true');
    this.domEl.appendChild(liveRegionElem);
    this.liveRegion = liveRegionElem;
  }

  /**
   * 'zurück' und 'weiter' - Controls hinzufügen
   */
  addPrevNext() {
    // zurück-Button
    this.prev = document.createElement('button');
    this.prev.classList.add('ba-slide-prev');
    this.prev.setAttribute('title', this.prevText);
    this.prev.setAttribute('aria-label', this.prevText);
    this.prev.setAttribute('aria-controls', this.track.getAttribute('id'));
    this.prev.addEventListener('click', () => {
      this.slide('prev');
    });

    // weiter-Button
    this.next = document.createElement('button');
    this.next.classList.add('ba-slide-next');
    this.next.setAttribute('title', this.nextText);
    this.next.setAttribute('aria-label', this.nextText);
    this.next.setAttribute('aria-controls', this.track.getAttribute('id'));
    this.next.addEventListener('click', () => {
      this.slide('next');
    });

    // Buttons setzen
    this.domEl.append(this.prev);
    this.domEl.append(this.next);
  }

  /**
   * Navigationspunkte hinzufügen
   */
  addDots() {
    const that = this;
    this.dots = document.createElement('ul');
    this.dots.setAttribute('role', 'tablist');
    this.dots.classList.add('ba-slider-dots');

    // Screenreader-Markierung für aktiven Dot
    this.currentMarker = document.createElement('span');
    this.currentMarker.classList.add('sr-only');
    this.currentMarker.appendChild(document.createTextNode(this.currentText));

    // Dots setzen
    for (let i = 0; i < this.slides.length; i++) {
      const dotText = document.createTextNode(`Bild ${i + 1}`);

      const dotSpanElem = document.createElement('span');
      dotSpanElem.classList.add('sr-only');
      dotSpanElem.appendChild(dotText);

      const dotBtnElem = document.createElement('button');
      dotBtnElem.setAttribute('role', 'tab');
      i === 0 && dotBtnElem.setAttribute('aria-selected', 'true');
      if (i !== 0) {
        dotBtnElem.setAttribute('tabindex', '-1');
      }
      dotBtnElem.setAttribute('aria-controls', this.slides[i].getAttribute('id'));
      dotBtnElem.appendChild(dotSpanElem);

      const dotElem = document.createElement('li');
      dotElem.setAttribute('role', 'presentation');
      dotElem.appendChild(dotBtnElem);

      this.dots.appendChild(dotElem);
    }

    // Alle Dots klickbar machen
    this.dots.querySelectorAll('button').forEach((elem) => {
      elem.addEventListener('click', () => {
        const parentElem = elem.parentNode;
        const closestUl = elem.closest('ul');
        let idx;
        closestUl.querySelectorAll('li').forEach((item, arrId) => {
          if (item === parentElem) idx = arrId;
        });
        that.slide(idx);
      });
    });
    this.domEl.prepend(this.dots);
  }

  /**
   * Positioniert Prev/Next-Buttons und Dots
   */
  positionPrevNextDots() {
    const imgSlide = /** @type {HTMLElement} */ (this.slides[this.current].querySelector('.ba-image'));
    const currSlideImageHeight = imgSlide.offsetHeight;
    this.prev.style.height = `${currSlideImageHeight}px`;
    this.next.style.height = `${currSlideImageHeight}px`;
    this.dots.style.top = `${currSlideImageHeight + 9}px`;
  }

  /**
   * Dots und Buttons neu positionieren nach Resize
   */
  resizeSlider() {
    this.positionPrevNextDots();
  }

  /**
   * Einzelnes Bild sliden (zurück / vorwärts / index)
   * @param {String|Number} direction 'prev' | 'next' | index
   * @param {Boolean} noAnim Animation ausschalten, Slide sofort umschalten
   * @param {Boolean} setSrText Aktualisiert aria-live mit dem aktuellen Bildunterschrift
   */
  slide(direction, noAnim = false, setSrText = true, createAriaLive = false) {
    // Disable/enable prev/next button
    function setDisabled(button, disabled) {
      if (disabled) {
        button.classList.add('disabled');
        button.disabled = true;
        button.setAttribute('aria-hidden', true);
      } else {
        button.classList.remove('disabled');
        button.disabled = false;
        button.removeAttribute('aria-hidden');
      }
    }

    // Neues aktives Slide setzen
    switch (direction) {  // 'prev', 'next' oder index
      case 'prev':
        this.current -= 1;
        break;
      case 'next':
        this.current += 1;
        break;
      default:
        direction = Number(direction);
        this.current = direction;
    }
    setDisabled(this.prev, false);
    setDisabled(this.next, false);

    // Erstes oder letztes Slide?
    if (this.current <= 0) {
      this.current = 0;
      if (document.activeElement === this.prev) {
        this.next.focus({preventScroll: true});
      }
      setDisabled(this.prev, true);
    } else if (this.current >= this.max) {
      this.current = this.max;
      if (document.activeElement === this.next) {
        this.prev.focus({preventScroll: true});
      }
      setDisabled(this.next, true);
    }

    // Neue Slider-Position setzen
    const newPos = ((100 / this.slides.length) * -this.current) + '%';
    if (noAnim) {
      this.domEl.classList.add('ba-no-anim');
    }
    this.track.style.transform = 'translate3d(' + newPos + ', 0, 0)';
    setTimeout(() => {
      this.domEl.classList.remove('ba-no-anim');
    }, 100);
    this.left = newPos;

    // A11y-Infos setzen
    const currentSlide = this.slides[this.current];
    currentSlide.removeAttribute('aria-hidden');
    Array.prototype.filter.call(currentSlide.parentNode.children, (child) => {
      if (child !== currentSlide) {
        child.setAttribute('aria-hidden', true);
        return child;
      }
    });
    // Dots updaten
    this.dots.querySelectorAll('li').forEach((li, idx) => {
      const button = li.querySelector('button');
      if (idx === this.current) {
        li.classList.add('ba-active');
        button.appendChild(this.currentMarker);
        button.hasAttribute('tabindex') && button.removeAttribute('tabindex');
        button.setAttribute('aria-selected', 'true');
      } else {
        li.classList.remove('ba-active');
        button.setAttribute('tabindex', '-1');
        button.setAttribute('aria-selected', 'false');
      }
    });

    handleLiveRegion(this);

    // Live-Region update für Screenreader
    function handleLiveRegion(that) {
      if (setSrText) {
        let slideCaption = that.slides[that.current].querySelector('.ba-caption').textContent;
        if (document.activeElement.getAttribute('role') !== 'tab') {
          slideCaption = that.slides[that.current].querySelector('.ba-caption').textContent + ' ' + that.indexText.replace('{1}', (that.current + 1).toString()).replace('{2}', (that.slides.length).toString());
        }
        that.setLiveRegionText(slideCaption);
      }
      if (createAriaLive) {
        that.liveRegion.textContent = '';
      }
    }

  }

  /**
   * Steuerung mit Pfeiltasten
   */
  initArrowKeys() {
    this.domEl.addEventListener('keydown', (evt) => {

      handleArrowLeft(this);
      handleArrowRight(this);

      // Links
      function handleArrowLeft(that) {
        if (evt.key === 'ArrowLeft' || evt.key === '37') {
          const evtTarget = /**  @type {any} */ (evt.target);
          if (evtTarget.closest('ul') && evtTarget.closest('ul') === that.dots) {
            const prev = that.dots.querySelectorAll('li button')[that.current - 1];
            if (prev) {
              prev.removeAttribute('tabindex');
              setTimeout(() => {
                prev.focus({preventScroll: true});
              }, 10);
            }
          } else {
            that.prev.focus({preventScroll: true});
          }
          that.slide('prev');
        }
      }

      // Rechts
      function handleArrowRight(that) {
        if (evt.key === 'ArrowRight' || evt.key === '39') {
          const evtTarget = evt.target;
          if (evtTarget.closest('ul') && evtTarget.closest('ul') === that.dots) {
            const next = that.dots.querySelectorAll('li button')[that.current + 1];
            if (next) {
              next.removeAttribute('tabindex');
              setTimeout(() => {
                next.focus({preventScroll: true});
              }, 10);
            }
          } else {
            that.next.focus({preventScroll: true});
          }
          that.slide('next');
        }
      }
    });
  }

  /**
   * Steuerung mit Touch Swipe
   */
  initTouch() {
    let startOffsetX = 0;
    const threshold = 50; // Distanz in Pixeln vom touchdrag zum Trigger Slide
    const that = this;
    this.track.addEventListener('touchstart', (event) => {
      startOffsetX = event.changedTouches[0].pageX;
      this.domEl.classList.add('ba-no-anim');
      window.addEventListener('touchmove', touchDragHandler);
      window.addEventListener('touchend', touchDragEnd);
    }, Utilities.supportsPassiveEvent() ? {passive: true} : false);

    // Während des Drag-Vorgangs
    function touchDragHandler(event) {
      event.stopPropagation();
      const newOffsetX = event.changedTouches[0].pageX;
      const dist = startOffsetX - newOffsetX;
      that.track.style.transform = 'translate3d(' + (Number(that.left) - dist) + 'px, 0, 0)';
    }

    // Nach dem Drag/Touch-Vorgang
    function touchDragEnd(event) {
      event.stopPropagation();
      that.domEl.classList.remove('ba-no-anim');
      const endOffsetX = event.changedTouches[0].pageX;
      if (startOffsetX > endOffsetX + threshold && that.current < that.max) { // Swipe nach rechts
        that.slide('next');
      } else if (startOffsetX < endOffsetX - threshold && that.current > 0) { // Swipe nach links
        that.slide('prev');
      } else {
        that.slide(that.current);
      }
      window.removeEventListener('touchmove', touchDragHandler);
      window.removeEventListener('touchend', touchDragEnd);
    }
  }

  /**
   * Focus-Handler für Live-Region updates
   */
  initLiveRegion() {
    const enableLiveRegion = () => {
      this.liveRegion.setAttribute('aria-live', 'polite');
      const slideCaption = this.slides[this.current].querySelector('.ba-caption').textContent;
      this.setLiveRegionText(slideCaption);
    };
    const disableLiveRegion = () => {
      this.liveRegion.setAttribute('aria-live', 'off');
      this.liveRegion.textContent = '';
    };
    this.domEl.addEventListener('focusin', enableLiveRegion);
    this.domEl.addEventListener('focusout', disableLiveRegion);
  }

  /**
   * Auf Änderung der Sichtbarkeit reagieren - Button- und Dots-Positionen lassen sich nur setzen, wenn Slider sichtbar ist
   */
  initVisibilityChange() {
    try {
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.intersectionRatio > 0) {
            this.resizeSlider();
          }
        });
      });
      observer.observe(this.domEl);
    } catch (e) {
      console.log('IntersectionObserver nicht unterstützt, bitte Browser updaten.'); //NOSONAR
    }
  }

  /**
   * Ersetzt den Text in der Live-Region mit newText
   * @param {string} newText
   */
  setLiveRegionText(newText) {
    if (newText !== this.liveRegion.textContent) {
      this.liveRegion.setAttribute('aria-hidden', 'false');
      this.liveRegion.textContent = newText;
      setTimeout(() => this.liveRegion.setAttribute('aria-hidden', 'true'), 10);
    }
  }
}

