export class BaDropdownSelect extends BaDropdown {
    /**
     * Dropdwon-Helpers für Select-Funktion initialisieren
     */
    init(): void;
    /**
     * Vervollständigt das Dropdown mit allen Events
     * @param {HTMLElement} dropdown ziel Dropdown
     */
    applyJsOnDropdown(dropdown: HTMLElement): void;
    /**
     * Aktualisiert mögliche States bei Dropdown, abhängig von aktivem Selection
     * @param {HTMLElement} dropdown ziel Dropdown
     */
    updateStates(dropdown: HTMLElement): void;
    /**
     * Gibt aktives <a> Element zurück
     * @param {HTMLElement} dropdown dropdown select element
     * @return {HTMLElement} selected a element
     */
    getActiveAnchor(dropdown: HTMLElement): HTMLElement;
    /**
     * Prüft, ob kein aktiver Eintrag vorhanden ist
     * @param {HTMLElement} dropdown ziel Dropdown
     * @return {boolean} true wenn dropdown keine aktive selection hat
     */
    isNoActive(dropdown: HTMLElement): boolean;
}
import { BaDropdown } from './_dropdown';
