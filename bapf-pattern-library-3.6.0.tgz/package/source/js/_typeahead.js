/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _typeahead.js */
import { Utilities } from './_utilities';

/**
 * Pattern: Typeahead
 * @constructor
 * @param {HTMLElement} element Pattern-Container
 * @param {Object} options Optionen
 */
export class BaTypeahead {

  constructor (element, options) {
    /* istanbul ignore next */
    if (element.hasAttribute('data-initialized')) return;

    this.domEl = element;

    this.currentActive = null;
    this.listOpen = false;
    this.suggestions = [];
    this.filteredSuggestions = []; // gefilterte Vorschläge begrenzt auf Maximalanzahl
    this.filteredSuggestionsCount = 0; // tatsächliche Anzahl gefilterter Vorschläge (ohne Begrenzung)
    this.debounceTimeout = null;
    this.lastSearch = null; // letzter Suchbegriff (für Änderungsprüfung)
    this.suggestionsFetchingCounter = 0; // laufende Nummer für Vorschlagsabrufe
    this.appliedSuggestionsFetchingIndex = -1; // welcher Vorschlagsabruf als letztes angewendet wurde

    this.options = {
      suggestions            : [],    // Vorschläge als Liste oder asynchrone Funktion
      entryTemplate          : (entry) => `<a class="dropdown-item" href="#" aria-label="${entry.term}">${entry.highlightedTerm}</a>`, // Ausgabe-Template für Eintrag in Vorschlagsliste
      selectCallback         : null,  // Callback-Funktion, die nach der Auswahl eines Vorschlags aus der Liste ausgeführt wird
      maxResults             : 10,    // Maximale Anzahl der anzuzeigenden Vorschläge
      minInputChars          : 1,     // Minimale Anzahl eingegebener Zeichen, bevor die Vorschlagsliste gerendert wird
      debounce               : 300,   // Verzögerung in ms, nach der die Eingabe die Vorschlagsliste aktualisiert
      filter                 : true,  // ob Vorschläge anhand des Suchbegriffs aussortiert werden sollen
      moreResultsTemplate    : false, // Ausgabe-Template für letzte Zeile, wenn mehr Ergebnisse verfügbar sind als angezeigt werden; Signatur (count: number, max: number) => string
      moreResultsAnnouncement: false  // Hinweis für Screen-Reader-Nutzer, dass mehr Ergebnisse verfügbar; Signatur (count: number, max: number) => string
    };

    if (options) {
      this.options = { ...this.options, ...options };
      if (typeof this.options.suggestions === 'function') {
        this.suggestions = [];
      } else {
        this.suggestions = this.options.suggestions;
      }
    }

    // Eventhandler registrieren
    this.handlers = {
      keyupSearchField: this.onKeyupSearchField.bind(this),
      clickDocument   : this.onClickDocument.bind(this),
      keydownDocument : this.onKeydownDocument.bind(this)
    };

    // Alle Elemente bereit? Init!
    this.searchField = element.querySelector('.dropdown input');
    this.suggestionList = element.querySelector('.dropdown-menu');
    if (this.searchField && this.suggestionList) {
      this.init();
    }
  }

  /**
   * Initialisiert den Typeahead durch hinzufügen von keyup/keydown Event Handlern und
   * dem initialisieren der Live-Region
   */
  init () {
    this.searchField.addEventListener('keyup', this.handlers.keyupSearchField);
    document.addEventListener('click', this.handlers.clickDocument);
    document.addEventListener('keydown', this.handlers.keydownDocument);
    this.addLiveRegion();
    this.domEl.setAttribute('data-initialized', 'true');
  }

  /**
   * Entfernt die Typeahead-Funktionalität mit allen Handlern
   */
  destroy () {
    clearTimeout(this.debounceTimeout);
    this.filteredSuggestions = [];
    this.filteredSuggestionsCount = 0;
    this.appliedSuggestionsFetchingIndex = Number.MAX_SAFE_INTEGER; // laufender Vorschlagsabruf wird damit nicht mehr angewendet
    this.paintList();
    document.removeEventListener('click', this.handlers.clickDocument);
    document.removeEventListener('keydown', this.handlers.keydownDocument);
    this.searchField.removeEventListener('keyup', this.handlers.keyupSearchField);
    this.domEl.removeChild(this.liveRegion);
    this.domEl.removeAttribute('data-initialized');
  }

  /**
   * Überschreibt die vorhandenen Optionen mit Einträgen aus options
   * @param {Object} options
   */
  async setOptions (options) {
    if (options) {
      this.options = { ...this.options, ...options };
      if (typeof this.options.suggestions === 'function') {
        this.suggestions = [];
      } else {
        this.suggestions = this.options.suggestions;
      }
      this.lastSearch = null;
      await this.updateList();
    }
  }

  /**
   * Maus-Handler für Document
   * @param {MouseEvent} e
   */
  onClickDocument (e) {
    if (this.listOpen && this.searchField !== e.target && !this.suggestionList.contains(e.target)) {
      this.closeMenu();
    }
  }

  /**
   * Tastatur-Handler für Document
   * @param {KeyboardEvent} e
   */
  onKeydownDocument (e) {
    if (e.key === 'Tab') this.closeMenu();
  }

  /**
   * Tastatur-Handler für Input-Feld
   * @param {KeyboardEvent} e
   */
  onKeyupSearchField (e) {
    const handleEscape = () => {
      this.closeMenu();
    };

    const handleEnter = () => {
      if (this.currentActive !== null) {
        if (this.options.selectCallback !== null) {
          this.options.selectCallback(this.filteredSuggestions[this.currentActive]);
        } else {
          this.searchField.focus();
        }
      }
      this.closeMenu();
    };

    const handleArrowUp = () => {
      if (this.currentActive <= 0) {
        this.currentActive = 0;
      } else {
        this.currentActive = this.currentActive - 1;
      }
      this.selectListItem();
    };

    const handleArrowDown = () => {
      if (this.currentActive === null || this.currentActive >= (this.filteredSuggestions.length - 1)) {
        this.currentActive = 0;
      } else {
        this.currentActive = this.currentActive + 1;
      }
      this.selectListItem();
    };

    switch (e.key) {
      // Sonderfunktionen
      case 'Escape':
        handleEscape();
        break;
      case 'Enter':
        handleEnter();
        break;
      case 'ArrowUp':
        handleArrowUp();
        break;
      case 'ArrowDown':
        handleArrowDown();
        break;

      // ggf. normale Eingaben
      default:
        const val = this.getNormalizedSearchFieldValue();

        if (val.length < this.options.minInputChars) {
          this.emptyLiveRegion();
          this.closeMenu();
        } else if (this.lastSearch !== val) {
          clearTimeout(this.debounceTimeout);
          this.debounceTimeout = window.setTimeout(() => {
            this.listOpen = true;
            this.updateList().then((success) => {
              if (success) this.updateLiveRegion();
            });
          }, this.options.debounce);
        }

        this.lastSearch = val;
        break;
    }
  }

  /**
   * Gibt die Sucheingabe zurück ohne überflüssige White-Spaces.
   */
  getNormalizedSearchFieldValue () {
    return this.searchField.value.trim();
  }

  /**
   * Menü öffnen
   */
  openMenu () {
    this.listOpen = true;
    this.searchField.setAttribute('aria-expanded', 'true');
    this.searchField.removeAttribute('aria-activedescendant');
    this.suggestionList.classList.add('show');
  }

  /**
   * Menü schließen
   */
  closeMenu () {
    clearTimeout(this.debounceTimeout);
    this.filteredSuggestions = [];
    this.filteredSuggestionsCount = 0;
    this.lastSearch = null;
    this.appliedSuggestionsFetchingIndex = ++this.suggestionsFetchingCounter; // laufende Anfrage soll Menü nicht wieder öffnen
    this.currentActive = null;
    this.listOpen = false;
    this.searchField.classList.remove('ba-hide-focus-outline');
    this.searchField.setAttribute('aria-expanded', 'false');
    this.searchField.removeAttribute('aria-activedescendant');
    this.suggestionList.classList.remove('show');
  }

  /**
   * Eintrag per Pfeiltasten aus Vorschlagsliste anwählen
   */
  selectListItem () {
    this.searchField.classList.remove('ba-hide-focus-outline');
    this.suggestionList.querySelectorAll('li').forEach((entry, idx) => {
      if (entry.classList.contains('ba-typeahead-more-results')) return;

      entry.setAttribute('aria-selected', 'false');
      entry.querySelector('a').classList.remove('ba-focused');

      if (idx === this.currentActive) {
        this.searchField.classList.add('ba-hide-focus-outline');
        entry.setAttribute('aria-selected', 'true');
        entry.querySelector('a').classList.add('ba-focused');
        this.searchField.setAttribute('aria-activedescendant', entry.getAttribute('id'));
        if (!Utilities.isInViewport(entry)) {
          entry.scrollIntoView({
            behavior: 'smooth',
            block   : 'nearest'
          });
        }
        this.choice();
      }
    });
  }

  /**
   * Aktualisieren der Vorschläge
   * @returns false wenn abgebrochen
   */
  async updateList () {
    this.currentActive = null;
    const enteredValue = this.getNormalizedSearchFieldValue();

    if (!enteredValue) {
      this.filteredSuggestions = [];
      this.filteredSuggestionsCount = 0;
      this.paintList();
      return true;
    }

    if (typeof this.options.suggestions === 'function') {
      const fetchingIndex = this.suggestionsFetchingCounter++;
      this.suggestions = await this.options.suggestions(enteredValue);

      if (fetchingIndex < this.appliedSuggestionsFetchingIndex) {
        // Fall: ein neuerer Vorschlagsabruf ist bereits angewendet worden, daher hier nichts
        // weiter unternehmen
        return false;
      }
      this.appliedSuggestionsFetchingIndex = fetchingIndex;
    }

    const allFilteredSuggestions = this.suggestions
      .filter((entry) => {
        if (this.options.filter === false) {
          return true;
        }
        return entry.term && entry.term.toLowerCase().indexOf(enteredValue.toLowerCase()) > -1;
      })
      .map((entry) => {
        const highlightedTerm = entry.term.replace(new RegExp(enteredValue.replace(/[/\-\\^$*+?.()|[\]{}]/g, '\\$&'), 'ig'), function (str) {
            return '<span class="term">' + str + '</span>';
        });
        return { highlightedTerm: highlightedTerm, ...entry };
      });

    this.filteredSuggestions = allFilteredSuggestions.slice(0, this.options.maxResults);
    this.filteredSuggestionsCount = allFilteredSuggestions.length;

    this.paintList();
    return true;
  }

  /**
   * Rendern der Vorschlagsliste
   */
  paintList () {
    // Liste löschen
    while (this.suggestionList.firstChild) {
      this.suggestionList.removeChild(this.suggestionList.firstChild);
    }
    // Keine Treffer
    if (this.filteredSuggestions.length === 0) {
      this.closeMenu();
      return;
    }

    this.filteredSuggestions.forEach((entry) => {
      const listElement = `<li role="option" aria-hidden="true">${this.options.entryTemplate(entry)}</li>`;
      this.suggestionList.insertAdjacentHTML('beforeend', listElement);
    });

    if (this.options.moreResultsTemplate && this.filteredSuggestionsCount > this.options.maxResults) {
      // mehr Ergebnisse vorhanden als angezeigt werden, füge zusätzliche Zeile mit Hinweis ein
      const moreListElement = `<li role="option" aria-hidden="true" class="ba-typeahead-more-results">${
        this.options.moreResultsTemplate(this.filteredSuggestionsCount, this.options.maxResults)
      }</li>`;
      this.suggestionList.insertAdjacentHTML('beforeend', moreListElement);
    }

    this.selectListItem();

    this.suggestionList.querySelectorAll('a').forEach((elem, index) => {
      elem.addEventListener('click', (e) => {
        e.preventDefault();
        this.currentActive = index;
        this.choice();
        if (this.options.selectCallback !== null) {
          this.options.selectCallback(this.filteredSuggestions[this.currentActive]);
        } else {
          this.searchField.focus();
        }
        this.closeMenu();
      });
    });

    this.openMenu();
  }

  /**
   * Ausgewählten Eintrag aus Liste als Input-Wert setzen
   */
  choice () {
    if (this.currentActive === null || !this.filteredSuggestions[this.currentActive] || !this.filteredSuggestions[this.currentActive].term) {
      return;
    }
    this.searchField.value = this.filteredSuggestions[this.currentActive].term;
  }

  /**
   * Live-Region für Screenreader hinzufügen
   */
  addLiveRegion () {
    this.liveRegion = document.createElement('div');
    this.liveRegion.classList.add('sr-only');
    this.liveRegion.setAttribute('aria-live', 'polite');
    this.liveRegion.setAttribute('aria-atomic', 'true');
    this.liveRegion.setAttribute('role', 'status');
    this.domEl.appendChild(this.liveRegion);
  }

  /**
   * Screenreader neue Anzahl an Elementen vorlesen lassen
   */
  updateLiveRegion () {
    const resultListLength = Math.min(this.filteredSuggestionsCount, this.options.maxResults);

    let liveRegionContent =
      resultListLength + (resultListLength === 1 ? ' Ergebnis' : ' Ergebnisse');

    if (this.options.moreResultsAnnouncement && this.filteredSuggestionsCount > this.options.maxResults) {
      // mehr Ergebnisse verfügbar als aufgelistet, Hinweis hinzufügen
      liveRegionContent +=
        ', ' + this.options.moreResultsAnnouncement(this.filteredSuggestionsCount, this.options.maxResults);
    }

    if (liveRegionContent !== this.liveRegion.textContent) {
      this.liveRegion.textContent = liveRegionContent;
    }
  }

  /**
   * Leeren der Live-Region
   */
  emptyLiveRegion () {
    if (this.liveRegion.textContent !== '') this.liveRegion.textContent = '';
  }
}
