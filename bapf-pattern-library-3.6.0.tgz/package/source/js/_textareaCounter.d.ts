/**
 * Pattern: Textarea-Counter
 * @constructor
 * @param {HTMLElement} element Pattern-Container
 * @param {Object} options Optionen
 */
export class BaTextareaCounter {
    constructor(element: any, options: any);
    domEl: any;
    max: number;
    srAnnounceInterval: number;
    hasOverflow: boolean;
    options: {
        templateCounter: (count: any, max: any) => string;
        templateCounterSR: (count: any, max: any) => string;
        templateOverflow: (max: any) => string;
    };
    /**
     * Fügt die Live Region und ein Counter Display hinzu und registriert verschiedene Events
     */
    init(): void;
    /**
     * Überschreibt die vorhandenen Optionen mit Einträgen aus options
     * @param {Object} options
     */
    setOptions(options: any): void;
    /**
     * Overflow-Warnung ausgeben
     */
    announceOverflow(): void;
    /**
     * Counter ausgeben
     * @param {boolean} force Erzwingt die Ausgabe der verfügbaren Zeichen im Screenreader unabhängig von der Anzahl
     */
    announceCounter(force: boolean): void;
    /**
     * Feldauszeichnung "Warnung" setzen
     * @param {boolean} on Fügt die Klasse ba-warning hinzu (true) oder entfernt sie (false)
     */
    setWarning(on: boolean): void;
    /**
     * Counter-Ausgabe hinzufügen
     */
    addCounterDisplay(): void;
    counterDisplay: HTMLDivElement;
    /**
     * Live-Region für Screenreader hinzufügen
     */
    addLiveRegion(): void;
    liveRegion: HTMLDivElement;
    /**
     * Live-Region aktualisieren
     * @param {string} content Neuer Inhalt der Live-Region
     */
    updateLiveRegion(content: string): void;
}
