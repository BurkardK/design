/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _contactInfobox.js */
/**
 * Pattern: Kontaktinfobox
 * steuert Anzeige der Öffnungszeiten
 * @constructor
 * @param {HTMLElement} element - Kontaktinfobox Pattern, default: .ba-contact-infobox
 */
export class BaContactInfobox {

  constructor (element) {
    /* istanbul ignore next */
    if (element.hasAttribute('data-initialized')) return;

    this.domEl = element;
    this.init();

    this.domEl.setAttribute('data-initialized', 'true');
  }

  /**
   * Anzeige der Öffnungszeiten initialisieren
   */
  init () {
    const date = new Date();
    const day = date.getDay();
    const openingTimeTable = this.domEl.querySelectorAll('.ba-contact-infobox-day');
    const triggerElems = this.domEl.querySelectorAll('.ba-toggle-days');

    if (triggerElems.length !== 0) {
      triggerElems.forEach((trigger) => {
        trigger.setAttribute('aria-expanded', 'false');
      });
    }

    const expando = this.domEl.querySelector('.ba-contact-infobox-day');
    let AllDdDtNotToday = null;
    if (openingTimeTable.length !== 0) {
      openingTimeTable.forEach((elem) => {
        const todayIndex = day === 0 ? 6 : day - 1;
        const todayTime = elem.querySelectorAll('dd')[todayIndex];
        elem.querySelectorAll('dt')[todayIndex].classList.add('ba-today');
        elem.querySelectorAll('dd')[todayIndex].classList.add('ba-today');
        this.showOpenText(date, todayTime, elem);
        AllDdDtNotToday = expando.querySelectorAll('dd:not(.ba-today), dt:not(.ba-today)') || [];
        this.setAriaHidden(AllDdDtNotToday, false);
      });
    }

    // Öffnen und schließen der Öffnungszeiten
    this.domEl.addEventListener('click', (e) => {
      // Geht durch alle Elternknoten des Targets
      if (e.target.matches('.ba-contact-infobox .ba-toggle-days')) {
        e.preventDefault();

        const trigger = e.target;
        let tableClosedText = null;
        let tableOpenText = null;

        if (expando) {
          tableClosedText = expando.getAttribute('data-closed-toggle-text');
          tableOpenText = expando.getAttribute('data-open-toggle-text');

          const isOpen = expando.classList.contains('ba-open');
          if (isOpen) {
            // Schließen
            this.setAriaHidden(AllDdDtNotToday, false);
            expando.classList.remove('ba-open');
            trigger.textContent = tableClosedText;
            trigger.classList.remove('ba-link-up');
            trigger.classList.add('ba-link-down');
            const ddElements = expando.querySelectorAll('dd');
            const dtElements = expando.querySelectorAll('dt');
            ddElements[ddElements.length - 1].setAttribute('hidden', false);
            dtElements[dtElements.length - 1].setAttribute('hidden', false);
            ddElements[ddElements.length - 2].setAttribute('hidden', false);
            dtElements[dtElements.length - 2].setAttribute('hidden', false);
          } else {
            // Öffnen
            expando.classList.add('ba-open');
            this.setAriaHidden(AllDdDtNotToday, true);

            trigger.textContent = tableOpenText;
            trigger.classList.remove('ba-link-down');
            trigger.classList.add('ba-link-up');
            const ddElements = expando.querySelectorAll('dd');
            const dtElements = expando.querySelectorAll('dt');
            ddElements[ddElements.length - 1].setAttribute('hidden', true);
            dtElements[dtElements.length - 1].setAttribute('hidden', true);
            ddElements[ddElements.length - 2].setAttribute('hidden', true);
            dtElements[dtElements.length - 2].setAttribute('hidden', true);
          }
          trigger.setAttribute('aria-expanded', (!isOpen).toString());
        }
      }

    }, { capture: false });
  }

  /**
   * Schaltet die Öffungszeiten für Screenreader ein/aus.
   * @param {NodeList} elems
   * @param {boolean} isOpen
   */
  setAriaHidden(elems, isOpen) {
    elems.forEach((/** @type {HTMLElement} */elem) => {
      isOpen ? elem.removeAttribute('aria-hidden') : elem.setAttribute('aria-hidden', 'true');
    });
  }

  /**
   * Zeigt den Status des Heutigen Tages ('Geöffnet', 'Öffnet demnächst', 'Schließt demnächst', 'Geschlossen')
   * @param {Date} date 'der Jetzige Zeitpunkt'
   * @param {HTMLElement} todayTime das Heutige Zeitfeld aus der Öffnungszeiten Liste
   * @param openingTimeTable die Öffnungszeiten Liste
   */
  showOpenText (date, /** @type {HTMLElement} */todayTime, openingTimeTable) {
    let hasEveningTime = false;
    if (todayTime.getAttribute('data-opening-evening-time-hour')) {
      hasEveningTime = true;
    }
    const compareOpenTimeMorning = new Date();
    const compareClosingTimeMorning = new Date();

    const compareOpenTimeEvening = new Date();
    const compareClosingTimeEvening = new Date();

    compareOpenTimeMorning.setHours(Number(todayTime.getAttribute('data-opening-morning-time-hour')));
    compareOpenTimeMorning.setMinutes(Number(todayTime.getAttribute('data-opening-morning-time-minutes')));

    compareClosingTimeMorning.setHours(Number(todayTime.getAttribute('data-closing-morning-time-hour')));
    compareClosingTimeMorning.setMinutes(Number(todayTime.getAttribute('data-closing-morning-time-minutes')));

    compareOpenTimeEvening.setHours(Number(todayTime.getAttribute('data-opening-evening-time-hour')));
    compareOpenTimeEvening.setMinutes(Number(todayTime.getAttribute('data-opening-evening-time-minutes')));

    compareClosingTimeEvening.setHours(Number(todayTime.getAttribute('data-closing-evening-time-hour')));
    compareClosingTimeEvening.setMinutes(Number(todayTime.getAttribute('data-closing-evening-time-minutes')));

    const openingTimeObject = {
      openMorningTime   : compareOpenTimeMorning,
      closingMorningTime: compareClosingTimeMorning,
      openingEveningTime: compareOpenTimeEvening,
      closingEveningTime: compareClosingTimeEvening
    };

    let text;

    // Bestimmt welcher Text am Heutigen Tag angezeigt wird ('Geöffnet', 'Öffnet demnächst', 'Schließt demnächst', 'Geschlossen')
    if ((this.isOpen(date, openingTimeObject.openMorningTime, openingTimeObject.closingMorningTime)) || (this.isOpen(date, openingTimeObject.openingEveningTime, openingTimeObject.closingEveningTime))) {
      if (this.timeframe(date, openingTimeObject, true, hasEveningTime)) {

        text = openingTimeTable.getAttribute('data-almost-closed-text');
        this.fillStatus(todayTime, text, 'almost');
      } else {
        text = openingTimeTable.getAttribute('data-open-text');
        this.fillStatus(todayTime, text, 'open');
      }
    } else {
      if (this.timeframe(date, openingTimeObject, false, hasEveningTime)) {
        text = openingTimeTable.getAttribute('data-almost-open-text');
        this.fillStatus(todayTime, text, 'almost');
      } else {
        if (!todayTime.getAttribute('data-weekend')) {
          text = openingTimeTable.getAttribute('data-closed-text');
          this.fillStatus(todayTime, text, 'closed');
        }
      }
      if (todayTime.getAttribute('data-weekend')) {
        this.fillStatus(todayTime, text, 'closed');
      }
    }
  }

  /**
   * Prüft, ob aktuelles DateTime im Zeitraum 'geöffnet' liegt
   * @param {Date} date 'der Jetzige Zeitpunkt'
   * @param {Date} openTime 'Date mit der Öffnungszeit'
   * @param {Date} closingTime 'Date mit der Schließungszeit'
   * @return {Boolean}
   */
  isOpen (date, openTime, closingTime) {
    return (date.getTime() > openTime.getTime() && date.getTime() < closingTime.getTime());
  }

  /**
   * Berechnet ob es 'demnächst Öffnet / Schließt' oder nicht
   * @param {Date} date 'der Jetzige Zeitpunkt'
   * @param {{closingMorningTime:Date,openingEveningTime:Date,closingEveningTime:Date,openMorningTime:Date}} openingTimeObject 'Date mit den Öffnungs- und Schließungszeiten'
   * @param {Boolean} open 'gibt an ob jetzt grade Offen ist'
   * @param {Boolean} hasEveningTime 'gibt an ob Heute auch am Nachmitag Öffnungszeiten existieren'
   * @return {Boolean}
   */
  timeframe (date, openingTimeObject, open, hasEveningTime) {
    let time;
    if (open) {
      time = openingTimeObject.closingMorningTime.getTime() - date.getTime();
      if (hasEveningTime && date.getTime() > openingTimeObject.openingEveningTime.getTime()) {
        time = openingTimeObject.closingEveningTime.getTime() - date.getTime();
      }
    } else {
      time = openingTimeObject.openMorningTime.getTime() - date.getTime();
      if (hasEveningTime && date.getTime() > openingTimeObject.closingMorningTime.getTime()) {
        time = openingTimeObject.openingEveningTime.getTime() - date.getTime();
      }
    }
    return (Math.round(time / 60 / 1000) <= 30 && Math.round(time / 60 / 1000) >= 0);
  }

  /**
   * Befuellt den Heutigen Tag mit dem Status in allen Kontaktinfoboxen auf der Seite
   * @param todayTime das Heutige Zeitfeld aus der Öffnungszeiten Liste
   * @param {String} text 'ein String mit dem Text'
   * @param {String} status 'ein String mit dem Status'
   */
  fillStatus (todayTime, text, status) {
    if (todayTime.getAttribute('data-weekend')) {
      todayTime.classList.add('ba-opening-status-closed');
    } else {
      const brElem = document.createElement('br');
      const spanElem = document.createElement('span');
      const spanClass = 'ba-opening-status ba-opening-status-' + status;
      const spanText = document.createTextNode(text);
      spanElem.setAttribute('class', spanClass);
      spanElem.appendChild(spanText);
      todayTime.appendChild(brElem);
      todayTime.appendChild(spanElem);
    }
  }
}
