/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _subHeader.js */
import { Utilities } from './_utilities';

/**
 * Pattern: SubHeader
 * Initialisiert die SubHeader-Funktionen
 * @constructor
 * @param {HTMLElement} element - SubHeader Element, default: .ba-subheader
 */
export class BaSubHeader {

  constructor (element) {
    /* istanbul ignore next */
    if (element.hasAttribute('data-initialized')) return;

    this.domEl = element;
    this.hasLogo = this.domEl.querySelectorAll('.ba-col-logo').length > 0;
    this.scrollHandler = this.handleHeaderInteractions.bind(this); // Extra-Referenz benötigt wg. bind(this)
    this.resizeHandler = this.handleResize.bind(this);
    this.resizeTO = null;

    // Observers
    this.observers = {
      headerClass     : null,
      subHeaderCompact: null,
      subHeaderFull   : null
    };
    // Höhe der Header
    this.headerHeight = {
      'compact': 53,
      'full'   : 76
    };
    // Abstand nach oben für Scroll-Anker
    this.scrollPaddingTop = {
      'headerOnly'    : '58px',
      'subheaderSmall': '116px',
      'subheaderLarge': '163px'
    };
    this.init();
  }

  /**
   * Sucht den Header als WebComponent oder im DOM und initialisiert dann den SubHeader
   */
  async init () {
    this.header = await Utilities.getHeader();
    if (this.header) {
      this.domEl.classList.toggle('ba-has-logo', this.hasLogo);// Wenn es eine Logo-Spalte gibt, wird sie in der mobilen Portrait-Ansicht ausgeblendet, wenn Subheader oben ist
      this.handleHeaderInteractions();
      this.initObservers();
      window.addEventListener('resize', this.resizeHandler);
      this.domEl.setAttribute('data-initialized', 'true');
    }
  }

  /**
   * Observer installieren zur Überwachung von:
   * - Sichtbarkeit Header mobile: wenn Header sichtbar ist, muss SubHeader entsprechend nach unten verschoben werden
   * - Position SubHeader mobile: wenn SubHeader sticky ist, muss Logo ausgeblendet werden
   * - Position SubHeader desktop: wenn SubHeader an Header stößt, wird dieser mit nach oben verschoben, bis SubHeader sticky ist
   */
  initObservers () {
    const that = this;

    try {
      // Header-Sichtbarkeit Compact überwachen (Überwachung class 'ba-hidden' an Header))
      this.observers.headerClass = new MutationObserver((mutations) => {
        mutations.forEach(mutation => {
          const mutationTarget = /** @type{HTMLElement} */ (mutation.target);
          if (mutation.oldValue !== mutationTarget.className) that.handleHeaderInteractions();
        });
      });
      this.observers.headerClass.observe(this.header, {
        attributes       : true,
        attributeFilter  : ['class'],
        attributeOldValue: true
      });
    } catch (e) {
      /* istanbul ignore next */
      console.log('MutationObserver nicht unterstützt, bitte Browser updaten.'); //NOSONAR
    }

    try {
      // SubHeader-Position überwachen Compact (Überwachung Überschneidung mit Viewport-Top / stickyness)
      this.observers.subHeaderCompact = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          that.handleIntersectionCompact(entry.intersectionRatio);
        });
      }, {
        rootMargin: -(this.headerHeight.compact + 1) + 'px 0px 0px 0px', // Höhe Header + 1px für Überschneidung
        threshold : [0.1, 0.5, 1]
      });
      this.observers.subHeaderCompact.observe(this.domEl);

      // SubHeader-Position überwachen Full (Überwachung Überschneidung mit Header)
      this.observers.subHeaderFull = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          that.handleIntersectionFull(entry.intersectionRatio < 1);
        });
      }, {
        rootMargin: -(this.headerHeight.full + 1) + 'px 0px 0px 0px', // Höhe Header + 1px für Überschneidung
        threshold : [1]
      });
      this.observers.subHeaderFull.observe(this.domEl);
    } catch (e) {
      /* istanbul ignore next */
      console.log('IntersectionObserver nicht unterstützt, bitte Browser updaten.'); //NOSONAR
    }
  }

  /**
   * Resize/Orientationchange-Handler
   */
  handleResize () {
    window.clearTimeout(this.resizeTO);
    this.resizeTO = window.setTimeout(() => {
      this.domEl.classList.remove('ba-sticky', 'ba-at-header');
      this.handleHeaderInteractions();
      this.observers.subHeaderCompact.unobserve(this.domEl);
      this.observers.subHeaderCompact.observe(this.domEl);
      this.observers.subHeaderFull.unobserve(this.domEl);
      this.observers.subHeaderFull.observe(this.domEl);
    }, 300);
  }

  /**
   * Handler für Y-Positionsänderung SubHeader Compact
   * @param {number} intersectionRatio - SubHeader Überschneidungsrate Header
   */
  handleIntersectionCompact (intersectionRatio) {
    if (this.isCompactHeader()) {
      this.setScrollPaddingTop();
      /* istanbul ignore next */
      const stickyRatio = document.documentElement.clientWidth < 576 ? 0.5 : 0.1;
      if (intersectionRatio < 1 && this.domEl.getBoundingClientRect().top < 60) {
        this.domEl.classList.add('ba-at-header');
        this.toggleHeaderShadow(false);
        this.closeFlyouts();
      } else {
        this.domEl.classList.remove('ba-at-header');
        this.toggleHeaderShadow(true);
      }
      if (intersectionRatio < stickyRatio) {
        this.domEl.classList.add('ba-sticky');
      } else {
        this.domEl.classList.remove('ba-sticky');
      }
    }
  }

  /**
   * Handler für Y-Positionsänderung SubHeader Full
   * @param {boolean} isIntersecting - SubHeader überschneidet Header
   */
  handleIntersectionFull (isIntersecting) {
    if (!this.isCompactHeader()) {
      if (isIntersecting) {
        document.addEventListener('scroll', this.scrollHandler, true);
        this.domEl.classList.add('ba-at-header');
        this.toggleHeaderShadow(false);
        this.closeFlyouts();
        this.handleHeaderInteractions();
      } else {
        document.removeEventListener('scroll', this.scrollHandler, true);
        this.domEl.classList.remove('ba-at-header');
        this.toggleHeaderShadow(true);
        this.header.style.transform = null;
      }
    }
  }

  /**
   * Interaktionen Header <-> SubHeader während Überschneidung
   */
  handleHeaderInteractions () {
    if (this.domEl && this.header.classList.contains('ba-at-subheader')) {
      if (this.isCompactHeader()) {
        const headerVisible = !this.header.classList.contains('ba-hidden');
        this.header.style.transform = null;
        this.domEl.classList.toggle('ba-header-visible', headerVisible);
      } else {
        const subHeaderTop = this.domEl.getBoundingClientRect().top;
        const newHeaderTop = Math.min(0, subHeaderTop - this.headerHeight.full);
        this.header.style.transform = 'translate3d(0, ' + Math.ceil(newHeaderTop) + 'px, 0)';
      }
    }
  }

  /**
   * Schatten des Headers ein/ausschalten, wenn SubHeader darunter/am Header ist
   * @param {boolean} show - Schatten an/aus
   */
  toggleHeaderShadow (show) {
    this.header.classList.toggle('ba-at-subheader', !show);
  }

  /**
   * Der Header ist compact, wenn die position auf 'fixed' gesetzt ist
   * @return {Boolean}
   */
  isCompactHeader () {
    return window.getComputedStyle(this.header).getPropertyValue('position') === 'fixed';
  }

  /**
   * Alle offenen Flyout-Menus und Collapsibles im Header schließen
   */
  closeFlyouts () {
    this.header.querySelectorAll('.show').forEach((elem) => {
      /* istanbul ignore next */
      if (elem && elem.bsCollapse) elem.bsCollapse.hide();
    });
  }

  /**
   * Abstand nach oben setzen für Scrollposition Seitenanker
   */
  setScrollPaddingTop () {
    document.documentElement.style.setProperty('--ba-mobile-scroll-padding-top', this.domEl.getBoundingClientRect().height > 70 ? this.scrollPaddingTop.subheaderLarge : this.scrollPaddingTop.subheaderSmall);
  }

  /**
   * Disconnect Observers
   */
  disconnect () {
    window.removeEventListener('resize', this.resizeHandler);
    document.removeEventListener('scroll', this.scrollHandler);
    document.documentElement.style.setProperty('--ba-mobile-scroll-padding-top', this.scrollPaddingTop.headerOnly);

    if (this.observers.headerClass) this.observers.headerClass.disconnect();
    if (this.observers.subHeaderFull) this.observers.subHeaderFull.disconnect();
    if (this.observers.subHeaderCompact) this.observers.subHeaderCompact.disconnect();

    if (this.header) {
      this.header.style.transform = null;
      this.header.classList.remove('ba-at-subheader');
    }

    this.domEl.classList.remove('ba-sticky', 'ba-at-header', 'ba-header-visible');
    this.domEl.removeAttribute('data-initialized');
  }
}

