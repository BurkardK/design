/**
 * BaGlobals
 * initialisiert Bootstrap, seitenübergreifende Funktionen und Patterns der DPL3
 */
export class BaGlobals {
    /**
     * Initialisiert Bootstrap, globale Funktionen und DPL Patterns
     */
    static init(): void;
    /**
     * Bootstrap JS-API als dpl.bs hinzufügen
     * Aufrufe der Bootstrap API-Calls damit statt bootstrap.Component -> dpl.bs.Component,
     * z.B. new bootstrap.Collapse(myCollapse) -> new dpl.bs.Collapse(myCollapse)
     */
    static setupBootstrap(): void;
    /**
     * Globale, seitenweite Funktionen einrichten und initialisieren
     */
    static setupGlobal(): void;
    /**
     * DPL3-Patterns einrichten und initialisieren
     */
    static setupPatterns(): void;
    static initPatterns(): void;
}
