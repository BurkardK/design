/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _dropdown.js */
/**
 * Pattern: Dropdown
 * erweitert Dropdown-Funktionalität
 * @constructor
 * @param {HTMLElement} element - Dropdown Pattern, default: .dropdown
 */
export class BaDropdown {
    constructor(element: any);
    domEl: any;
    /**
     * Fügt einen Event Handler hinzu, der den Fokus auf das aktive Element setzt
     */
    initFocus(): void;
}
