/**
 * Pattern: Typeahead
 * @constructor
 * @param {HTMLElement} element Pattern-Container
 * @param {Object} options Optionen
 */
export class BaTypeahead {
    constructor(element: any, options: any);
    domEl: any;
    currentActive: any;
    listOpen: boolean;
    suggestions: any;
    filteredSuggestions: any[];
    filteredSuggestionsCount: number;
    debounceTimeout: number;
    lastSearch: any;
    suggestionsFetchingCounter: number;
    appliedSuggestionsFetchingIndex: number;
    options: any;
    handlers: {
        keyupSearchField: any;
        clickDocument: any;
        keydownDocument: any;
    };
    searchField: any;
    suggestionList: any;
    /**
     * Initialisiert den Typeahead durch hinzufügen von keyup/keydown Event Handlern und
     * dem initialisieren der Live-Region
     */
    init(): void;
    /**
     * Entfernt die Typeahead-Funktionalität mit allen Handlern
     */
    destroy(): void;
    /**
     * Überschreibt die vorhandenen Optionen mit Einträgen aus options
     * @param {Object} options
     */
    setOptions(options: any): Promise<void>;
    /**
     * Maus-Handler für Document
     * @param {MouseEvent} e
     */
    onClickDocument(e: MouseEvent): void;
    /**
     * Tastatur-Handler für Document
     * @param {KeyboardEvent} e
     */
    onKeydownDocument(e: KeyboardEvent): void;
    /**
     * Tastatur-Handler für Input-Feld
     * @param {KeyboardEvent} e
     */
    onKeyupSearchField(e: KeyboardEvent): void;
    /**
     * Gibt die Sucheingabe zurück ohne überflüssige White-Spaces.
     */
    getNormalizedSearchFieldValue(): any;
    /**
     * Menü öffnen
     */
    openMenu(): void;
    /**
     * Menü schließen
     */
    closeMenu(): void;
    /**
     * Eintrag per Pfeiltasten aus Vorschlagsliste anwählen
     */
    selectListItem(): void;
    /**
     * Aktualisieren der Vorschläge
     * @returns false wenn abgebrochen
     */
    updateList(): Promise<boolean>;
    /**
     * Rendern der Vorschlagsliste
     */
    paintList(): void;
    /**
     * Ausgewählten Eintrag aus Liste als Input-Wert setzen
     */
    choice(): void;
    /**
     * Live-Region für Screenreader hinzufügen
     */
    addLiveRegion(): void;
    liveRegion: HTMLDivElement;
    /**
     * Screenreader neue Anzahl an Elementen vorlesen lassen
     */
    updateLiveRegion(): void;
    /**
     * Leeren der Live-Region
     */
    emptyLiveRegion(): void;
}
