/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _sitemap.js */
/**
 * DPL-Demo Sitemap
 * @constructor
 * @param {HTMLElement} Pattern-Container
 */
export class BaSitemap {

  constructor (element) {
    this.domEl = element;
    this.init();
    this.domEl.setAttribute('data-initialized', 'true');
  }

  /**
   * Initialisiere die Sitemap
   */
  init () {
    if (typeof navItems !== 'undefined') {
      this.generateTable().then((table) => {
        const links = document.querySelectorAll('a');
        links.forEach((elem) => {
          elem.addEventListener('click', (e) => {
            e.preventDefault();
            window.open((/** @type{HTMLLinkElement} */(e.target)).href, '_top');
          });
        });
        this.sortTable(table, 0, false);
      });
    }
  }

  /**
   * Generiert die Tabelle
   * @return {Promise}
   */
  generateTable () {
    return new Promise((resolve) => {
      setTimeout(() => {
        const patternList = document.getElementById('raw-pattern-list');
        let currentList;
        const patterns = ['global', 'navigation', 'content', 'forms', 'headerfooter'];
        const demos = ['demo', 'tests'];
        const external = [];
        const internal = ['redd'];
        const prototyping = ['prototyping'];

        for (let t = 0; t < navItems.patternGroups.length; t++) {  // Geht durch alle Pattern Typen der Hauptnavigation durch
          const patternGroup = navItems.patternGroups[t];
          if (patterns.indexOf(patternGroup.patternGroupLC) !== -1) { // Patterns
            currentList = 'patterns';
          } else if (demos.indexOf(patternGroup.patternGroupLC) !== -1) { // Demos
            currentList = 'demo';
          } else if (external.indexOf(patternGroup.patternGroupLC) !== -1) { // Extern
            currentList = 'external';
          } else if (internal.indexOf(patternGroup.patternGroupLC) !== -1) { // Intern
            currentList = 'internal';
          } else if (prototyping.indexOf(patternGroup.patternGroupLC) !== -1) { // Prototyping
            currentList = 'prototyping';
          } else {
            continue;
          }

          const liText = document.createTextNode(patternGroup.patternGroupUC);
          const level0Entry = document.createElement('li');
          level0Entry.appendChild(liText);
          const level0List = document.createElement('ul');

          for (let i = 0; i < patternGroup.patternGroupItems.length; i++) { // Geht durch alle Gruppen durch (Untermenüs)
            const patternGroupItem = patternGroup.patternGroupItems[i];
            if (patternGroupItem.patternSubgroupItems.length) { // Überprüfe ob es Patterns in der Gruppe gibt
              const level1EntryText = document.createTextNode(patternGroupItem.patternSubgroupUC);
              const level1Entry = document.createElement('li');
              level1Entry.appendChild(level1EntryText);
              const level1List = document.createElement('ul');

              for (let j = 0; j < patternGroupItem.patternSubgroupItems.length; j++) { // Geht durch alle Patterns in der Gruppe durch
                const patternSubgroupItem = patternGroupItem.patternSubgroupItems[j];
                if (patternSubgroupItem.patternPartial.indexOf('viewall-') === 0) continue;

                const level2Entry = document.createElement('li');
                const level2EntryLink = document.createElement('a');
                const level2EntryLinkHref = '../../?p=' + patternSubgroupItem.patternPartial;
                const level2EntryLinkText = document.createTextNode(patternSubgroupItem.patternName);
                level2EntryLink.setAttribute('href', level2EntryLinkHref);
                level2EntryLink.appendChild(level2EntryLinkText);
                level2Entry.appendChild(level2EntryLink);

                if ((currentList === 'patterns' || currentList === 'demo') && patternSubgroupItem.patternState) {
                  const level2EntrySpan = document.createElement('span');
                  const level2EntrySpanText = document.createTextNode(patternSubgroupItem.patternState);
                  level2EntrySpan.setAttribute('class', 'sg-pattern-state ' + patternSubgroupItem.patternState);
                  level2EntrySpan.appendChild(level2EntrySpanText);

                  level2Entry.appendChild(level2EntrySpan);
                }
                level1List.appendChild(level2Entry);

                const tableRaw = document.createElement('tr');

                const tableCellFirst = document.createElement('td');
                const tableCellFirstTextNode = document.createTextNode(patternSubgroupItem.patternName);
                tableCellFirst.appendChild(tableCellFirstTextNode);

                const tableCellSecond = document.createElement('td');
                const tableLinkUrl = '../../?p=' + patternSubgroupItem.patternPartial;
                const tableLinkText = patternGroup.patternGroupUC + ' / ' + patternGroupItem.patternSubgroupUC + ' / ' + patternSubgroupItem.patternName;
                const tableLinkTextNode = document.createTextNode(tableLinkText);
                const tableLink = document.createElement('a');
                tableLink.appendChild(tableLinkTextNode);
                tableCellSecond.appendChild(tableLink);

                tableRaw.appendChild(tableCellFirst);
                tableRaw.appendChild(tableCellSecond);

                tableLink.setAttribute('href', tableLinkUrl);
                patternList.appendChild(tableRaw);
              }
              level1Entry.appendChild(level1List);
              level0List.appendChild(level1Entry);
            }
          }

          for (let i = 0; i < patternGroup.patternItems.length; i++) { // loop all patterns
            const patternItem = patternGroup.patternItems[i];
            if (patternItem.patternPartial.indexOf('viewall-') === 0) continue;

            const level1Entry = document.createElement('li');
            const level1EntryLink = document.createElement('a');
            const level1EntryLinkUrl = '../../?p=' + patternItem.patternPartial;
            const level1EntryLinkTextNode = document.createTextNode(patternItem.patternName);
            level1EntryLink.setAttribute('href', level1EntryLinkUrl);
            level1EntryLink.appendChild(level1EntryLinkTextNode);
            level1Entry.appendChild(level1EntryLink);

            if ((currentList === 'patterns' || currentList === 'demo') && patternItem.patternState) {
              const level1EntrySpan = document.createElement('span');
              const level1EntrySpanText = document.createTextNode(patternItem.patternState);
              level1EntrySpan.setAttribute('class', 'sg-pattern-state ' + patternItem.patternState);
              level1EntrySpan.appendChild(level1EntrySpanText);
              level1Entry.appendChild(level1EntrySpan);
            }
            level0List.appendChild(level1Entry);

            const tr = document.createElement('tr');

            const firstCell = document.createElement('td');
            const firstCellTextNode = document.createTextNode(patternItem.patternName);
            firstCell.appendChild(firstCellTextNode);

            const secondCell = document.createElement('td');
            const secondCellLink = document.createElement('a');
            const secondCellLinkUrl = '../../?p=' + patternItem.patternPartial;
            const secondCellLinkTextnode = document.createTextNode(patternGroup.patternGroupUC + ' / ' + patternItem.patternName);
            secondCellLink.setAttribute('href', secondCellLinkUrl);
            secondCellLink.appendChild(secondCellLinkTextnode);
            secondCell.appendChild(secondCellLink);

            tr.append(firstCell, secondCell);
          }

          level0Entry.append(level0List);
          document.getElementById(currentList + '-list').append(level0Entry);
        }

        resolve(patternList);
      }, 1000);
    });
  }

  /**
   * Sortiert die Tabelle auf- oder absteigend
   * @param {HTMLElement} table
   * @param {string} col
   * @param {number} reverse
   */
  sortTable (table, col, reverse) {
    const tb = table, tr = Array.prototype.slice.call(tb.rows, 0); // Fügt die Zeilen in das Array ein
    let  i;
    reverse = -((+reverse) || -1);
    tr.sort(function (a, b) { // Sortiere die Zeilen
      return reverse // `-1 *` Falls die Sortierung umgedreht werden soll
        * (a.cells[col].textContent.trim() // Nutze `.textContent.trim()` für den Test
            .localeCompare(b.cells[col].textContent.trim()));
    });
    for (i = 0; i < tr.length; ++i) tb.appendChild(tr[i]); // Füge jede Zeile in der richtigen Reihenfolg hinzu
  }
}
