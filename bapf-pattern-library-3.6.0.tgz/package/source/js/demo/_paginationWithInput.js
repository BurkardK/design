/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _paginationWithInput.js */
/**
 * Demo-Implementierung Verhalten Seitennavigation (Pagination) mit Input
 * @constructor
 * @param {HTMLElement} Pattern-Container
 */
export class BaPaginationWithInput {
  constructor (paginationWithInput) {
    this.previousPage = paginationWithInput.querySelector('.ba-page-previous a');
    this.nextPage = paginationWithInput.querySelector('.ba-page-next a');
    this.pageCount = paginationWithInput.querySelector('.ba-page-active span:nth-child(3)').textContent.substr(5);
    this.inputField = paginationWithInput.querySelector('.ba-page-active input');
    this.init();
  }

  /**
   * Initialisiert die Seitennavigation
   */
  init () {
    this.setTitle();
    this.initEvents();
  }

  /**
   * Initialisiere Events
   */
  initEvents () {
    this.previousPage.addEventListener('click', (e) => {
      e.preventDefault();
      this.handleEvent('prev');
    });
    this.nextPage.addEventListener('click', (e) => {
      e.preventDefault();
      this.handleEvent('next');
    });
    this.inputField.addEventListener('keyup', (e) => {
      if (e.keyCode === 13) {
        e.preventDefault();
        this.handleEvent();
      }
    });
    this.inputField.addEventListener('focusout', (e) => {
      e.preventDefault();
      this.handleEvent();
    });
  }

  /**
   * Event-Handler
   * @param {string} trigger - Werte können 'prev' oder 'next' sein
   */
  handleEvent (trigger = '') {
    if (trigger === 'next') {
      this.inputField.value++;
    } else if (trigger === 'prev') {
      this.inputField.value--;
    }
    this.inputField.value = Number(this.inputField.value) >= Number(this.pageCount) ? Number(this.pageCount) : this.inputField.value;
    this.inputField.value = Number(this.inputField.value) <= 1 ? 1 : this.inputField.value;

    checkDisabled(this);

    function checkDisabled(that) {
      if (Number(that.inputField.value) > 1 && Number(that.inputField.value) < Number(that.pageCount)) {
        if (that.previousPage.closest('li').classList.contains('disabled')) {
          that.enableElem(that.previousPage);
        }
        if (that.nextPage.closest('li').classList.contains('disabled')) {
          that.enableElem(that.nextPage);
        }
      } else if (Number(that.inputField.value) === 1) {
        that.setDisabled(that.previousPage);
        if (that.nextPage.closest('li').classList.contains('disabled')) {
          that.enableElem(that.nextPage);
        }
      } else if (Number(that.inputField.value) === Number(that.pageCount)) {
        that.setDisabled(that.nextPage);
        if (that.previousPage.closest('li').classList.contains('disabled')) {
          that.enableElem(that.previousPage);
        }
      }
    }

    this.setTitle();
  }

  /**
   * Sperrt die Pfeil-Buttons auf der ersten oder letzten Seite
   * @param {HTMLElement} elem
   */
  setDisabled (elem) {
    elem.closest('li').classList.add('disabled');
    elem.setAttribute('tabindex', '-1');
    elem.setAttribute('aria-disabled', 'true');
  }

  /**
   * Aktiviert die Pfeil-Buttons
   * @param {HTMLElement} elem
   */
  enableElem (elem) {
    elem.closest('li').classList.remove('disabled');
    elem.removeAttribute('aria-disabled');
    elem.removeAttribute('tabindex');
  }

  /**
   * Setzt die Titel und das aria-label
   */
  setTitle () {
    const titleTextNext = `Nächste Seite (${Number(this.inputField.value) + 1})`;
    const titleTextPrev = `Vorherige Seite (${Number(this.inputField.value) - 1})`;
    const textAriaLabeInput = `Aktuelle Seite (${Number(this.inputField.value)})`;
    this.inputField.setAttribute('aria-label', textAriaLabeInput);
    if ((Number(this.inputField.value) + 1) <= this.pageCount) {
      this.nextPage.setAttribute('title', titleTextNext);
      this.nextPage.setAttribute('aria-label', titleTextNext);
    }
    if ((Number(this.inputField.value) - 1) >= 1) {
      this.previousPage.setAttribute('title', titleTextPrev);
      this.previousPage.setAttribute('aria-label', titleTextPrev);
    }
  }

}
