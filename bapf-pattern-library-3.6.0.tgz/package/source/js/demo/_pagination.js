/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _pagination.js */
/**
 * Demo-Implementierung Verhalten Seitennavigation (Pagination)
 * @constructor
 * @param {HTMLElement} Pattern-Container
 */
export class BaPagination {
  constructor (el) {

    this.pagination = el;
    this.pagesElements = [];
    this.pagination.querySelectorAll('li:not([class]) a').forEach((elem) => {
      this.pagesElements.push(elem.parentNode);
    });
    this.controls = {
      first        : this.pagination.querySelector('.ba-page-first'),
      previous     : this.pagination.querySelector('.ba-page-previous'),
      previousGroup: this.pagination.querySelector('.ba-page-previous-group'),
      page         : this.pagesElements,
      active       : this.pagination.querySelector('.ba-page-active'),
      nextGroup    : this.pagination.querySelector('.ba-page-next-group'),
      next         : this.pagination.querySelector('.ba-page-next'),
      last         : this.pagination.querySelector('.ba-page-last'),
    };
    this.totalPages = this.parsePageByElem(this.controls.next.previousElementSibling.querySelector('a')) || 7;  // 12 war davor           // Gesamtzahl Seiten
    this.currentPage = this.parsePageByElem(this.pagination.querySelector('.ba-page-active > span')) || 1;  // Aktuelle Seite
    /* istanbul ignore next */
    if (this.currentPage > this.totalPages) this.currentPage = 1;
    this.dotLimit = 7;         // Anzahl Seiten, die noch alle angezeigt werden, bevor ... aktiviert werden
    this.pagesBeforeDot = 3;   // Anzahl Seiten am Anfang und Ende, bevor ... eingefügt wird
    this.pagination.setAttribute('data-initialized', 'true');
    this.initEvents();
  }

  /**
   * Sucht nach page NUmmer im 'li' Element
   * @param {HTMLElement} element
   * @return {number|null}
   */
  parsePageByElem (element) {
    const arrNummer = element.textContent.match(/\d+/);
    return arrNummer ? parseInt(arrNummer[0]) : null;
  }

  /**
   * Initialisieren von Events
   */
  initEvents () {
    // Klickhandler für alle Controls initialisieren
    for (const control in this.controls) {
      /* istanbul ignore else babel-plugin-istanbul bug #186 */
      if (control) this.setEventToElem(control);
    }
    window.addEventListener('resize', () => {
      this.render();
    });
    this.render();
  }

  /**
   * Set Click-Event
   * @param {string} controlName - Object keys
   */
  setEventToElem (controlName) {
    if (controlName === 'page') {
      this.controls[controlName].forEach((elem) => {
        elem.addEventListener('click', (e) => {
          e.preventDefault();
          this.handleClick(controlName, e);
        });
      });
    } else {
      this.controls[controlName].addEventListener('click', (e) => {
        e.preventDefault();
        this.handleClick(controlName, e);
      });
    }
  }

  /**
   * Click-Event Handler
   * @param {string} page - Object keys
   * @param {Event} e - Click-Event
   */
  handleClick (page, /**Event*/e) {
    e.preventDefault();
    const clossetLi = (/** @type{HTMLElement} */(e.target)).closest('li');
    if (clossetLi.classList.contains('disabled')) return;

    switch (page) {
      case 'first':
        this.currentPage = 1;
        break;
      case 'previous':
        this.currentPage -= 1;
        break;
      case 'previousGroup':
        this.currentPage -= 3;
        break;
      case 'page':
        this.currentPage = this.parsePageByElem(clossetLi);
        break;
      case 'nextGroup':
        this.currentPage += 3;
        break;
      case 'next':
        this.currentPage += 1;
        break;
      case 'last':
        this.currentPage = this.totalPages;
        break;
      /* istanbul ignore next */
      default: return;
    }
    this.render();
  }

  /**
   * Pagination berechnen und ausgeben
   */
  render () {
    const paginator = document.createElement('ul');

    // mobile first
    this.setDisabled(this.controls.first, this.currentPage === 1);

    paginator.appendChild(this.controls.first);

    // previous
    this.setDisabled(this.controls.previous, this.currentPage === 1);
    this.setTitle(this.controls.previous, 'Vorherige Seite' + ((this.currentPage === 1) ? '' : ' (' + (this.currentPage - 1) + ')'));
    paginator.appendChild(this.controls.previous);

    // first
    paginator.appendChild(this.getPageButton(1, 'Erste Seite'));

    // previous [...] Gruppe
    paginator.appendChild(this.controls.previousGroup);
    if ((this.currentPage <= this.pagesBeforeDot || this.totalPages <= this.dotLimit) || (document.body.clientWidth <= 575)) {
      this.controls.previousGroup.style.display = 'none';
    } else {
      this.controls.previousGroup.style.display = 'flex';
    }

    // Seitenbuttons
    addPageButtons(this);

    // next [...] Gruppe
    paginator.appendChild(this.controls.nextGroup);
    ((this.currentPage > (this.totalPages - this.pagesBeforeDot) || this.totalPages <= this.dotLimit) || (document.body.clientWidth <= 575)) ? this.controls.nextGroup.style.display = 'none' : this.controls.nextGroup.style.display = 'flex'; //NOSONAR

    // last
    paginator.appendChild(this.getPageButton(this.totalPages, 'Letzte Seite ' + this.totalPages));

    // next
    this.setDisabled(this.controls.next, this.currentPage === this.totalPages);
    this.setTitle(this.controls.next, 'Nächste Seite' + ((this.currentPage === this.totalPages) ? '' : ' (' + (this.currentPage + 1) + ')'));
    paginator.appendChild(this.controls.next);

    // mobile last
    this.setDisabled(this.controls.last, this.currentPage === this.totalPages);
    paginator.appendChild(this.controls.last);

    // neuen Zustand ausgeben
    while (this.pagination.firstChild) this.pagination.removeChild(this.pagination.firstChild);
    this.pagination.appendChild(paginator);

    function addPageButtons(that) {
      if (that.totalPages <= that.dotLimit) { // wenn im Limit, alle anzeigen, keine [...]
        for (let i = 2; i < that.totalPages; i++) {
          paginator.appendChild(that.getPageButton(i));
        }
      } else { // wenn über Limit, [...] anzeigen
        if (that.currentPage <= that.pagesBeforeDot) {
          for (let i = 2; i <= that.pagesBeforeDot; i++) {
            paginator.appendChild(that.getPageButton(i));
          }
        }
        if (that.currentPage > that.pagesBeforeDot && that.currentPage <= (that.totalPages - that.pagesBeforeDot)) {
          for (let i = that.currentPage - 1; i <= that.currentPage + 1; i++) {
            paginator.appendChild(that.getPageButton(i));
          }
        }
        if (that.currentPage > (that.totalPages - that.pagesBeforeDot)) {
          for (let i = that.totalPages - that.pagesBeforeDot + 1; i < that.totalPages; i++) {
            paginator.appendChild(that.getPageButton(i));
          }
        }
      }
    }
  }

  /**
   * Element de/aktivieren
   * @param {HTMLElement} el
   * @param {boolean} on
   */
  setDisabled (el, on) {
    if (on) {
      el.classList.add('disabled');
      el.querySelector('a').setAttribute('aria-disabled', 'true');
      el.setAttribute('tabindex', '-1');
      el.querySelector('a').setAttribute('tabindex', '-1');
    } else {
      el.classList.remove('disabled');
      el.querySelector('a').removeAttribute('aria-disabled');
      el.removeAttribute('tabindex');
      el.querySelector('a').removeAttribute('tabindex');
    }
  }

  /**
   * Titel und Aria-Attribut setzen
   * @param {HTMLElement} el
   * @param {string} title - Text für title-attribute
   */
  setTitle (el, title) {
    const button = el.classList.contains('ba-page-active') ? el.querySelector('span') : el.querySelector('a');
    if (title) {
      button.setAttribute('title', title);
      button.setAttribute('aria-label', title);
      if (button.classList.contains('sr-only')) {
        button.textContent = title;
      }
    }
    // This code is unused!
    else {
      button.removeAttribute('title');
      button.removeAttribute('aria-label');
    }
  }

  /**
   * Rendert den Standard-Page-Button und gibt ihn zurück
   * @param {number} page
   * @param {string} title
   * @return {HTMLElement}
   */
  getPageButton (page, title='') {
    let pageButton, pageButtonInner;

    if (page === this.currentPage) {
      pageButton = this.controls.active;
      pageButtonInner = pageButton.querySelectorAll('span')[1];
      pageButtonInner.textContent = page;
      pageButton.querySelectorAll('span')[2].textContent = ' von ' + this.totalPages  + ' Seiten';
      this.setTitle(pageButton, title ? title + ' (aktuelle Seite)' : 'Seite ' + page + ' (aktuelle Seite)');
    } else {
      /* istanbul ignore else babel-plugin-istanbul bug #186 */
      if (this.controls.page[0] && this.controls.page.length > 0) {
        pageButton = (/** @type{HTMLElement} */(this.controls.page[0])).cloneNode(true);
        (/** @type{HTMLElement} */(pageButton)).querySelector('a').textContent = page.toString();
        pageButton.addEventListener('click', (e) => {
          e.preventDefault();
          this.handleClick('page', e);
        });
      }
      this.setTitle(/** @type{HTMLElement} */(pageButton), title ? title : 'Seite ' + page);
    }

    return pageButton;
  }

}
