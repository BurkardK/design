/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _datePicker.js */
/**
 * Demo-Implementierung Datepicker
 * @constructor
 * @param {HTMLElement} Pattern-Container
 */
export class BaDatePicker {

  constructor (element) {
    this.domEl = element;
    this.input = this.domEl.querySelector('.form-control');
    this.toggleButton = {
      el: this.domEl.querySelector('button.ba-icon-datepicker'),
      labels: {
        show: 'Kalender öffnen',
        hide: 'Kalender schließen'
      }
    };

    const dp = /** @type {Object} */ (new DatePickerView(this.input, this.toggleButton, new DatePicker()));
    this.domEl.setAttribute('data-initialized', 'true');

    return dp;
  }
}

//-----------------------------------------------------
//       _datepicker View
//-----------------------------------------------------
/**
 * _datepicker View, kontrolliert die User-Interaktionen und rendered den _datepicker
 * @constructor
 * @param {HTMLElement} inputField Input Element an das der Datepicker angehängt wird und den Rohwert des ausgewählten Datums enthält
 * @param {HTMLElement} toggleButton Button, welcher den Datepicker Dialog öffnet/schließt
 * @param {DatePicker} datePicker Enthält die Datepicker Instanz, welche sich um die Logik kümmert
 */
class DatePickerView {

  constructor (inputField, toggleButton, datePicker) {

    this.dp = datePicker;
    /* istanbul ignore next */
    this.locale = window.navigator['userLanguage'] || window.navigator.language || 'de-DE';

    this.visible = false;
    this.toggleButton = toggleButton.el;
    this.toggleLabels = toggleButton.labels;
    this.inputField = inputField;

    this.id = this.inputField.getAttribute('id') ? this.inputField.getAttribute('id').toString() : 'datepicker-' + Math.floor(Math.random() * 100000);
    this.template = this.getHtmlTemplate();

    const input = this.inputField.closest('.input-group');
    input.insertAdjacentHTML('afterend', this.getDpHtml());

    this.dpFull = input.closest('.ba-date-picker').querySelector('.ba-datepicker');

    this.title = this.dpFull.querySelector('.dp-month');
    this.prevY = this.dpFull.querySelector('.dp-year-prev');
    this.prevM = this.dpFull.querySelector('.dp-month-prev');
    this.nextM = this.dpFull.querySelector('.dp-month-next');
    this.nextY = this.dpFull.querySelector('.dp-year-next');
    this.grid = this.dpFull.querySelector('.dp-grid');

    this.render();
    this.bindHandlers();
    this.hide();
  }

  /**
   * Generiert und updated das Datepicker HTML
   */
  render () {
    this.updateNavLabels();
    this.updateGrid();

    // Zeig das momentan ausgewählte Jahr und den Monat an
    const title = this.getMonthName(this.dp.focus) + ' ' + this.dp.focus.getFullYear();
    this.setHtmlTitle(title);
    this.fillInput(this.dp.selected);
  }

  /**
   * Updated das Grid und ersetzt das alte HTML mit dem Neuem
   */
  updateGrid () {
    // Bereinigt das HTML Grid
    const grid = this.grid.querySelector('tbody');
    while (grid.firstChild) {
      grid.removeChild(grid.firstChild);
    }

    let gridCells = '';
    for (var i = 0; i < this.dp.weeks.length; i++) {
      const week = this.dp.weeks[i];
      gridCells += this.createRowHtml(week);
    }

    // Füllt das Grid mit den neuen Zellen
    this.grid.querySelector('tbody').insertAdjacentHTML('beforeend', gridCells);

    // Updated das activedescendant Attribut mit der momentan ausgewählten Zellen-ID
    this.grid.setAttribute('aria-activedescendant', this.createDayCellHtmlId(this.dp.focus));
  }

  /**
   * Updated den Titel und die Navigationsbuttons (Jahr und Monat)
   */
  updateNavLabels () {
    const thisObj = this;
    changeLabel(this.prevY, changeYear(-1));
    changeLabel(this.prevM, changeMonth(-1));
    changeLabel(this.nextM, changeMonth(+1));
    changeLabel(this.nextY, changeYear(+1));

    function changeYear (amount) {
      return thisObj.dp.focus.getFullYear() + amount;
    }

    function changeMonth (amount) {
      const date = new Date(thisObj.dp.focus);
      date.setDate(1);
      date.setMonth(date.getMonth() + amount);
      return thisObj.getMonthName(date) + ' ' + date.getFullYear();
    }

    function changeLabel (/**HTMLElement*/elem, /**string*/newText) {
      const text = elem.getAttribute('title');
      const resultText = text.replace(/\(.+\)/, '(' + newText + ')');
      elem.setAttribute('title', resultText);
    }
  }

  /**
   * Generiert den HTML Code des Headers des Grids
   * @return {string}
   */
  createGridHeaderHtml () {
    const result = document.createElement('tr');
    result.classList.add('dp-weekdays');
    for (let i = 0; i < 7; i++) {
      const day = (this.dp.firstDayOfWeek + i) % 7;
      result.appendChild(this.createWeekDayColumn(day));
    }
    return result.outerHTML;
  }

  /**
   * Generiert das HTMLElement, welches die Kopfzeile der Woche enthält
   * @param {number} weekDay 0-6 Sonntag bis Samstag
   * @return {HTMLElement} <th> Element
   */
  createWeekDayColumn (weekDay) {
    const date = new Date();
    const dayNow = date.getDay();
    date.setDate(date.getDate() + (7 - dayNow) + weekDay);

    const dayName = this.getWeekdayName(date);
    const dayNameShort = this.getShortWeekdayName(date);

    const column = document.createElement('th');
    column.setAttribute('id', this.createHeaderId(weekDay));
    column.setAttribute('scope', 'col');

    const nvda = document.createElement('div');
    nvda.setAttribute('class', 'sr-only');
    nvda.setAttribute('aria-live', 'off');
    nvda.textContent = dayName;

    const abbr = document.createElement('abbr');
    abbr.setAttribute('title', dayName);
    abbr.setAttribute('aria-hidden', 'true');
    abbr.textContent = dayNameShort;

    column.appendChild(nvda);
    column.appendChild(abbr);
    return column;
  }

  /**
   * Generiert die Zeile für eine Woche
   * @param {Week} weekObj
   * @return {string} <tr> HTML
   */
  createRowHtml (weekObj) {
    let rowHtml = '<tr role="row" id="' + this.createRowHtmlId(weekObj) + '">';
    for (let dateIdx = 0; dateIdx < weekObj.dates.length; dateIdx++) {
      const date = weekObj.dates[dateIdx];
      rowHtml += this.createCellHtml(date);
    }
    rowHtml += '</tr>';
    return rowHtml;
  }

  /**
   * Generiert das HTML für eine Zelle pro Datum
   * @param {Date} date
   * @return {string} <td> HTML
   */
  createCellHtml (date) {
    const isSelected = this.dp.isSelected(date);
    const hasFocus = this.dp.hasFocus(date);
    const isToday = this.dp.isToday(date);
    const isAnotherMonth = this.dp.isAnotherMonth(date);
    const isDisabled = this.dp.isDisabled(date);

    const dayName = this.getWeekdayName(date);
    const label = this.createDateLabel(date, isDisabled, isToday, isSelected);
    const classes = this.createDateClasses(hasFocus, isDisabled || isAnotherMonth, isToday, isSelected);

    const ariaSelected = hasFocus; // aria-selected ist für den aktuellen focus, nicht das ausgewählte Datum
    const ariaHidden = isDisabled;
    const dateNr = date.getDate();

    return `
<td id="${this.createDayCellHtmlId(date)}" class="${classes}" tabindex="-1" role="gridcell" aria-selected="${ariaSelected}" data-value="${dateNr}" ${ariaHidden ? 'aria-readonly="true"' : ''}>
 <div class="sr-only" role="button" aria-label="${label}" aria-live="off"></div>
 <div data-value="${dateNr}" title="${dayName} ${label}" aria-hidden="true">${dateNr}</div>
</td>`;
  }

  /**
   * Generiert das Label für eine Datumszelle
   * @param {Date} date
   * @param {boolean} isDisabled
   * @param {boolean} isToday
   * @param {boolean} isSelected
   * @return {string} Date-Label
   */
  createDateLabel (date, isDisabled, isToday, isSelected) {
    const dateText = this.getLocaleString(date, {
      day  : 'numeric',
      month: 'long',
      year : 'numeric'
    });
    const infoText = [];
    if (isDisabled) infoText.push('nicht auswählbar');
    if (isToday) infoText.push('heute');
    if (isSelected) infoText.push('ausgewählt');
    return `${dateText} ${infoText.length ? '(' + infoText.join(', ') + ')' : ''}`;
  }

  /**
   * Generiert die CSS-Klassen for eine Datumszelle
   * @param {boolean} hasFocus
   * @param {boolean} isDisabled
   * @param {boolean} isToday
   * @param {boolean} isSelected
   * @return {string} CSS-Klassen
   */
  createDateClasses (hasFocus, isDisabled, isToday, isSelected) {
    let classText = 'day';
    if (hasFocus) classText += ' focus';
    if (isDisabled) classText += ' disabled';
    if (isToday) classText += ' today';
    if (isSelected) classText += ' selected';
    return classText;
  }

  /**
   * Generiert das Datum einer Zelle
   * @param {*} date
   * @return {string} Datumsformat, z.B.: 'day4-month5-id'
   */
  createDayCellHtmlId (/**Date*/date) {
    /* istanbul ignore next */
    if (!date) return '';
    return 'day' + date.getDate() + '-' + 'month' + (date.getMonth() + 1) + '-' + this.id;
  }

  /**
   * Generiert die id für eine Wochenzeile
   * @param {Week} week
   * @return {string}
   */
  createRowHtmlId (/**Week*/week) {
    /* istanbul ignore next */
    if (!week) return '';
    return 'row' + week.id + '-' + this.id;
  }

  /**
   * Generiert die id für die Headerzeile
   * @param {string} weekDay
   * @return {string}
   */
  createHeaderId (weekDay) {
    return 'day' + weekDay + '-header-' + this.id;
  }

  /**
   * Extrahiert das Datum einer Zelle aus dem HTMLEelement und gibt es als String zurück
   * @param {HTMLElement} dayCell
   * @return {string}
   */
  getDateByViewCell (dayCell) {
    const dayNr = (dayCell).getAttribute('data-value');
    return new Date(this.dp.focus.getFullYear(), this.dp.focus.getMonth(), dayNr);
  }

  /**
   * Updated den Titel des Datepicker
   * @param {string} titleString
   */
  setHtmlTitle (titleString) {
    this.title.textContent = titleString;
  }

  /**
   * Lokalisiert das gegebene Datum und updated das Value des Input Feldes damit
   * @param {Date} date date to fill
   */
  fillInput (date) {
    if (date) {
      this.inputField.value = this.getLocaleString(date, {
        day  : '2-digit',
        month: '2-digit',
        year : 'numeric'
      });
    }
  }

  /**
   * Lokalisiert das Datum und entfernt das Sonderzeichen u200e (LTR), welches in IE11 zu einem Problem führt
   * @param {Date} date
   * @param {Object} options Siehe Date.toLocaleString
   * @return {string} Lokalisiertes Datum mit IE11 bug fix
   */
  getLocaleString (date, options) {
    return date.toLocaleString(this.locale, options)
      .replace(/\u200E/g, ''); // Siehe: https://stackoverflow.com/a/36015664/2519073
  }

  /**
   * Gibt das Datum des Input Feldes as Date Instanz oder null im Fehlerfall zurück
   * @return {Date|null}
   */
  readFromInput () {
    const text = this.inputField.value;
    return this.parseDate(text);
  }

  /**
   * Konvertiert den gegebenen dateString zu einer Date Instanz. Gibt null im Fehlerfall zurück
   * @param {string} dateString
   * @return {Date|null}
   */
  parseDate (dateString) {
    // Einfacher Parser für das deutsche Datumsformat.
    const regex = /(\d{2})[^\d](\d{2})[^\d](\d{4})/;
    const result = regex.exec(dateString);
    if (!result || result.length !== 4) return null;
    // Jahr, Monat, Tag
    return new Date(Number(result[3]), Number(result[2]) - 1, Number(result[1]));
  }

  /**
   * Gibt den lokalisierten Namen des Wochentags des gegebenen Datums zurück
   * @param {Date} date
   * @return {string}
   */
  getWeekdayName (date) {
    return this.getLocaleString(date, { weekday: 'long' });
  }

  /**
   * Returns the localized, shortened weekday name of the given date
   * Gibt den lokalisierten, verkürzten Namen (z.B. 'Mo', 'Di', 'Mi', ...) des
   * Wochentags des gegebenen Datums zurück
   * @param {Date} date
   * @return {string}
   */
  getShortWeekdayName (date) {
    return this.getLocaleString(date, { weekday: 'short' });
  }

  /**
   * Gibt den lokalisierten Namen des Monats des gegebenen Datums zurück
   * @param {Date} date
   * @return {string} month long name, depends on current locale
   */
  getMonthName (date) {
    return this.getLocaleString(date, { month: 'long' });
  }

  /**
   * Fügt mehrere Event Handler hinzu (Tastatur- und Mausnavigation), die die
   * Interaktion mit dem Datepicker ermöglichen.
   */
  bindHandlers () {
    const thisObj = this;
    const dp = this.dp;
    const hh = new HotkeyHandler(dp, this.render.bind(this));

    // Toggle Button
    hh.setAction(this.toggleButton, this.toggle.bind(this));

    // Klick, Enter, Leertaste
    hh.setAction(this.prevM, dp.setPrevMonth);
    hh.setAction(this.prevY, dp.setPrevYear);
    hh.setAction(this.nextM, dp.setNextMonth);
    hh.setAction(this.nextY, dp.setNextYear);

    // Funktioniert auf jedem dp Element
    hh.setOnTree('pageup', this.dpFull, dp.setPrevMonth);
    hh.setOnTree('pagedown', this.dpFull, dp.setNextMonth);
    hh.setOnTree('shift+pageup', this.dpFull, dp.setPrevYear);
    hh.setOnTree('shift+pagedown', this.dpFull, dp.setNextYear);

    // Navigation innerhalb des Grids
    hh.setOn('left', this.grid, dp.setPrevDay);
    hh.setOn('right', this.grid, dp.setNextDay);
    hh.setOn('up', this.grid, dp.setPrevWeek);
    hh.setOn('down', this.grid, dp.setNextWeek);
    hh.setOn('shift+up', this.grid, dp.setPrevMonth);
    hh.setOn('shift+down', this.grid, dp.setNextMonth);

    // Nur Tage, die nicht deaktiviert sind, dürfen klickbar sein
    hh.setOn('click', this.grid, 'td.day:not(.disabled):not(.other)>div', selectClickedDate);
    hh.setOn('space', this.grid, selectFocusedDate);
    hh.setOn('enter', this.grid, selectFocusedDate);

    // Focus-out muss manuell getriggered werden, da die auf den Target Focus warten müssen.
    hh.setOn('shift+tab', this.prevY, focusOnLastElement); // shift+tab um das letzte Element zu fokusieren
    hh.setOn('tab', this.grid, focusOnFirstElement); // tab um das erste Element zu fokusieren
    hh.setOnTree('esc', this.dpFull, focusToggleButtonAndClose);

    /* istanbul ignore next */
    function focusToggleButtonAndClose (e) {
      e.preventDefault(); // Kein weiterer Tab
      thisObj.toggleButton.focus();
      thisObj.hide();
    }

    /* istanbul ignore next */
    function focusOnFirstElement (e) {
      e.preventDefault(); // Kein weiterer Tab
      thisObj.prevY.focus();
    }

    /* istanbul ignore next */
    function focusOnLastElement () {
      thisObj.grid.querySelector('.focus').focus();
    }

    function selectClickedDate (e) {
      const clickedDate = thisObj.getDateByViewCell(e.target);
      dp.setFocus(clickedDate);
      selectFocusedDate(e);
    }

    function selectFocusedDate (e) {
      e.preventDefault(); // Keine weitere Leertaste/Enter bei einem Input
      if (dp.isDisabled(dp.focus)) return;

      thisObj.select(dp.focus);
      thisObj.hide();
      thisObj.inputField.focus();
    }
  }

  /**
   * Wählt das gegebene Datum aus
   * @param {Date} date
   */
  select (date) {
    this.dp.setSelected(date);
    this.fillInput(this.dp.selected);
  }

  /**
   * Zeigt den Datepicker an
   */
  show () {
    this.visible = true;
    // Zeigt den Dialog
    this.dpFull.setAttribute('aria-hidden', 'false');
    this.toggleButton.setAttribute('title', this.toggleLabels.hide);
    this.toggleButton.setAttribute('aria-label', this.toggleLabels.hide);
    const inputValue = this.readFromInput();
    // Wenn der Input Wert leer ist, nutze den heutigen Tag
    this.dp.setFocus(inputValue || new Date());
    this.dp.setSelected(inputValue);
    this.render();
    this.prevY.focus();
    this.enableCloseOnFocusOut();
  }

  /**
   * Versteckt das Popup und fokusiert das Input Element
   */
  hide () {
    this.visible = false;
    // Versteckt den Dialog. Im CSS wird display: none; gesetzt
    this.dpFull.setAttribute('aria-hidden', 'true');
    this.toggleButton.setAttribute('title', this.toggleLabels.show);
    this.toggleButton.setAttribute('aria-label', this.toggleLabels.show);
    this.disableCloseOnFocusOut();
  }

  /**
   * Versteckt das Datepicker Popup wenn es sichtbar ist und zeigt es ansonsten an
   */
  toggle () {
    this.visible ? this.hide() : this.show();
  }

  /**
   * Fügt einen Event Handler hinzu der den Datepicker schließt, wenn der Nutzer außerhalb des Grids klickt
   */
  enableCloseOnFocusOut () {
    const thisObj = this;

    // Der Click Handler muss für diese Instanz generiert werden und darf nicht mit anderen Datepicker Instanzen geteilt werden
    thisObj.hideIfClickOther = function (e) {
      if (!thisObj.dpFull.contains(e.target) && thisObj.dpFull !== e.target) {
        thisObj.hide();
      }
    };

    // Warte zuerst auf Event Bubbling bevor der Click Handler registriert werden kann
    setTimeout(function () {
      document.addEventListener('click', thisObj.hideIfClickOther);
    }, 10);
  }

  /**
   * Entfernt den Event Handler wenn der Nutzer außerhalb des Datepickers klickt
   */
  disableCloseOnFocusOut () {
    if (typeof this.hideIfClickOther === 'function') document.removeEventListener('click', this.hideIfClickOther);
  }

  /**
   * Gibt das HTML Template für den Datepicker zurück
   * @return {string}
   */
  getHtmlTemplate () {
    const description = 'Bedienung mittels Tab und Umschalt-Tab und Pfeiltasten. Tag auswählen: Eingabetaste. Schließen der Datumsauswahl: Escapetaste.';
    return `
<div id="datepickerDialog-CALENDARID" class="ba-datepicker" aria-label="Datumsauswahl" aria-modal="true" role="dialog" aria-hidden="true" aria-describedby="datepickerDescription-CALENDARID">

  <label id="datepickerDescription-CALENDARID" class="sr-only">${description}</label>

  <div class="dp-month-wrap">
    <div class="dp-year-prev" role="button" aria-controls="CURRENT_MONTH" title="Vorheriges Jahr (YEAR-1)" tabindex="0" aria-describedby="prevYear-CALENDARID"></div>
    <label id="prevYear-CALENDARID" class="sr-only">Schnelltaste: Umschalt + Bild auf</label>

    <div class="dp-month-prev" role="button" aria-controls="CURRENT_MONTH" title="Vorheriger Monat (MONTH-1 YEAR)" tabindex="0" aria-describedby="prevMonth-CALENDARID"></div>
    <label id="prevMonth-CALENDARID" class="sr-only">Schnelltaste: Bild auf</label>

    <div role="region" id="CURRENT_MONTH" aria-live="polite" class="dp-month">TITLE</div>

    <div class="dp-month-next" role="button" aria-controls="CURRENT_MONTH" title="Nächster Monat (MONTH+1 YEAR)" tabindex="0" aria-describedby="nextMonth-CALENDARID"></div>
    <label id="nextMonth-CALENDARID" class="sr-only">Schnelltaste: Bild ab</label>

    <div class="dp-year-next" role="button" aria-controls="CURRENT_MONTH" title="Nächstes Jahr (YEAR+1)" tabindex="0" aria-describedby="nextYear-CALENDARID"></div>
    <label id="nextYear-CALENDARID" class="sr-only">Schnelltaste: Umschalt + Bild ab</label>
  </div>

  <table class="dp-grid" role="grid" aria-readonly="true" aria-label="Kalender" aria-activedescendant="dp-err-msg-CALENDARID" tabindex="0">
    <thead>
      ${this.createGridHeaderHtml()}
    </thead>
    <tbody>
      <tr><td id="dp-err-msg-CALENDARID" colspan="7">JavaScript muss aktiviert sein.</td></tr>
    </tbody>
  </table>

</div>`;
  }

  /**
   * Fügt die ID des Kalendars in das HTML Template ein.
   * @see https://developer.mozilla.org/en-US/docs/Web/API/Element/insertAdjacentHTML
   * @return {string}
   */
  getDpHtml () {
    return this.getHtmlTemplate().replace(/CALENDARID/g, this.id).replace(/CURRENT_MONTH/g, `dp-month-${this.id}`);
  }
}

/**
 * Datepicker Business Logi
 * @constructor
 * @param {Object} [options]
 */
class DatePicker {
  constructor (options) {
    /* istanbul ignore next */
    this.firstDayOfWeek = (options && options.firstDayOfWeek) || 1; // Montag

    /**@type Week[]*/
    this.weeks = [];

    /**@type Date*/
    this.today = this.createDateOnly(); // Muss angepasst werden, falls der Nutzer das Feature über 0:00 Uhr hinweg bedient

    /**@type Date*/
    this.focus = null;
    this.setFocus(this.today);

    /**@type Date*/
    this.selected = null;
    this.setSelected(null);
  }

  /**
   * Setzt den Fokus des Datepickers auf das gegebene Datum
   * @param {Date} date
   */
  setFocus (/**Date*/date) {
    this.focus = (date) ? this.createDateOnly(date) : null;
    this.fillDates(this.focus);
  }

  /**
   * Wählt das gegeben Datum aus
   * @param {Date} date
   */
  setSelected (/**Date*/date) {
    if (this.isDisabled(date)) {
      return;
    }
    this.selected = date ? this.createDateOnly(date) : null;
  }

  /**
   * Füllt das Grid mit allen Tagen des Monats
   * @param {null|Date} referenceDate
   */
  fillDates (/**Date*/referenceDate) {
    if (!referenceDate) return;

    const firstDate = new Date(referenceDate);
    firstDate.setDate(1);
    const weekDay = firstDate.getDay();
    // Offset (= firstDayOfWeek) hängt von dem ersten Tag im Grid ab und ist gewöhnlicherweise negativ
    // vom vorherigen Monat. setDate(1) ist der erste Tag, setDate(-1) bedeutet, dass der Tag vom vorherigen Monat
    // genommen wird
    const position = (weekDay - this.firstDayOfWeek + 7) % 7;
    const startFromDay = 1 - position;

    const lastDay = this.getLastDayInMonth(firstDate);
    let counter = 0;
    this.weeks = [];
    for (let i = startFromDay; i <= lastDay; i += 7) {
      const date = new Date(firstDate);
      date.setDate(i);
      const week = new Week(date, counter++);
      this.weeks.push(week);
    }
  }

  /**
   * Überprüft ob das Datum deaktiviert werdn soll (zum Beispiel an Wochenenden)
   * @param {Date} date
   * @return {boolean}
   */
  isDisabled (date) {
    if (!date) return false;
    return date.getDay() === 0 || date.getDay() === 6;
  }

  /**
   * Überprüft ob das gegebene Datum nicht im aktuellen Monat liegt
   * @param {Date} date
   * @return {boolean}
   */
  isAnotherMonth (/**Date*/date) {
    return !this.isInMonth(date);
  }

  /**
   * Überprüft ob das gegebene Datum im aktuellen Monat liegt
   * @param {Date} date
   * @return {boolean}
   */
  isInMonth (/**Date*/date) {
    return this.focus.getMonth() === date.getMonth() && this.focus.getFullYear() === date.getFullYear();
  }

  /**
   * Überprüft ob das gegebene Datum fokusiert ist
   * @param {Date} date
   * @return {boolean}
   */
  hasFocus (/**Date*/date) {
    return this.areDatesEqual(this.focus, date);
  }

  /**
   * Überprüft ob das gegebene Datum ausgewählt ist
   * @param {Date} date
   * @return {boolean}
   */
  isSelected (/**Date*/date) {
    return this.areDatesEqual(this.selected, date);
  }

  /**
   * Überprüft ob das gegebene Datum der heutige Tag ist
   * @param {Date} date
   * @return {boolean}
   */
  isToday (/**Date*/date) {
    return this.areDatesEqual(this.today, date);
  }

  /**
   * Gibt ein Date Objekt zurück bei dem keine Uhrzeit gesetzt ist
   * @param {Date} [date] Optional, wenn nicht gesetzt wird als Wert 'Now' genommen
   * @return {Date}
   */
  createDateOnly (date) {
    if (!date) date = new Date();
    return new Date(date.getFullYear(), date.getMonth(), date.getDate());
  }

  /**
   * Vergleicht zwei Tage, aber ignoriert die gesetzte Zeit
   * @param {Date} date1
   * @param {Date} date2
   * @return {boolean}
   */
  areDatesEqual (date1, date2) {
    if (!date1 || !date2) return false;
    return date1.getFullYear() === date2.getFullYear() && date1.getMonth() === date2.getMonth() && date1.getDate() === date2.getDate();
  }

  /**
   * Gibt den letzten Tag des Monats zurück
   * @param {Date} date
   * @return {number}
   */
  getLastDayInMonth (date) {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  }

  /**
   * Fokusiert das Datum welches die Anzahl der gegebenen Tage entfernt ist (amount kann positiv oder negativ sein)
   * @param {number} amount
   */
  changeFocusDay (amount) {
    var date = this.focus;
    date.setDate(date.getDate() + amount);
    this.setFocus(date);
  }

  /**
   * Fokusiert das Datum welches die Anzahl der gegebenen Monate entfernt ist (amount kann positiv oder negativ sein)
   * @param {number} amount amount of months
   */
  changeFocusMonths (amount) {
    var date = this.focus;
    var originalDate = date.getDate();
    date.setMonth(date.getMonth() + amount);
    // Wenn der Tag des Monats außerhalb des validen Bereichs ist, wird das Datum auf das Maximum des vorherigen Monats gesetzt
    // Zum Beispiel: 31. Januar + 1 month -> 3
    if (date.getDate() !== originalDate) {
      date.setDate(0);
    }
    while (this.isDisabled(date)) {
      date.setDate(date.getDate() + (amount > 0 ? 1 : -1));
    }
    this.setFocus(date);
  }

  /**
   * Fokusiert das Datum welches die Anzahl der gegebenen Jahre entfernt ist (amount kann positiv oder negativ sein)
   * @param {number} amount
   */
  changeFocusYears (amount) {
    // Wegen Schaltjahren darf .setYear() hier nicht benutzt werden
    this.changeFocusMonths(12 * amount);
  }

  /**
   * Fokusiert den vorherigen Tag
   */
  setPrevDay () {
    this.changeFocusDay(-1);
  }

  /**
   * Fokusiert den nächsten Tag
   */
  setNextDay () {
    this.changeFocusDay(+1);
  }

  /**
   * Fokusiert die vorherige Woche
   */
  setPrevWeek () {
    this.changeFocusDay(-7);
  }

  /**
   * Fokusiert die kommende Woche
   */
  setNextWeek () {
    this.changeFocusDay(+7);
  }

  /**
   * Fokusiert den vorherigen Monat
   */
  setPrevMonth () {
    this.changeFocusMonths(-1);
  }

  /**
   * Fokusiert den kommenden Monat
   */
  setNextMonth () {
    this.changeFocusMonths(+1);
  }

  /**
   * Fokusiert das vorherige Jahr
   */
  setPrevYear () {
    this.changeFocusYears(-1);
  }

  /**
   * Fokusiert das kommende Jahr
   */
  setNextYear () {
    this.changeFocusYears(+1);
  }
}

/**
 * Repräsentiert eine ganze Woche
 * @param {Date} fromDate Die Woche wird von dem gegebenen Datum plus 7 Tage erstellt
 * @param {string|number} id ID der Woche
 * @constructor
 */
class Week {

  constructor (/**Date*/fromDate, /**string|number*/id) {
    /**@type Date[]*/
    this.dates = [];
    /**@type string*/
    this.id = id + '';

    for (let i = 0; i < 7; i++) {
      const date = new Date(fromDate);
      date.setDate(date.getDate() + i);
      this.dates.push(date);
    }
  }
}

/**
 * Hotkey Handler
 * @param {Object} [fnContextObj] Optionaler Kontext für 'this' in Hotkey Callbacks
 * @param {function} [refreshMethod] Optionale Methode welche nach jeder Aktion aufgerufen wird
 * @constructor
 */
class HotkeyHandler {

  constructor (fnContextObj, refreshMethod) {
    /**
     * Enum für unterstützte Tasten
     * @type { {TAB: number, ENTER: number, ESC: number, SPACE: number, PAGEUP: number, PAGEDOWN: number,
     * END: number, HOME: number, LEFT: number, UP: number, RIGHT: number, DOWN: number} }
     */
    this.Keys = Object.freeze({
      TAB     : 9,
      ENTER   : 13,
      ESC     : 27,
      SPACE   : 32,
      PAGEUP  : 33,
      PAGEDOWN: 34,
      END     : 35,
      HOME    : 36,
      LEFT    : 37,
      UP      : 38,
      RIGHT   : 39,
      DOWN    : 40
    });

    /**@tpye Object*/
    this.contextObj = fnContextObj;
    /**@type function*/
    this.refreshMethod = refreshMethod;
  }

  /**
   * Setzt den gegebenen Hotkey auf dem Element. Kann modifier Tasten enthalten.
   * @param {string} keysToPress Tastenkombinationen wie `ctrl+shift+up` oder `ctrl+click`. Die Modifier Taste muss am
   * Anfang auftauchen: `up + ctrl` ist richtig, `ctrl + up` ist falsch.
   * @param {HTMLElement} element
   * @param {string|function} [liveSelector] Spezieller Selektor der den Hotkey an dynamische Elemente des Elements setzt.
   * @param {function} method Wird mit this.contextObj und dem Event als Parameter aufgerufen
   */
  setOnTree (keysToPress, element, liveSelector, method = undefined) {
    if (typeof liveSelector === 'function') {
      method = liveSelector;
      liveSelector = null;
    }

    const isClick = /click$/i.test(keysToPress);

    if (isClick) {
      return this.setOnClick(keysToPress, element, liveSelector, method);
    } else {
      return this.setOnKey(keysToPress, element, liveSelector, method);
    }
  }

  /**
   * Ähnlich zu HotkeyHandler, aber propagiert nicht durch die Kindelemente. Diese Funktion wird nur aufgerufen, wenn
   * element + liveSelector gleich dem target des Events ist.
   * @param {string} keysToPress Tastenkombinationen wie `ctrl+shift+up` oder `ctrl+click`. Die Modifier Taste muss am
   * Anfang auftauchen: `up + ctrl` ist richtig, `ctrl + up` ist falsch.
   * @param {HTMLElement} element
   * @param {string|function} [liveSelector] Spezieller Selektor der den Hotkey an dynamische Elemente des Elements setzt.
   * @param {function} method Wird mit this.contextObj und dem Event als Parameter aufgerufen
   */
  setOn (keysToPress, element, liveSelector, method = undefined) {
    if (typeof liveSelector === 'function') {
      method = liveSelector;
      liveSelector = null;
    }
    return this.setOnTree(keysToPress, element, liveSelector, function (e) {
      const elementIsTarget = element === e.target;
      let liveSelectorIsTarget = false;

      if (liveSelector && typeof liveSelector === 'string') {
        const targets = element.querySelectorAll(liveSelector);
        targets.forEach((elem) => {
          if (elem === e.target) liveSelectorIsTarget = true;
        });

        if (!liveSelectorIsTarget) {
          return;
        }
      } else {
        if (!elementIsTarget) {
          return;
        }
      }
      e.preventDefault();
      return method.call(this, e);
    });
  }

  /**
   * Sets den Hotkey Action Handler auf dem Element
   */
  setOnKey (/**string*/keys, /**HTMLElement*/element, /**string|null*/_selector, /**function*/method) {
    const thisObj = this;

    element.addEventListener('keydown', (/**Event*/e) => {

      if (!thisObj.checkModKeys(keys, e)) {
        return true;
      }

      const keyNameMatch = keys.match(/[a-z]+$/i);
      if (keyNameMatch.length === 0) {
        return true;
      }

      const keyName = keyNameMatch[0].toUpperCase();
      const keyCode = thisObj.Keys[keyName];

      if (!keyCode || e.keyCode !== keyCode) {
        return true;
      }
      e.preventDefault();
      return thisObj.apply(method, e);
    });
  }

  /**
   * Setzt den Action Event Handler für Modifier Taste + Klick auf dem Element
   */
  setOnClick (/**string*/modKeys, /**HTMLElement*/element, /**string|null*/_selector, /**function(e:Event)*/method) {
    const thisObj = this;
    element.addEventListener('click', (/**Event*/e) => {
      if (e.type !== 'click') {
        return true;
      }

      if (e.target.classList.contains('disabled')) {
        return false;
      }

      if (!thisObj.checkModKeys(modKeys, e)) {
        return true;
      }

      return thisObj.apply(method, e);
    });
  }

  /**
   * Überprüft ob die Modifier Tasten (ctrl, shift, alt) in keys in dem Event auch wirklich gedrückt wurden
   * @param {string} keys Kombination mit Modifier Tasten
   * @param {KeyboardEvent} e
   * @return {boolean} true wenn die Modifier Tasten im Event gedrückt wurden
   */
  checkModKeys (keys, e) {
    if (/ctrl/i.test(keys) !== e.ctrlKey) {
      return false;
    }
    if (/shift/i.test(keys) !== e.shiftKey) {
      return false;
    }
    if (/alt/i.test(keys) !== e.altKey) {
      return false;
    }
    return true;
  }

  /**
   * Ruft die gegebene Funktion fn im Kontext von this.contextObj mit dem Event Parameter auf
   * @param {function} fn
   * @param {Event} e
   * @return {*} Gibt das Ergebnis von fn zurück
   */
  apply (fn, e) {
    const result = fn.call(this.contextObj, e);
    if (this.refreshMethod) this.refreshMethod();

    return result;
  }

  /**
   * Setzt die gegebene Funktion für 'click', 'space' und 'enter'
   * @param {HTMLElement} element
   * @param {string|null|function} selectorOrFn
   * @param {function} [fn=null]
   */
  setAction (element, selectorOrFn, fn) {
    if (typeof selectorOrFn === 'function') {
      fn = selectorOrFn;
      selectorOrFn = null;
    }
    this.setOnTree('click', element, selectorOrFn, fn);
    this.setOnTree('space', element, selectorOrFn, fn);
    this.setOnTree('enter', element, selectorOrFn, fn);
  }
}





