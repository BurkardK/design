/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _loadSpinner.js */
/**
 * Demo-Implementierung interaktiver Loading-Spinner
 * @constructor
 * @param {HTMLElement} Pattern-Container
 */
export class BaLoadSpinner {

  constructor (elem) {
    this.triggerBtn = elem;
    this.triggerBtn.setAttribute('data-initialized', 'true');
    // Sonderfall: Buttonmatrix-Demo
    if (this.triggerBtn.getAttribute('data-demo-spinner-target') === 'buttonmatrix') {
      this.triggerBtn.addEventListener('click', (e) => {
        e.preventDefault();
        this.toggleButtonLoadingSpinner();
      });
      return;
    }
    this.spinnerTarget = this.triggerBtn.getAttribute('data-demo-spinner-target') ? document.getElementById(this.triggerBtn.getAttribute('data-demo-spinner-target')) : document.body;
    this.targetTitle = this.spinnerTarget.getAttribute('title') ? this.spinnerTarget.getAttribute('title') : '';
    this.loadingInfo = 'Daten werden geladen...';
    this.init();
  }

  /**
   * Initialisiert den Loading-Spinner
   */
  init () {
    this.initEvents();
  }

  /**
   * Fügt ein click event hinzu
   */
  initEvents () {
    this.triggerBtn.addEventListener('click', (e) => {
      e.preventDefault();
      if (this.triggerBtn.getAttribute('data-demo-spinner').match('fade-in-out')) {
        this.fadeInOutWithTimer();
      } else if (this.triggerBtn.getAttribute('data-demo-spinner').match('toggle-in-out')) {
        this.toggleInOutWithTimer();
      } else {
        this.triggerBtn.getAttribute('data-demo-spinner').match('faded-out') ? this.fadeInOutLoadingSpinner() : this.toggleLoadSpinner();
        this.toggleAccessibilityAttributes();
      }
    });
  }

  /**
   * Fügt die Klassen hinzu, welche beim Laden benutzt werden sollen
   * @param {Array} clsList
   */
  addClasses (clsList) {
    clsList.forEach((cls) => {
      this.spinnerTarget.classList.add(cls);
      if (cls === 'faded-out') {
        setTimeout(() => {
          this.spinnerTarget.classList.remove(cls);
        }, 100);
      }
    });
  }

  /**
   * Schaltet den Loading-Spinner an oder aus
   */
  toggleLoadSpinner () {
    // Klassen aus data-Attr lesen, .ba-loading ist Pflicht sonst wird nicht initialisiert in demo.js
    const spinnerClasses = this.triggerBtn.getAttribute('data-demo-spinner') ? this.triggerBtn.getAttribute('data-demo-spinner').split(' ') : ['ba-loading'];
    if (this.spinnerTarget.classList.contains('ba-loading')) {
      this.spinnerTarget.classList.remove('ba-loading', 'ba-loading-inverted', 'ba-loading-small', 'toggle-in-out');
    } else {
      this.addClasses(spinnerClasses);
    }
  }

  /**
   * Blendet den Loading-Spinner ein oder aus
   */
  fadeInOutLoadingSpinner () {
    const fadeOutTime = 1000;
    const spinnerClasses = this.triggerBtn.getAttribute('data-demo-spinner') ? this.triggerBtn.getAttribute('data-demo-spinner').split(' ').sort() : ['ba-loading'];
    if (this.spinnerTarget.classList.contains('ba-loading')) {
      this.spinnerTarget.classList.add('faded-out');
      setTimeout(() => {
        this.spinnerTarget.classList.remove('ba-loading', 'ba-loading-inverted', 'ba-loading-small', 'faded-out', 'toggle-in-out');
      }, fadeOutTime);
    } else {
      this.addClasses(spinnerClasses);
    }
  }

  /**
   * Blendet den Loading-Spinner ein/aus und mit 3 Sekunden Verzögerung wieder aus/ein
   */
  fadeInOutWithTimer () {
    this.fadeInOutLoadingSpinner();
    this.toggleAccessibilityAttributes();
    setTimeout(() => {
      this.fadeInOutLoadingSpinner();
      this.toggleAccessibilityAttributes();
    }, 3000);
  }

  /**
   * Toggle in-out mit Timer
   * Schaltet den Loading-Spinner ein/aus und mit 3 Sekunden Verzögerung wieder aus/ein
   */
  toggleInOutWithTimer () {
    this.toggleLoadSpinner();
    this.toggleAccessibilityAttributes();
    setTimeout(() => {
      this.toggleLoadSpinner();
      this.toggleAccessibilityAttributes();
    }, 3000);
  }

  /**
   * Schaltet das Accessibiltiy-Attribute 'aria-busy' ein oder aus
   */
  toggleAccessibilityAttributes () {
    if (this.spinnerTarget.getAttribute('aria-busy') === 'true') {
      this.spinnerTarget.setAttribute('aria-busy', 'false');
      this.removeTitle();
    } else {
      this.spinnerTarget.setAttribute('aria-busy', 'true');
      this.setTitle();
    }
  }

  /**
   * Setzt den Titel
   */
  setTitle () {
    if (this.targetTitle) {
      this.spinnerTarget.setAttribute('data-demo-spinner-title', this.targetTitle);
      this.spinnerTarget.setAttribute('title', `${this.targetTitle}: ${this.loadingInfo}`);
    } else {
      this.spinnerTarget.setAttribute('title', this.loadingInfo);
    }
  }

  /**
   * Entfernt den Titel
   */
  removeTitle () {
    if (this.spinnerTarget.getAttribute('data-demo-spinner-title')) {
      this.spinnerTarget.setAttribute('title', this.spinnerTarget.getAttribute('data-demo-spinner-title'));
    } else {
      this.spinnerTarget.removeAttribute('title');
    }
  }

  /**
   * Schaltet den Loading-Spinner für alle Buttons ein oder aus
   */
  toggleButtonLoadingSpinner () {
    if (document.querySelectorAll('.ba-btn.ba-loading').length) {
      document.querySelectorAll('.ba-loading').forEach((el) => {
        el.classList.remove('ba-loading', 'ba-loading-inverted');
        el.removeAttribute('tabindex');
        el.removeAttribute('aria-hidden');
      });
    } else {
      document.querySelectorAll('.ba-btn').forEach((el) => {
        el.classList.add('ba-loading');
        el.setAttribute('tabindex', '-1');
        el.setAttribute('aria-hidden', 'true');
      });
    }
  }
}
