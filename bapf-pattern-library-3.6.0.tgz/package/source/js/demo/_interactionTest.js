/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _interactionTest.js */
/**
 * Demo-Implementierung Initialisierungen der Bootstrap-Komponenten
 * @constructor
 * @param {HTMLElement} Pattern-Container
 */
export class BaImplementElementsViaJs {

  constructor(element) {
    this.domEl = element;
    this.init();
    this.domEl.setAttribute('data-initialized', 'true');
  }

  /**
   * Initialisiert das Pattern
   */
  init() {
    this.initModal();
    this.initCollapse();
    this.initDropdown();
    this.initTab();
    this.initAkkordeon();
    this.initAlert();
  }

  /**
   * Initialisiert ein Alert
   */
  initAlert() {
    const triggerAlerts = document.querySelectorAll('[data-alert-target]');
    triggerAlerts.forEach((triggerAlert) => {
      triggerAlert.querySelector('.close').addEventListener('click', (e) => {
        e.preventDefault();
        (/** @type{any} */(triggerAlert)).bsAlert = (/** @type{any} */(window)).dpl.bs.Alert.getInstance(triggerAlert) || new (/** @type{any} */(window)).dpl.bs.Alert(triggerAlert);
        (/** @type{any} */(triggerAlert)).bsAlert.close();
      });
    });
  }

  /**
   * Initialisiert ein Modal
   */
  initModal() {
    const triggerModals = document.querySelectorAll('[data-modal-target]');
    triggerModals.forEach((triggerModal) => {
      const modalElem = document.getElementById(triggerModal.getAttribute('data-modal-target'));
      (/** @type{any} */(modalElem)).bsModal = (/** @type{any} */(window)).dpl.bs.Modal.getInstance(modalElem) || new (/** @type{any} */(window)).dpl.bs.Modal(modalElem);
      triggerModal.addEventListener('click', (e) => {
        e.preventDefault();
        const modalId = (/** @type{HTMLElement} */(e.target)).getAttribute('data-modal-target');
        const modalDialog = document.getElementById(modalId);
        (/** @type{any} */(modalDialog)).bsModal.toggle();
      });
    });
  }

  /**
   * Initialisiert ein Collapse
   */
  initCollapse() {
    const triggers = document.querySelectorAll('[data-collapse-target]');
    triggers.forEach((triggerCollapse) => {
      const collapseElem = document.getElementById(triggerCollapse.getAttribute('data-collapse-target'));
      (/** @type{any} */(collapseElem)).bsCollapse = (/** @type{any} */(window)).dpl.bs.Collapse.getInstance(collapseElem) || new (/** @type{any} */(window)).dpl.bs.Collapse(collapseElem, {toggle: false});
      triggerCollapse.addEventListener('click', (e) => {
        e.preventDefault();
        const currentCollapseElem = document.getElementById((/** @type{HTMLElement} */(e.target)).getAttribute('data-collapse-target'));
        (/** @type{any} */(currentCollapseElem)).bsCollapse.toggle();
      });
    });
  }

  /**
   * Initialisiert ein Dropdown
   */
  initDropdown() {
    const triggers = document.querySelectorAll('[data-dropdown-target]');
    triggers.forEach((triggerDropdown) => {
      const dropdownElem = document.getElementById(triggerDropdown.getAttribute('data-dropdown-target'));
      (/** @type{any} */(dropdownElem)).bsDropdown = (/** @type{any} */(window)).dpl.bs.Dropdown.getInstance(dropdownElem) || new (/** @type{any} */(window)).dpl.bs.Dropdown(dropdownElem);
      triggerDropdown.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const currentDropdownElem = document.getElementById((/** @type{HTMLElement} */(e.target)).getAttribute('data-dropdown-target'));
        (/** @type{any} */(currentDropdownElem)).bsDropdown.toggle();
      });
    });
  }

  /**
   * Initialisiert ein Tab
   */
  initTab() {
    const triggers = document.querySelectorAll('[data-tab-target]');
    triggers.forEach((triggerTab) => {
      triggerTab.addEventListener('click', (e) => {
        e.preventDefault();
        const showTab = !(/** @type{HTMLElement} */(e.target)).hasAttribute('data-no-tab-switch');
        const tabId = (/** @type{HTMLElement} */(e.target)).getAttribute('data-tab-target');
        const tab = document.getElementById(tabId);
        const tabbar = tab.closest('.ba-tabbar').baTabbar;
        tabbar.setActive(tabId, showTab);
      });
    });
  }

  /**
   * Initialisiert ein Akkordeon
   */
  initAkkordeon() {
    const triggers = document.querySelectorAll('[data-akkordeon-target]');
    triggers.forEach((triggerPanel) => {
      const panelElem = document.getElementById(triggerPanel.getAttribute('data-akkordeon-target'));
      (/** @type{any} */(panelElem)).bsAkkordeon = (/** @type{any} */(window)).dpl.bs.Collapse.getInstance(panelElem) || new (/** @type{any} */(window)).dpl.bs.Collapse(panelElem, {toggle: false});
      triggerPanel.addEventListener('click', (e) => {
        e.preventDefault();
        const currentPanelElem = document.getElementById((/** @type{HTMLElement} */(e.target)).getAttribute('data-akkordeon-target'));
        (/** @type{any} */(currentPanelElem)).bsAkkordeon.toggle();
      });
    });
  }

}

