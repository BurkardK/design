/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _fileUpload.js */
/**
 * Demo-Implementierung Dateiupload
 * @constructor
 * @param {HTMLElement} Pattern-Container
 */
export class BaFileUpload {

  constructor (uploader) {
    this.domEl = uploader;
    /* istanbul ignore next */
    this.uploadURL = location.href.indexOf('web.arbeitsagentur.de') !== -1 ? // Endpunkt für Upload, hier z.B. PDS Upload-Mock auf prod oder dev
      'https://web.arbeitsagentur.de/design/pds3/upload' :
      'https://web.dev.ocp.webapp.idst.ibaintern.de/design/pds3/develop/upload';
    this.callApi = /* istanbul ignore next */ (url, options) => fetch(url, options);
    this.dropArea = uploader.querySelector('.ba-upload-dropzone');
    this.fileInput = uploader.querySelector('input[type=file]');
    this.fileList = uploader.querySelector('.ba-upload-files');
    this.dropArea = uploader.querySelector('.ba-upload-dropzone');
    this.message = uploader.querySelector('.ba-upload-message');

    this.identString = '';
    this.pendingUploadReqs = {};
    this.fileCount = {
      all    : 0,
      success: 0,
      error  : 0
    };

    // Screenreader Live-Area Meldungen
    this.srMessages = {
      uploadSuccess: () => this.identString + 'Alle Dateien erfolgreich hochgeladen.',
      uploadFailed : (error) => this.identString + `${this.fileCount.error} Datei${this.fileCount.error > 1 ? 'en' : ''} wurde${this.fileCount.error > 1 ? 'n' : ''} nicht erfolgreich hochgeladen (${error || 'unbekannter Fehler'}). Bitte beachten Sie die Liste der hochgeladenen Dateien.`,
      abortSuccess : /* istanbul ignore next */ (fileName) => this.identString + `Hochladen der Datei ${fileName} erfolgreich abgebrochen.`,
      deleteSuccess: (fileName) => this.identString + `Datei ${fileName} wurde erfolgreich gelöscht.`
    };

    // Template für einen Dateieintrag in der Upload-Liste
    this.fileListEntry = `
      <li class="ba-upload-listed" data-filename="{{title}}">
        <span class="ba-title">{{title}}</span>
        <span class="sr-only">wird hochgeladen</span>
        <button class="ba-upload-delete" aria-label="Datei {{title}} löschen"></button>
      </li>`;

    /* istanbul ignore else */
    if (this.dropArea && this.fileInput && this.fileList) {
      this.init();
      this.domEl.setAttribute('data-initialized', 'true');
    }
  }

  /**
   * Drag, drop und click Event-Handler
   */
  init () {
    const that = this;
    const dropArea = this.dropArea;
    const fileInput = this.fileInput;

    // Wenn es mehrere Upload-Komponenten auf der Seite gibt, muss der Screenreader das Label der aktuellen Komponente mit ausgeben
    /* istanbul ignore else */
    if (document.querySelectorAll('input[type=file]').length > 1) {
      if (fileInput.hasAttribute('aria-labelledby')) {
        this.identString = document.getElementById(this.fileInput.getAttribute('aria-labelledby')).textContent + ': ';
      } else {
        this.identString = this.domEl.querySelector('label').childNodes[0].textContent + ': ';
      }
    }

    // Datei aus der Upload Liste entfernen
    document.addEventListener('click', function (e) {
      /* istanbul ignore else */
      if (that.domEl.contains(e.target)) {
        const target = /** @type{HTMLElement} */(e.target);
        const button = target.closest('.ba-upload-delete');

        /* istanbul ignore else */
        if (button) {
          const entry = button.closest('li');
          that.fileList.removeChild(entry);

          // Der Upload wird abgebrochen, falls er noch nicht beendet wurde
          const fileName = entry.getAttribute('data-filename');
          const pendingReq = that.pendingUploadReqs[fileName];
          /* istanbul ignore next */
          if (pendingReq) {
            delete that.pendingUploadReqs[fileName];
            pendingReq.abort();
          }

          const isStillUploading = entry.classList.contains('ba-upload-loading');
          const srMessage = isStillUploading ?
            /* istanbul ignore next */
            that.srMessages.abortSuccess(fileName) :
            that.srMessages.deleteSuccess(fileName);
          that.setSrMessage(srMessage);
        }
      }
    }, false);

    // Datei wird über die DropArea gezogen
    ['dragenter', 'dragover'].forEach(eventName => {
      dropArea.addEventListener(eventName, function (e) {
        e.preventDefault();
        e.stopPropagation();
        dropArea.classList.add('dropable');
      }, false);
    });

    // Datei ist nicht mehr über der DropArea
    ['dragleave', 'drop'].forEach(eventName => {
      dropArea.addEventListener(eventName, function (e) {
        e.preventDefault();
        e.stopPropagation();
        dropArea.classList.remove('dropable');
      }, false);
    });

    // drop event
    dropArea.addEventListener('drop', this.handleFiles.bind(this), false);

    // file select event
    fileInput.addEventListener('change', this.handleFiles.bind(this));
  }

  /**
   * Dateien im Input bearbeiten
   * @param {DragEvent} e
   */
  handleFiles (e) {
    /* istanbul ignore next */
    const files = e.dataTransfer ? e.dataTransfer.files : e.target.files; // from drop or form control
    this.fileCount = {
      all    : [...files].length,
      success: 0,
      error  : 0
    };
    this.message.textContent = '';
    ([...files]).forEach(file => {
      this.uploadFile(file);
    });

    e.target.value = '';
  }

  /**
   * Upload-Ergebnis im Screenreader ausgeben
   * @param {string} error
   */
  setUploadMessage (error) {
    let message = this.message.textContent;
    if (this.fileCount.error > 0) {
      message = this.srMessages.uploadFailed(error);
      this.fileList.focus();
    } else /* istanbul ignore else */ if (this.fileCount.success === this.fileCount.all) {
      message = this.srMessages.uploadSuccess();
    }

    this.setSrMessage(message);
  }

  /**
   * Screenreader Ausgabe
   * @param {string} message
   */
  setSrMessage (message) {
    /* istanbul ignore else */
    if (message && message !== this.message.textContent) {
      this.message.textContent = message;
    }
  }

  /**
   * Upload Liste erweitern und Datei uploaden
   * @param {File} file
   */
  uploadFile (file) {
    const fileEntry = this.expandUploadList(file.name);

    this.sendRequest(file)
      .then(async (response) => {
        /* istanbul ignore next */
        if (!response) return;

        delete this.pendingUploadReqs[file.name];
        fileEntry.classList.remove('ba-upload-loading');
        const fileCounter = this.fileCount;

        if (response.ok) {
          this.onUploadSuccess(this, fileEntry, fileCounter);
        } else {
          this.onUploadFailed(this, fileEntry, fileCounter, await response.text());
        }
      });
  }

  /**
   * Fügt den Namen der Datei in das html template hinzu und gibt es als HTMLElement zurück
   * @param {string} fileName
   * @return {HTMLElement}
   */
  expandUploadList (fileName) {
    const fileEntry = /** @type{HTMLElement} */(this.htmlToElement(this.fileListEntry.replace(/{{title}}/g, fileName)));
    this.fileList.appendChild(fileEntry);

    fileEntry.classList.remove('ba-upload-listed');
    fileEntry.classList.add('ba-upload-loading');

    return fileEntry;
  }

  /**
   * Sended den File Upload Request
   * @param {File} file
   * @return {Promise}
   */
  sendRequest (file) {
    const controller = new AbortController();
    const { signal } = controller;
    const formData = new FormData();
    formData.append(this.fileInput.attributes.name.value, file);

    // Speichert den Request, um ihn durch Klicken des Buttons abbrechen zu können
    this.pendingUploadReqs[file.name] = controller;

    return this.callApi(this.uploadURL, {
      method: 'POST',
      body  : formData,
      signal
    })
      .catch( /* istanbul ignore next */ (e) => {
        if (e.name !== 'AbortError') throw e;
      });
  }

  /**
   * Zeigt dem Nutzer an, dass der Upload erfolgreich war
   * @param {BaFileUpload} that
   * @param {HTMLElement} fileEntry
   * @param {number} fileCounter
   */
  onUploadSuccess (that, fileEntry, fileCounter) {
    fileEntry.classList.add('ba-upload-success');
    fileEntry.querySelector('.sr-only').textContent = 'Status: Hochgeladen';
    fileCounter.success++;

    that.setUploadMessage();
  }

  /**
   * Zeigt dem Nutzer an, dass der Upload fehlgeschlagen ist
   * @param {BaFileUpload} that
   * @param {BaFileUpload} that
   * @param {HTMLElement} fileEntry
   * @param {string} errorText
   */
  onUploadFailed (that, fileEntry, fileCounter, errorText) {
    const fileEntryTitle = /** @type{HTMLElement} */(fileEntry.querySelector('.ba-title'));
    fileEntryTitle.innerText = errorText;
    fileEntry.classList.add('ba-upload-error');
    fileEntry.querySelector('.sr-only').textContent = 'Status: Fehler';
    fileCounter.error++;

    that.setUploadMessage(errorText);
  }

  /**
   * Fügt den HTML code in ein <div> ein und gibt ein HTMLElement zurück
   * @param {string} html
   * @return {HTMLElement}
   */
  htmlToElement (html) {
    const dummy = document.createElement('div');
    dummy.innerHTML = html.trim();
    return dummy.firstChild;
  }
}
