/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _checkboxTree.js */
/**
 * Pattern: CheckboxTree
 * Initialisiert die Checkbox-Tree-Funktionen (Tri-State Checkbox)
 * @constructor
 * @param {HTMLElement} element - CheckboxTree container Element, default: fieldset.ba-checkbox-tree
 */
export class BaCheckboxTree {

  constructor (element) {
    /* istanbul ignore next */
    if (element.hasAttribute('data-initialized')) return;

    this.domEl = element;
    this.initListeners();
    this.initIndeterminateState();

    this.domEl.setAttribute('data-initialized', 'true');
  }

  /**
   * Setzt das indeterminate Element und updated die Kinderelemente.
   * @param {HTMLElement} check
   */
  setIndeterminate (check) {
    // Erstelle nodeArray
    const nodeArray = (selector, parent = this.domEl) => [].slice.call(parent.querySelectorAll(selector));
    const getCheckbox = (elem) => elem.querySelector('input[type="checkbox"]');
    const getCheckboxContainer = (elem) => elem.closest('.form-check');

    // Wählt die Kindelemente aus und setzt den indeterminate Wert auf false
    const children = nodeArray('.form-check', getCheckboxContainer(check));
    children.forEach(child => {
      getCheckbox(child).checked = check.checked;
      getCheckbox(child).indeterminate = false;
    });

    while (check) {
      // Findet alle Kind- und Geschwistercheckboxen
      const parentCheck = check.parentNode.parentNode.closest('.form-check') ? check.parentNode.parentNode.closest('.form-check').querySelector(':scope > input[type="checkbox"]') : null;
      const siblingChecks = [].slice.call(check.parentNode.parentNode.querySelectorAll(':scope > .form-check > input[type="checkbox"]'));

      // Liest die checked Status aus und überprüft ob alle oder nur ein paar ausgewählt sind
      const checkStatus = siblingChecks.map(sibling => sibling.checked);
      const every = checkStatus.every(Boolean);
      const some = checkStatus.some(Boolean);

      if (parentCheck) {
        // Setzt den indeterminate Status des Elternelements auf true wenn ein oder mehrere Kindelemente nicht gesetzt sind
        parentCheck.checked = every;
        parentCheck.indeterminate = (!every && every !== some) || siblingChecks.filter(sibling => sibling.indeterminate).length > 0;
        check = parentCheck;
      }
      else {
        check = 0;
      }
    }
  }

  /**
   * Fügt einen Event Listener zur Checkbox hinzu, welcher das indeterminate Element
   * bei Änderungen updated.
   * Events: change
   */
  initListeners () {
    this.domEl.addEventListener('change', (e) => {
      this.setIndeterminate(e.target);
    });
  }

  /**
   * Initialisiert den indeterminate Status
   */
  initIndeterminateState () {
    this.domEl.querySelectorAll('input[type="checkbox"]:checked').forEach(check => {
      this.setIndeterminate(check);
    });
  }
}
