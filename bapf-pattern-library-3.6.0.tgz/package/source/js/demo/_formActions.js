/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _formActions.js */
/**
 * Demo-Implementierung Formular-Interaktionen
 * @constructor
 * @param {HTMLElement} Pattern-Container
 */
export class BaFormActions {

  constructor (element) {
    this.domEl = element;
    this.init();
    this.domEl.setAttribute('data-initialized', 'true');
  }

  /**
   * Initialisiert das Pattern
   */
  init () {
    this.initExpandByCheckbox();
    this.initEnableByCheckbox();
    this.initToggleByRadio();
    this.initToggleBySelect();
    this.initDynamicAdditions();
    this.initFormatting();
    // Form submit in Demo verhindern
    /* istanbul ignore next */
    if (document.querySelector('form.ba-progress-form-area')) {
      document.querySelector('form.ba-progress-form-area').addEventListener('submit', function (e) {
        e.preventDefault();
      }, true);
    }
  }

  /**
   * Feldanzeige umschalten mit Radio Buttons
   */
  initToggleByRadio () {
    const triggerGroups = document.querySelectorAll('fieldset[data-toggle-targets]');
    triggerGroups.forEach((triggerGroup) => {
      const triggers = triggerGroup.querySelectorAll('[data-toggle-target]');
      const targets = triggerGroup.getAttribute('data-toggle-targets');
      const toggleGroup = document.querySelectorAll(`[data-toggle-group=${targets}]`);

      toggleGroup.forEach((toggleEl) => {
        (/** @type{any} */(toggleEl)).bsCollapse = (/** @type{any} */(window)).dpl.bs.Collapse.getInstance(toggleEl) || new (/** @type{any} */(window)).dpl.bs.Collapse(toggleEl, { toggle: false });
      });

      triggers.forEach((trigger) => {
        trigger.addEventListener('change', function () {
          const toggleTarget = document.getElementById(trigger.getAttribute('data-toggle-target'));
          toggleGroup.forEach((toggleEl) => {
            toggleEl === toggleTarget ? (/** @type{any} */(toggleEl)).bsCollapse.show() : (/** @type{any} */(toggleEl)).bsCollapse.hide();
          });
        });
      });
    });
  }

  /**
   * Feldanzeige umschalten mit Selects
   */
  initToggleBySelect () {
    const triggerGroups = document.querySelectorAll('select[data-toggle-targets]');
    triggerGroups.forEach((triggerGroup) => {
      const targets = triggerGroup.getAttribute('data-toggle-targets');
      const toggleGroup = document.querySelectorAll(`[data-toggle-group=${targets}]`);

      toggleGroup.forEach((toggleEl) => {
        (/** @type{any} */(toggleEl)).bsCollapse = (/** @type{any} */(window)).dpl.bs.Collapse.getInstance(toggleEl) || new (/** @type{any} */(window)).dpl.bs.Collapse(toggleEl, { toggle: false });
      });

      triggerGroup.addEventListener('change', function () {
        const toggleTarget = document.getElementById(triggerGroup.options[triggerGroup.selectedIndex].getAttribute('data-toggle-target'));
        toggleGroup.forEach((toggleEl) => {
          toggleEl === toggleTarget ? (/** @type{any} */(toggleEl)).bsCollapse.show() : (/** @type{any} */(toggleEl)).bsCollapse.hide();
        });
      });
    });
  }

  /**
   * Felder anzeigen, wenn Checkbox aktiv gesetzt ist
   */
  initExpandByCheckbox () {
    const triggers = document.querySelectorAll('[data-expand-target]');
    triggers.forEach((/** @type{HTMLInputElement} */trigger) => {
      const expandEl = document.getElementById(trigger.getAttribute('data-expand-target'));
      const bsCollapse = (/** @type{any} */(window)).dpl.bs.Collapse.getInstance(expandEl) || new (/** @type{any} */(window)).dpl.bs.Collapse(expandEl, { toggle: false });
      trigger.addEventListener('change', function () {
        trigger.checked ? bsCollapse.show() : bsCollapse.hide();
      });
    });
  }

  /**
   * Felder aktivieren, wenn Checkbox aktiv gesetzt ist
   */
  initEnableByCheckbox () {
    const triggers = document.querySelectorAll('[data-enable-target]');
    triggers.forEach((/** @type{HTMLInputElement} */trigger) => {
      const enableEl = /** @type{HTMLInputElement} */(document.getElementById(trigger.getAttribute('data-enable-target')));
      trigger.addEventListener('change', function () {
        enableEl.disabled = !trigger.checked;
      });
    });
  }

  /**
   * Felder hinzufügen/entfernen
   */
  initDynamicAdditions () {
    // HTML Templates für hinzuzufügende Elemente
    const templates = {
      'demo-append-fields'   : `
        <div class="demo-dynamic-fields collapse">
          <div role="group" class="border-bottom" aria-labelledby="heading-add-fields-{{group}}-1">
            <div class="row ba-form-action-head">
              <div class="col ba-form-action-title"><h5 class="ba-heading" id="heading-add-fields-{{group}}-1">Dynamische Feldgruppe</h5></div>
              <div class="col ba-form-action-trigger"><button class="ba-btn ba-btn-icon ba-icon-trash ba-btn-tertiary" type="button" title="diese Feldgruppe entfernen" disabled="" data-remove-container="demo-append-fields">Entfernen</button>
              </div>
            </div>
            <div class="row ba-form-row">
              <div class="col-12 col-sm-6">
                <label for="add-fields-{{group}}-id1">Label dyn. 1</label>
                <input id="add-fields-{{group}}-id1" class="form-control" type="text">
              </div>
              <div class="col-12 col-sm-6">
                <label for="add-fields-{{group}}-id2">Label dyn. 2</label>
                <input id="add-fields-{{group}}-id2" class="form-control" type="text">
              </div>
              <div class="col-12">
                <label for="add-fields-{{group}}-id3">Label dyn. 3</label>
                <input id="add-fields-{{group}}-id3" class="form-control" type="text">
              </div>
            </div>
          </div>
        </div>`,
      'demo-append-fieldsets': `
        <div class="demo-dynamic-fields collapse">
          <div role="group" class="ba-form-group ba-layout-tile" aria-labelledby="heading-add-fields-{{group}}-1">
            <div class="ba-form-group-info ba-copytext">
              <h4 class="ba-heading" id="heading-add-fields-{{group}}-1">Hinzugefügte Feldgruppe</h4>
            </div>
            <div class="ba-form-group-fields">
              <fieldset>
                <div class="row ba-form-action-head">
                  <div class="col ba-form-action-trigger"><button class="ba-btn ba-btn-icon ba-icon-trash ba-btn-tertiary" type="button" title="diese Feldgruppe entfernen" data-remove-container="demo-append-fieldsets">Entfernen</button></div>
                </div>
                <div class="row ba-form-row">
                  <div class="col-12 col-sm-6">
                    <label for="add-fields-{{group}}-id1">Label dyn. 4</label>
                    <input id="add-fields-{{group}}-id1" class="form-control" type="text">
                  </div>
                  <div class="col-12 col-sm-6">
                    <label for="add-fields-{{group}}-id2">Label dyn. 5</label>
                    <input id="add-fields-{{group}}-id2" class="form-control" type="text">
                  </div>
                  <div class="col-12">
                    <label for="add-fields-{{group}}-id3">Label dyn. 6</label>
                    <input id="add-fields-{{group}}-id3" class="form-control" type="text">
                  </div>
                </div>
              </fieldset>
            </div>
          </div>
        </div>`
    };

    // DOM-Element aus HTML-Template erzeugen
    function htmlToElement (html) {
      const template = document.createElement('template');
      html = html.trim(); // Never return a text node of whitespace as the result
      template.innerHTML = html;
      return template.content.firstChild;
    }

    // "entfernen"-Button disablen, wenn letzter Feldcontainer
    function updateDeleteButtons (container, show) {
      const buttons = container.querySelectorAll('[data-remove-container]');
      buttons.forEach((button) => {
        button.disabled = !show;
      });
    }

    function removeNode(nodeItem, container) {
      container.removeChild(nodeItem);
      return container;
    }

    // Click-Handler für "hinzufügen" und "entfernen"
    document.addEventListener('click', function (e) {
      for (let target = /** @type{any} */(e.target); target && target !== this; target = target.parentNode) { // loop parent nodes from the target to the delegation node
        // hinzufügen
        const targetElem = /** @type{HTMLElement} */(e.target);
        if (targetElem.matches('[data-append-container]')) {
          e.preventDefault();
          const containerId = targetElem.getAttribute('data-append-container');
          const container = document.getElementById(containerId);
          const template = targetElem.getAttribute('data-append-template') && appendTemplates ? appendTemplates[targetElem.getAttribute('data-append-template')] : templates[containerId];
          const additionNode =/** @type{HTMLElement} */ (htmlToElement(template.replace(/{{group}}/g, 'group' + Math.floor(Math.random() * 100000)).replace(/-id0"/g, '-id' + Math.floor(Math.random() * 100000) + '"')));
          container.insertBefore(additionNode, container.lastElementChild);
          new (/** @type{any} */(window)).dpl.bs.Collapse(additionNode); // BS Collapse initialisieren auf neue Node und expanden
          updateDeleteButtons(container, container.querySelectorAll('.demo-dynamic-fields').length > 1);
          // neu eingefügte dynamische Patterns initialisieren
          document.dispatchEvent(new Event('DOMContentLoaded', {bubbles: true}));
          // nach Hinzufügen muss der Focus auf ein sinnvolles Element gesetzt werden, im Beispiel hier der "entfernen"-Button
          const focusTarget = /** @type{HTMLElement} */(additionNode.querySelector('button[data-remove-container]'));
          focusTarget.focus();
          return;
        }
        // entfernen
        if (targetElem.matches('[data-remove-container]')) {
          e.preventDefault();
          const containerId = targetElem.getAttribute('data-remove-container');
          const container = document.getElementById(containerId);
          const removalNode = targetElem.closest('.demo-dynamic-fields');
          /* istanbul ignore next */
          const bsCollapse = (/** @type{any} */(window)).dpl.bs.Collapse.getInstance(removalNode) || new (/** @type{any} */(window)).dpl.bs.Collapse(removalNode, { toggle: false });
          removalNode.addEventListener('hidden.bs.collapse', removeNode(removalNode, container));  // Node entfernen nach BS collapse
          bsCollapse.hide();
          updateDeleteButtons(container, container.querySelectorAll('.demo-dynamic-fields:not(.collapsing)').length > 1);
          return;
        }
      }
    }, { capture: false });
  }

  /**
   * Feldinhalte formatieren
   */
  initFormatting () {
    const targets = document.querySelectorAll('[data-formatter]');
    targets.forEach((/** @type{HTMLInputElement} */target) => {
      const formatter = target.getAttribute('data-formatter');
      switch (formatter) {
        // Beispiel: IBAN (sehr rudimentär)
        case 'iban':
          target.addEventListener('input', () => {
            target.value = target.value
              .toUpperCase()
              .replace(/[^0-9A-Z]/g, '')
              .replace(/(.{4})/g, '$1 ')
              .trim();
          });
          break;
        /* istanbul ignore next */
        case 'date':
          // weitere Formatierung
          break;
        /* istanbul ignore next */
        case 'time':
          // weitere Formatierung
          break;
        /* istanbul ignore next */
        default: return;
      }
    });
  }
}
