/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | demo.js */
import { BaSitemap } from './_sitemap';
import { BaPagination } from './_pagination';
import { BaPaginationWithInput } from './_paginationWithInput';
import { BaFileUpload } from './_fileUpload';
import { BaDatePicker } from './_datePicker';
import { BaFormActions } from './_formActions';
import { BaImplementElementsViaJs } from './_interactionTest';
import { BaLoadSpinner } from './_loadSpinner';
import { BaCheckboxTree } from './_checkboxTree';

(/** @type{any} */(window)).dplDemo = (/** @type{any} */(window)).dplDemo || {};

// DPL-Demo Sitemap
(/** @type{any} */(window)).dplDemo.sitemap = {
  init: function (selector) {
    if (!selector) selector = '.dpl-sitemap:not([data-initialized])';
    const targets = document.querySelectorAll(selector);
    /* istanbul ignore next */
    if (targets && targets.length) {
      targets.forEach((target) => {
        target.baSitemap = new BaSitemap(target);
      });
    }
  }
};

// Demo Pagination
(/** @type{any} */(window)).dplDemo.pagination = {
  init: function (selector) {
    if (!selector) selector = '.ba-pagination:not(.with-input):not([data-initialized])';
    const targets = document.querySelectorAll(selector);
    /* istanbul ignore next */
    if (targets && targets.length) {
      targets.forEach((target) => {
        target.baPagination = new BaPagination(target);
      });
    }
  }
};

// Demo Pagination mit Eingabefeld
(/** @type{any} */(window)).dplDemo.paginationWithInput = {
  init: function (selector) {
    if (!selector) selector = '.ba-pagination.with-input:not([data-initialized])';
    const targets = document.querySelectorAll(selector);
    /* istanbul ignore next */
    if (targets && targets.length) {
      targets.forEach((target) => {
        target.baPaginationWichInput = new BaPaginationWithInput(target);
      });
    }
  }
};

// Demo FileUploader
(/** @type{any} */(window)).dplDemo.fileUpload = {
  init: function (selector) {
    if (!selector) selector = '.ba-file-uploader:not(.with-input):not([data-initialized])';
    const targets = document.querySelectorAll(selector);
    /* istanbul ignore next */
    if (targets && targets.length) {
      targets.forEach((target) => {
        target.baFileUpload = new BaFileUpload(target);
      });
    }
  }
};

// Demo Datepicker
(/** @type{any} */(window)).dplDemo.datePicker = {
  init: function (selector) {
    if (!selector) selector = '.ba-date-picker:not([data-initialized])';
    const targets = document.querySelectorAll(selector);
    /* istanbul ignore next */
    if (targets && targets.length) {
      targets.forEach((target) => {
        target.baDatePicker = new BaDatePicker(target);
      });
    }
  }
};

// Demo Formularstrecke / dynamische Form-Bereiche
(/** @type{any} */(window)).dplDemo.formActions = {
  init: function (selector) {
    if (!selector) selector = '.demo-form-actions:not([data-initialized])';
    const targets = document.querySelectorAll(selector);
    /* istanbul ignore next */
    if (targets && targets.length) {
      targets.forEach((target) => {
        target.baFormActions = new BaFormActions(target);
      });
    }
  }
};

// Demo interaktive BS5-Elemente
(/** @type{any} */(window)).dplDemo.interactiveActions = {
  init: function (selector) {
    if (!selector) selector = '.demo-interactive-elements:not([data-initialized])';
    const targets = document.querySelectorAll(selector);
    /* istanbul ignore next */
    if (targets && targets.length) {
      targets.forEach((target) => {
        target.baInteractiveActions = new BaImplementElementsViaJs(target);
      });
    }
  }
};

// Demo Loading Spinner
(/** @type{any} */(window)).dplDemo.loadspinner = {
  init: function (selector) {
    if (!selector) selector = '[data-demo-spinner]:not([data-initialized])';
    const targets = document.querySelectorAll(selector);
    /* istanbul ignore next */
    if (targets && targets.length) {
      targets.forEach((target) => {
        target.baLoadSpinner = new BaLoadSpinner(target);
      });
    }
  }
};

// Demo Tri-State Checkbox
(/** @type{any} */(window)).dplDemo.checkboxTree = {
  init: function (selector) {
    if (!selector) selector = 'fieldset.ba-checkbox-tree:not([data-initialized])';
    const targets = document.querySelectorAll(selector);
    /* istanbul ignore next */
    if (targets && targets.length) {
      targets.forEach((target) => {
        target.baCheckbox = new BaCheckboxTree(target);
      });
    }
  }
};


document.addEventListener('DOMContentLoaded', function () {
  (/** @type{any} */(window)).dplDemo.sitemap.init();
  (/** @type{any} */(window)).dplDemo.pagination.init();
  (/** @type{any} */(window)).dplDemo.paginationWithInput.init();
  (/** @type{any} */(window)).dplDemo.fileUpload.init();
  (/** @type{any} */(window)).dplDemo.datePicker.init();
  (/** @type{any} */(window)).dplDemo.formActions.init();
  (/** @type{any} */(window)).dplDemo.interactiveActions.init();
  (/** @type{any} */(window)).dplDemo.loadspinner.init();
  (/** @type{any} */(window)).dplDemo.checkboxTree.init();
});

