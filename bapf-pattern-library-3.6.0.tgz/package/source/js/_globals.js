/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _globals.js */
// Bootstrap JS Modules
import { Alert, Collapse, Modal, Dropdown, Popover, Tab } from 'bootstrap/dist/js/bootstrap.esm';
import { Utilities } from './_utilities';

// DPL Pattern JS Modules
import { BaScrollToTop } from './_scrollToTop';
import { BaTabbar } from './_tabbar';
import { BaNavbar } from './_navbar';
import { BaCollapse } from './_collapse';
import { BaHeader } from './_header';
import { BaContactInfobox } from './_contactInfobox';
import { BaProgressNav } from './_progressNav';
import { BaDropdownSelect } from './_dropdownSelect';
import { BaRangeSlider } from './_rangeSlider';
import { BaPopover } from './_popover';
import { BaSlider } from './_slider';
import { BaSubHeader } from './_subHeader';
import { BaDropdown } from './_dropdown';
import { BaToolbar } from './_toolbar';
import { BaTypeahead } from './_typeahead';
import { BaTextareaCounter } from './_textareaCounter';

/**
 * BaGlobals
 * initialisiert Bootstrap, seitenübergreifende Funktionen und Patterns der DPL3
 */
export class BaGlobals {

  /**
   * Initialisiert Bootstrap, globale Funktionen und DPL Patterns
   */
  static init () {
    this.setupBootstrap();
    this.setupGlobal();
    this.setupPatterns();
  }

  /**
   * Bootstrap JS-API als dpl.bs hinzufügen
   * Aufrufe der Bootstrap API-Calls damit statt bootstrap.Component -> dpl.bs.Component,
   * z.B. new bootstrap.Collapse(myCollapse) -> new dpl.bs.Collapse(myCollapse)
   */
  static setupBootstrap () {
    (/** @type{any} */(window)).dpl = (/** @type{any} */(window)).dpl || {};
    (/** @type{any} */(window)).dpl.bs = {
      Alert,
      Collapse,
      Dropdown,
      Modal,
      Popover,
      Tab
    };
  }

  /**
   * Globale, seitenweite Funktionen einrichten und initialisieren
   */
  static setupGlobal () {
    (/** @type{any} */(window)).dpl = (/** @type{any} */(window)).dpl || {};

    // Button scrollen zum Seitenanfang
    const initScrollToTop = () => {
      if (initialized.scrollToTop) return;
      const scrollToTopElem = document.querySelector('a.ba-scroll-to-top:not([data-initialized])');
      /* istanbul ignore next */
      if (scrollToTopElem) {
        (/** @type{any} */(scrollToTopElem)).baScrollToTop = new BaScrollToTop(scrollToTopElem);
      }
      initialized.scrollToTop = true;
    };

    // Erkennung Tastatur- oder Mausbedienung
    const initMouseKeyboardMode = () => {
      if (initialized.mouseKeyboardMode) return;
      document.addEventListener('keydown', () => {
        document.body.classList.add('ba-keyboard-mode');
      });
      document.addEventListener('mousedown', () => {
        document.body.classList.remove('ba-keyboard-mode');
      });
      initialized.mouseKeyboardMode = true;
    };

    // A11y-Erweiterungen Modal
    const initModalA11y = () => {
      const modals = document.querySelectorAll('.modal');
      /* istanbul ignore next */
      modals.forEach((/** @type {HTMLElement} */modal) => {
        // Nach Öffnen eines BS-Modals: erstes fokussierbares Element im Modal fokussieren
        if (!modal.hasAttribute('data-prevent-autofocus')) {
          modal.addEventListener('shown.bs.modal', () => {
            Utilities.getFirstFocusable(modal).focus();
          });
        }
        // Modal kann per Tab-Taste nicht mehr verlassen werden (Focus-Falle)
        modal.addEventListener('keydown', (e) => {
          if (!e.shiftKey && e.key === 'Tab') {
            const focusables = Utilities.getFocusableElements(modal);
            if (focusables[focusables.length - 1] === e.target) {
              e.preventDefault();
              focusables[0].focus();
            }
          }
        });
      });
    };

    /*
     * Workaround Chromium Bug:
     * Chromium scrollt, wenn Tastaturfokus in position:sticky-Element und CSS scroll-padding-top nicht 0 ist
     * https://bugs.chromium.org/p/chromium/issues/detail?id=1257719
     * https://bugs.chromium.org/p/chromium/issues/detail?id=1178622
     */
    const initStickyScrollFix = () => {
      if (initialized.stickyScrollFix) return;
      let currentPaddingMobile = document.documentElement.style.getPropertyValue('--ba-mobile-scroll-padding-top');
      let currentPaddingDesktop = document.documentElement.style.getPropertyValue('--ba-desktop-scroll-padding-top');

      document.addEventListener('keydown', (e) => {
        // prüfen, ob Focus auf Body oder in position:sticky-Element ist, falls ja, scroll-padding-top auf 0
        if (e.key === 'Tab' && e.target instanceof HTMLElement) { // NOSONAR
          if (document.activeElement.tagName === 'BODY' || document.activeElement.closest('.ba-header') || document.activeElement.closest('.ba-subheader') || e.target.closest('.ba-header') || e.target.closest('.ba-subheader')) { // NOSONAR
            currentPaddingMobile = document.documentElement.style.getPropertyValue('--ba-mobile-scroll-padding-top');
            currentPaddingDesktop = document.documentElement.style.getPropertyValue('--ba-desktop-scroll-padding-top');
            document.documentElement.style.setProperty('--ba-mobile-scroll-padding-top', '0');
            document.documentElement.style.setProperty('--ba-desktop-scroll-padding-top', '0');
          }
        }
      });
      document.addEventListener('keyup', (e) => {
        if (e.key === 'Tab') {
          document.documentElement.style.setProperty('--ba-mobile-scroll-padding-top', currentPaddingMobile);
          document.documentElement.style.setProperty('--ba-desktop-scroll-padding-top', currentPaddingDesktop);
        }
      });
      initialized.stickyScrollFix = true;
    };

    // einige Funktionen dürfen nur einmal initialisiert werden
    const initialized = {
      scrollToTop: false,
      stickyScrollFix: false,
      mouseKeyboardMode: false
    };

    (/** @type{any} */(window)).dpl.global = {
      init: function () {
        initScrollToTop();
        initMouseKeyboardMode();
        initModalA11y();
        initStickyScrollFix();
      }
    };

    // Globale Funktionen initialisieren
    document.addEventListener('DOMContentLoaded', () => {
      (/** @type{any} */(window)).dpl.global.init();
    });

    // Globale Methoden exportieren
    (/** @type{any} */(window)).dpl.Utilities = Utilities;
  }

  /**
   * DPL3-Patterns einrichten und initialisieren
   */
  static setupPatterns () {
    (/** @type{any} */(window)).dpl = (/** @type{any} */(window)).dpl || {};

    // Pattern: Tabbar
    (/** @type{any} */(window)).dpl.tabbar = {
      init: function (selector) {
        /* istanbul ignore next */
        if (!selector) selector = '.ba-tabbar:not([data-initialized])';
        const targets = document.querySelectorAll(selector);
        /* istanbul ignore next */
        if (targets && targets.length) {
          targets.forEach((target) => {
            target.baTabbar = new BaTabbar(target);
          });
        }
      }
    };

    // Pattern: Navbar
    (/** @type{any} */(window)).dpl.navbar = {
      init: function (selector) {
        /* istanbul ignore next */
        if (!selector) selector = '.ba-navbar:not([data-initialized])';
        const targets = document.querySelectorAll(selector);
        /* istanbul ignore next */
        if (targets && targets.length) {
          targets.forEach((target) => {
            target.baNavbar = new BaNavbar(target);
          });
        }
      }
    };

    // Pattern: Header
    (/** @type{any} */(window)).dpl.header = {
      init: function (selector) {
        /* istanbul ignore next */
        if (!selector) selector = '.ba-header:not([data-initialized])';
        const targets = document.querySelectorAll(selector);
        /* istanbul ignore next */
        if (targets && targets.length) {
          targets.forEach((target) => {
            target.baHeader = new BaHeader(target);
          });
        }
      }
    };

    // Pattern: Ausklappbarer Inhaltsbereich
    (/** @type{any} */(window)).dpl.collapse = {
      init: function (selector) {
        /* istanbul ignore next */
        if (!selector) selector = '[data-bs-toggle=collapse][data-label-collapsed][data-label-expanded]:not([data-initialized])';
        const targets = document.querySelectorAll(selector);
        /* istanbul ignore next */
        if (targets && targets.length) {
          targets.forEach((target) => {
            target.baCollapse = new BaCollapse(target);
          });
        }
      }
    };

    // Pattern: Kontaktinfobox
    (/** @type{any} */(window)).dpl.contactInfobox = {
      init: function (selector) {
        /* istanbul ignore next */
        if (!selector) selector = '.ba-contact-infobox:not([data-initialized])';
        const targets = document.querySelectorAll(selector);
        /* istanbul ignore next */
        if (targets && targets.length) {
          targets.forEach((target) => {
            target.baContactInfobox = new BaContactInfobox(target);
          });
        }
      }
    };

    // Pattern: Fortschrittsnavigation
    (/** @type{any} */(window)).dpl.progressNav = {
      init: function (selector) {
        /* istanbul ignore next */
        if (!selector) selector = '.ba-progress-nav:not([data-initialized])';
        const targets = document.querySelectorAll(selector);
        /* istanbul ignore next */
        if (targets && targets.length) {
          targets.forEach((target) => {
            target.baProgressNav = new BaProgressNav(target);
          });
        }
      }
    };

    // Pattern: Dropdown
    (/** @type{any} */(window)).dpl.dropdown = {
      init: function (selector) {
        /* istanbul ignore next */
        if (!selector) selector = '.dropdown:not(.ba-typeahead):not(.ba-dropdown-select):not([data-initialized])';
        const targets = document.querySelectorAll(selector);
        /* istanbul ignore next */
        if (targets && targets.length) {
          targets.forEach((target) => {
            target.baDropdown = new BaDropdown(target);
          });
        }
      }
    };

    // Pattern: Dropdown mit Auswahl-Ergebnis / Dropdown als Select
    (/** @type{any} */(window)).dpl.dropdownSelect = {
      init: function (selector) {
        /* istanbul ignore next */
        if (!selector) selector = '.ba-dropdown-select:not([data-initialized])';
        const targets = document.querySelectorAll(selector);
        /* istanbul ignore next */
        if (targets && targets.length) {
          targets.forEach((target) => {
            target.baDropdownSelect = new BaDropdownSelect(target);
          });
        }
      }
    };

    // Pattern: Tooltips/Popovers
    (/** @type{any} */(window)).dpl.popover = {
      init: function (selector) {
        /* istanbul ignore next */
        if (!selector) selector = '[data-bs-toggle=popover]:not([data-initialized])';
        const targets = document.querySelectorAll(selector);
        /* istanbul ignore next */
        if (targets && targets.length) {
          targets.forEach((target) => {
            target.baPopover = new BaPopover(target);
          });
        }
      }
    };

    // Pattern: Range Slider
    (/** @type{any} */(window)).dpl.rangeSlider = {
      init  : function (selector) {
        /* istanbul ignore next */
        if (!selector) selector = '.ba-range-slider:not([data-initialized])';
        const targets = document.querySelectorAll(selector);
        /* istanbul ignore next */
        if (targets && targets.length) {
          targets.forEach((target) => {
            target.baRangeSlider = new BaRangeSlider(target);
          });
        }
      },
      update: function (selector) {
        /* istanbul ignore next */
        if (!selector) selector = '.ba-range-slider[data-initialized]';
        const targets = document.querySelectorAll(selector);
        /* istanbul ignore next */
        if (targets && targets.length) {
          targets.forEach((target) => {
            target.baRangeSlider.update();
          });
        }
      }
    };

    // Pattern: Image Slider
    (/** @type{any} */(window)).dpl.imageSlider = {
      init: function (selector) {
        /* istanbul ignore next */
        if (!selector) selector = '.ba-slider:not([data-initialized])';
        const targets = document.querySelectorAll(selector);
        /* istanbul ignore next */
        if (targets && targets.length) {
          targets.forEach((target) => {
            target.baImageSlider = new BaSlider(target);
          });
        }
      },
    };

    // Pattern: SubHeader
    (/** @type{any} */(window)).dpl.subHeader = {
      init: function (selector) {
        /* istanbul ignore next */
        if (!selector) selector = '.ba-subheader:not([data-initialized])';
        const targets = document.querySelectorAll(selector);
        /* istanbul ignore next */
        if (targets && targets.length) {
          targets.forEach((target) => {
            target.baSubHeader = new BaSubHeader(target);
          });
        }
      },
    };

    // Pattern: Buttonzeile als Toolbar
    (/** @type{any} */(window)).dpl.toolbar = {
      init: function (selector) {
        if (!selector) selector = '.ba-btn-row[role="toolbar"]:not([data-initialized])';
        const targets = document.querySelectorAll(selector);
        /* istanbul ignore next */
        if (targets && targets.length) {
          targets.forEach((target) => {
            target.baToolbar = new BaToolbar(target);
          });
        }
      }
    };

    // Pattern: Typeahead / Autocomplete
    (/** @type{any} */(window)).dpl.typeahead = {
      init: function (selector) {
        if (!selector) selector = '.ba-typeahead:not([data-initialized])';
        const targets = document.querySelectorAll(selector);
        /* istanbul ignore next */
        if (targets && targets.length) {
          targets.forEach((target) => {
            target.baTypeahead = new BaTypeahead(target);
          });
        }
      }
    };

    // Pattern: Textarea input length
    (/** @type{any} */(window)).dpl.textareaCounter = {
      init: function (selector) {
        if (!selector) selector = 'textarea.ba-textarea-counter[maxlength]:not([data-initialized])';
        const targets = document.querySelectorAll(selector);
        /* istanbul ignore next */
        if (targets && targets.length) {
          targets.forEach((target) => {
            target.baTextareaCounter = new BaTextareaCounter(target);
          });
        }
      }
    };

    // alle Patterns initialisieren
    document.addEventListener('DOMContentLoaded', this.initPatterns);
  }

  /*
   * Alle noch nicht initialisierten Patterns können nach setupPatterns() initalisiert werden.
   * Die Methode wird standardmäßig nach DOMContentLoaded aufgerufen, in SPAs können so aber auch
   * nicht-initialisierte DPL-Patterns im DOM nachinitialisiert werden, alle Patterns mit dem Attribut
   * 'data-initialized' werden ignoriert.
   */
  static initPatterns () {
    (/** @type{any} */(window)).dpl.tabbar.init();
    (/** @type{any} */(window)).dpl.navbar.init();
    (/** @type{any} */(window)).dpl.header.init();
    (/** @type{any} */(window)).dpl.collapse.init();
    (/** @type{any} */(window)).dpl.contactInfobox.init();
    (/** @type{any} */(window)).dpl.progressNav.init();
    (/** @type{any} */(window)).dpl.dropdownSelect.init();
    (/** @type{any} */(window)).dpl.dropdown.init();
    (/** @type{any} */(window)).dpl.popover.init();
    (/** @type{any} */(window)).dpl.rangeSlider.init();
    (/** @type{any} */(window)).dpl.imageSlider.init();
    (/** @type{any} */(window)).dpl.subHeader.init();
    (/** @type{any} */(window)).dpl.toolbar.init();
    (/** @type{any} */(window)).dpl.typeahead.init();
    (/** @type{any} */(window)).dpl.textareaCounter.init();
  }
}

