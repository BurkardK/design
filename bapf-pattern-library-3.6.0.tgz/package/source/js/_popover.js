/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _popover.js */
import { Utilities } from './_utilities';

/**
 * Pattern: tooltip/popover / Interaktives Popover
 * Initialisiert Bootstrap-Popover und erweitert die Funktionalität
 * Optional kann man mit dem Attribute "data-bs-container" den Container für das Tooltip/Popover bestimmen.
 * @constructor
 * @param {HTMLElement} element - Popover Pattern, default: data-bs-toggle: "popover"
 */
export class BaPopover {

  constructor (element) {
    /* istanbul ignore next */
    if (element.hasAttribute('data-initialized')) return;

    this.domEl = element;
    this.ariaLabels = {
      closed  : this.domEl.getAttribute('aria-label') || 'Tooltip anzeigen',
      expanded: this.domEl.getAttribute('data-label-expanded') || 'Tooltip schließen'
    };
    this.init();
    this.domEl.setAttribute('data-initialized', 'true');
  }

  /**
   * Initialisiert das Popover
   */
  init () {
    const heading = this.domEl.hasAttribute('data-heading') ? this.domEl.getAttribute('data-heading') : 'h6';
    const trigger = this.domEl.hasAttribute('data-bs-trigger') ? this.domEl.getAttribute('data-bs-trigger') : 'click';
    const containerElement = this.domEl.parentElement.classList.contains('ba-tooltip-wrapper') ? this.domEl.parentElement : 'body';

    const options = {
      trigger           : trigger,
      html              : true,
      delay             : {
        'show': 0,
        'hide': 200
      },
      container         : this.domEl.hasAttribute('data-bs-container') ? this.domEl.getAttribute('data-bs-container') : containerElement,
      fallbackPlacements: ['top', 'bottom'],
      offset            : [0, 10],
      template          : `<div class="popover" role="tooltip"><div class="popover-arrow"></div><${heading} class="popover-header"></${heading}><div class="popover-body"></div></div>`
    };

    this.domEl.bsPopover = (/** @type{any} */(window)).dpl.bs.Popover.getInstance(this.domEl) || new (/** @type{any} */(window)).dpl.bs.Popover(this.domEl, options);
    this.initEvents();
  }

  /**
   * Erweitert mit Mouseover auf Popover-Item
   * Schließt das Popover-Item mit Mouseout
   * Schließt Popover auf Escape-Taste
   */
  initEvents () {
    const that = this;

    that.domEl.addEventListener('shown.bs.popover', function () {
      if (Utilities.isSafari()){
        that._setupClickOutsideListener(that);
      }
      let popoverELem = document.getElementById(that.domEl.getAttribute('aria-describedby'));
      if (document.activeElement.shadowRoot) {
        popoverELem = document.activeElement.shadowRoot.getElementById(that.domEl.getAttribute('aria-describedby'));
      }
      // für "hover" Trigger: Tooltip offen lassen bei mouseover, schließen bei mouseout: MouseEvents des Popovers an den Trigger weiterleiten
      /* istanbul ignore next */
      popoverELem.addEventListener('mouseover', () => {
        /* istanbul ignore next */
        that.domEl.dispatchEvent(new MouseEvent('mouseover'));
      });
      /* istanbul ignore next */
      popoverELem.addEventListener('mouseout', () => {
        /* istanbul ignore next */
        that.domEl.dispatchEvent(new MouseEvent('mouseout'));
      });
      // aria-label ändern
      that.setAriaLabel('expanded');
    });

    that.domEl.addEventListener('hidden.bs.popover', function () {
      // aria-label ändern
      that.setAriaLabel('closed');
    });

    // Schließt Popover auf Escape-Taste
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        that.domEl.bsPopover.hide();
      }
    });

    document.addEventListener('focusout', (e) => {
      const targetWrapperElem = e.target && /** @type{HTMLElement} */ (e.target).closest('.ba-tooltip-wrapper');
      const nextTargetWrapperElem = e.relatedTarget && /** @type{HTMLElement} */ (e.relatedTarget).closest('.ba-tooltip-wrapper');

      if (targetWrapperElem && targetWrapperElem !== nextTargetWrapperElem) {
        // Schließt Popover, wenn nächstes Focus-Element ist nicht in .ba-tooltip-wrapper
        that.setAriaLabel('closed');
        that.domEl.bsPopover.hide();
      } else {
        if (!targetWrapperElem) {
          const closestElem = e.relatedTarget && /** @type{HTMLElement} */ (e.relatedTarget).closest('.popover');

          // Schließt Popover auf focusout
          if (!closestElem) {
            that.setAriaLabel('closed');
            that.domEl.bsPopover.hide();
          }
        }
      }
    });
  }

  // Safari fix
  _setupClickOutsideListener(that) {
    document.addEventListener('click', function handler(e) {
      that._handleClickOutside(e);
      e.currentTarget.removeEventListener(e.type, handler);
    });
  }

  _handleClickOutside(e) {
    const clickedEl = e.target;
    if (
        clickedEl !== this.domEl &&
        !this.domEl.contains(clickedEl)
    ) {
      this.setAriaLabel('closed');
      this.domEl.bsPopover.hide();
    }
  }

  /**
   * Ändert aria-label
   * @param {string} status - mögliche Werte: expanded, closed
   */
  setAriaLabel (status) {
    this.domEl.getAttribute('aria-label') && this.domEl.setAttribute('aria-label', this.ariaLabels[status]);
  }
}
