###Javascript Sources

`_xxx.js`: Pattern-spezifische JS-Fragmente.

`app.js`: Initialisierung der Pattern-spezifischen JS.

`app-dev.js`: Initialisierung DPL-Demo / Patternlab

`demo/*`: Module für DPL-Demo und Pattern-Beispiele
