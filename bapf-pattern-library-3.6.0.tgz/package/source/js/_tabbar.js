/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _tabbar.js */
import { Utilities } from './_utilities';

/**
 * Pattern: Tabbar
 * Initialisiert Tabbar-Navigation
 * @constructor
 * @param {HTMLElement} element - TabBar Pattern, default: .ba-tabbar
 */
export class BaTabbar {

  constructor (element) {
    /* istanbul ignore next */
    if (element.hasAttribute('data-initialized')) return;

    this.scrollFactor = .5; // Anteil des sichtbarer Bereichs, der pro Klick gescrollt wird
    this.domEl = element;
    this.leftPos = 0;
    this.listWidth = 0;
    this.viewportWidth = 0;

    this.viewport = this.domEl.querySelector('.ba-viewport');
    this.marker = this.domEl.querySelector('.ba-viewport ul li.ba-marker');

    this.list = this.domEl.querySelector('ul');
    this.items = this.domEl.querySelectorAll('ul li:not(.ba-marker)');
    this.links = this.domEl.querySelectorAll('ul li a');
    this.controls = {
      prev: {
        el   : this.domEl.querySelector('.ba-prev'),
        title: this.domEl.getAttribute('data-title-prev') || 'zurück'
      },
      next: {
        el   : this.domEl.querySelector('.ba-next'),
        title: this.domEl.getAttribute('data-title-next') || 'weiter'
      }
    };

    this.initTabs();
    this.initVisibilityChange();
    this.initActions();
    this.initControls();
    this.initItemResizeObserver();
    this.initResize();
    this.initTouch();
    this.initTouchPad();

    this.domEl.setAttribute('data-initialized', 'true');
  }

  /**
   * Initialisiert die Tabbar, wenn sichtbar
   */
  initVisibilityChange () {
    try {
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.intersectionRatio > 0) {
            this.initUI();
          }
        });
      });
      observer.observe(this.domEl);
    }
    catch (e)
      /* istanbul ignore next */
    {
      this.initUI();
      console.log('IntersectionObserver nicht unterstützt, bitte Browser updaten.'); //NOSONAR
    }
  }

  /**
   * Elemente vermessen, Marker positionieren
   */
  initUI () {
    this.startMeasure();
    this.list.classList.add('active'); // Um die max. Größe eines Eintrags zu messen, müssen alle auf aktiv (bold) gestellt werden

    setTimeout(() => {
      this.items.forEach((item) => {
        item.removeAttribute('style');
        item.style.width = item.clientWidth + 'px';
      });

      this.listWidth = this.list.offsetWidth;
      this.list.classList.remove('active'); // Nach dem Messen wieder alle auf Normalzustand
      this.updateUI();

      const activeLink = this.list.querySelector('a.active');
      if (activeLink) {
        const activeListItem = activeLink.closest('li');
        this.setMarker(activeListItem);
      }
      this.endMeasure();
    }, 0);
  }

  /**
   * Aktionen und Handler initialisieren
   */
  initActions () {
    const tabbar = this;
    tabbar.links.forEach((link) => {

      // Marker unter Link bewegen
      link.addEventListener('mouseenter', (e) => {
        tabbar.marker.classList.add('hover');
        const targetElem = e.target;
        const targetListItem = targetElem.closest('li');
        tabbar.setMarker(targetListItem);
      }, false);

      // Marker unter aktiven Link zurückbewegen
      link.addEventListener('mouseleave', () => {
        tabbar.marker.classList.remove('hover');
        const activeLink = tabbar.list.querySelector('a.active');
        if (activeLink) {
          const activeListItem = activeLink.closest('li');
          tabbar.setMarker(activeListItem);
        } else {
          /* istanbul ignore next */
          Object.assign(tabbar.marker.style, {
            left : 0,
            width: 0
          });
        }
      }, false);

      // Gedrückt-Stil hinzufügen
      link.addEventListener('mousedown', () => {
        setTimeout(function () { // warten auf blur Event des vorherigen :focus
          tabbar.marker.classList.remove('hover');
        }, 10);
      });

      // Gedrückt-Stil ersetzen durch hover
      link.addEventListener('mouseup', () => {
        tabbar.marker.classList.add('hover');
      });

      // Link aktiv setzen und in Viewport schieben
      link.addEventListener('click', (e) => {
        /* istanbul ignore next */
        if (tabbar.domEl.classList.contains('ba-static-links')) {
          return true;
        }
        e.preventDefault();
        const activeElems = tabbar.domEl.querySelectorAll('.active');
        if (activeElems.length > 0) {
          activeElems.forEach(activeElem => activeElem.classList.remove('active'));
        }
        e.target.classList.add('active');
        tabbar.moveIntoViewport(e.target.closest('li'));
      });

      // Active-Marker updaten
      link.addEventListener('blur', function () {
        setTimeout(function () { // auf focus warten, document.activeElement geht zwischendurch auf <body>
          let focusedElement = document.activeElement;
          /* istanbul ignore next */
          if (document.activeElement.shadowRoot) {
            focusedElement = document.activeElement.shadowRoot.activeElement;
          }
          /* istanbul ignore next */
          if (!focusedElement.closest('.ba-tabbar') || focusedElement.closest('.ba-tabbar') !== tabbar.domEl) { // nicht mehr in Tabbar? Active-Marker resetten
            const activeLink = tabbar.list.querySelector('a.active');
            if (activeLink) {
              const activeListItem = activeLink.closest('li');
              tabbar.setMarker(activeListItem);
            }
          }
        }, 10);
      });

      // Navigation per Tastatur
      link.addEventListener('focus', () => {
        const entry = link.closest('li');
        tabbar.moveIntoViewport(entry);
        tabbar.setMarker(entry);
      });
    });
  }

  /**
   * Links/rechts Scrollbuttons initialisieren und aus Tab-Index entfernen
   */
  initControls () {
    const tabbar = this;
    const prevElem = this.controls.prev.el;
    prevElem.setAttribute('tabindex', '-1');
    prevElem.setAttribute('title', this.controls.prev.title);
    prevElem.addEventListener('click', () => {
      tabbar.slide('prev');
    });
    const nextElem = this.controls.next.el;
    nextElem.setAttribute('tabindex', '-1');
    nextElem.setAttribute('title', this.controls.next.title);
    nextElem.addEventListener('click', () => {
      tabbar.slide('next');
    });
  }

  /**
   * A11y: reagieren auf Größenänderungen durch interaktive User-Anpassungen (letter-spacing, font-size, ...)
   * Prüfschritt 1.4.12a Textabstände anpassbar (AA)
   */
  initItemResizeObserver () {
    try {
      const tabbar = this;
      const observer = new ResizeObserver((el) => {
        const elementWidth = el[0].contentRect.width;
        const containerWidth = el[0].target.closest('li').clientWidth;

        const isEnoughDifference = () => {
          const diff = containerWidth - elementWidth; // sollte ~32 sein (2x 16px Container-Padding)
          const BOLD_FACTOR = 0.015; // 0.015 ist der Faktor um den sich die Groesse durch bold verändert
          return diff < 32 || diff > 34 + elementWidth * BOLD_FACTOR;
        };

        if (elementWidth > 0 && isEnoughDifference()) {
          tabbar.initUI();
        }
      });
      // Nur das breiteste Item muss beobachtet werden
      let widestItem = null;
      let maxWidth = 0;
      this.startMeasure();
      tabbar.items.forEach((item) => {
        const itemWidth = item.offsetWidth;
        if (itemWidth > maxWidth) {
          maxWidth = itemWidth;
          widestItem = item;
        }
      });
      this.endMeasure();
      if (widestItem) observer.observe((/** @type{HTMLElement} */(widestItem)).querySelector('a'));
    } catch (e) {
      /* istanbul ignore next */
      console.log('ResizeObserver nicht unterstützt, bitte Browser updaten.'); //NOSONAR
    }
  }

  /**
   * Verwendung als Tabs initialisieren
   */
  initTabs () {
    if (this.list.getAttribute('role') === 'tablist') {
      const tabbar = this;

      // BS Tabverhalten aktivieren
      tabbar.links.forEach((triggerTab) => {
        if (triggerTab.getAttribute('role') === 'tab') {
          triggerTab.bsTab = (/** @type{any} */(window)).dpl.bs.Tab.getOrCreateInstance(triggerTab);
          triggerTab.addEventListener('keydown', () => {
            document.body.classList.add('ba-keyboard-mode');
          });
          triggerTab.addEventListener('click', (e) => {
            e.preventDefault();
            triggerTab.focus({ preventScroll: true });
            triggerTab.bsTab.show();
          });
        }
      });

      // Bewegen des Tastaturfokus per home/end-Tasten
      tabbar.domEl.addEventListener('keydown', (e) => {
        if (e.key === 'Home') {
          e.stopPropagation();
          e.preventDefault();
          const next = tabbar.items[0];
          next.querySelector('a').click();
        }
        if (e.key === 'End') {
          e.stopPropagation();
          e.preventDefault();
          const next = tabbar.items[tabbar.items.length - 1];
          next.querySelector('a').click();
        }
      });
    }
  }

  /**
   * Auf Größenänderungen und Orientationchange des Browsers reagieren
   */
  initResize () {
    const tabbar = this;
    let resizeTimeout = null;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(tabbar.updateUI.bind(tabbar), 100);
    });
  }

  /**
   * Touch-Steuerung für Mobile initialisieren
   */
  initTouch () {
    const tabbar = this;
    let startPos = 0;
    let startOffsetX = 0;

    // Touchdrag Handler
    tabbar.list.addEventListener('touchstart', (e) => {
      tabbar.domEl.classList.add('ba-noanim'); // Slide-Transition für touch-drag deaktivieren
      startPos = tabbar.leftPos;
      startOffsetX = e.changedTouches[0].pageX;
      window.addEventListener('touchmove', touchDragHandler);
      window.addEventListener('touchend', touchDragEnd);
    }, Utilities.supportsPassiveEvent() ? { passive: true } : false);

    // Handler während des Drag-Vorgangs
    function touchDragHandler (e) {
      e.stopPropagation();
      const newOffsetX = e.changedTouches[0].pageX;
      const distance = startOffsetX - newOffsetX;
      tabbar.leftPos = startPos - distance;
      tabbar.updateSlidePos();
    }

    // Handler nach dem Drag/Touch-Vorgang
    function touchDragEnd (e) {
      e.stopPropagation();
      tabbar.domEl.classList.remove('ba-noanim'); // Slide-Transition wieder aktivieren
      window.removeEventListener('touchmove', touchDragHandler);
      window.removeEventListener('touchend', touchDragEnd);
    }
  }

  /**
   * Touchpad-/MightyMouse-Steuerung initialisieren
   */
  initTouchPad () {
    const tabbar = this;
    const supportsPassive = Utilities.supportsPassiveEvent();
    tabbar.domEl.addEventListener('wheel', (e) => {
      if (tabbar.listWidth <= tabbar.viewportWidth) {
        return;
      }
      if (!supportsPassive) e.preventDefault();
      const delta = e.deltaX;
      if (delta < 0) {
        tabbar.slide('prev');
      }
      if (delta > 0) {
        tabbar.slide('next');
      }
    }, supportsPassive ? { passive: true } : false);
  }

  /**
   * Tabbar im sichtbaren Bereich verschieben: links, rechts oder Pixelposition
   * @param {string} direction - Mögliche Werte: 'prev', 'next'
   */
  slide (direction) {
    let newPos = this.leftPos;
    const distance = this.viewportWidth * this.scrollFactor;
    if (direction === 'prev') {
      newPos = this.leftPos + distance;
    }
    if (direction === 'next') {
      newPos = this.leftPos - distance;
    }
    this.leftPos = newPos;

    this.updateSlidePos();
  }

  /**
   * Ausrichtung, Overflow, Position und Buttonzustände aktualisieren
   * (initial, nach Resize, nach sichtbarmachen, ...)
   */
  updateUI () {
    const isHidden = Utilities.isHidden(this.domEl);

    /* istanbul ignore next */
    if (isHidden) {
      this.startMeasure();
    }

    this.domEl.classList.add('ba-noanim');
    this.updateOverflow();
    this.updateSlidePos();
    const activeElem = this.list.querySelector('.active');
    if (activeElem) {
      this.moveIntoViewport(activeElem.closest('li'));
    }
    this.domEl.classList.remove('ba-noanim');

    /* istanbul ignore next */
    if (isHidden) {
      this.endMeasure();
    }
  }

  /**
   * Testen, ob neue Slider-Position korrekt im Viewport liegt,
   * dann auf neue Position sliden und Controls aktualisieren
   */
  updateSlidePos () {
    if (this.leftPos > 0) { // Ganz links
      this.leftPos = 0;
    }
    if (this.leftPos < this.viewportWidth - this.listWidth) { // Ganz rechts
      if (this.viewportWidth >= this.listWidth) {
        this.leftPos = 0;
      } else {
        this.leftPos = this.viewportWidth - this.listWidth - 8; // 8px = padding-viewport + outline auf focus
      }
    }
    this.list.style.transform = `translate3d(${this.leftPos}px, 0, 0)`;
    this.updateControlStatus();
  }

  /**
   * Scrollbuttons je nach Scrollposition de/aktivieren
   */
  updateControlStatus () {
    if (this.leftPos >= 0) { // Ganz links
      this.domEl.classList.remove('ba-show-prev');
    } else {
      this.domEl.classList.add('ba-show-prev');
    }
    if (this.leftPos <= this.viewportWidth - this.listWidth) { // Ganz rechts
      this.domEl.classList.remove('ba-show-next');
    } else {
      this.domEl.classList.add('ba-show-next');
    }
  }

  /**
   * Prüfen, ob Tabbar größer ist als sichtbarer Bereich
   */
  updateOverflow () {
    let availableWidth;
    if (this.domEl.classList.contains('ba-overflown')) {
      availableWidth = Utilities.outerWidth(this.viewport);
    } else {
      availableWidth = this.viewport.offsetWidth + 1; //
    }
    this.listWidth > availableWidth ? this.domEl.classList.add('ba-overflown') : this.domEl.classList.remove('ba-overflown');
    this.viewportWidth = this.viewport.offsetWidth;
  }

  /**
   * Eintrag in den sichtbaren Bereich schieben
   * @param {HTMLElement} el - Tabbar-Item
   */
  moveIntoViewport (el) {
    if (!this.domEl.classList.contains('ba-overflown')) {
      return;
    }
    // Zusätzlicher Abstand damit der Focus-Rahmen komplett im View liegt
    const spacing = 40;
    const elLeft = el.offsetLeft;
    const elRight = elLeft + el.offsetWidth;
    /* istanbul ignore next */
    if (this.leftPos < -elLeft) {
      this.leftPos = -elLeft + spacing;
    }
    /* istanbul ignore next */
    if (this.leftPos - this.viewportWidth > -elRight) {
      this.leftPos = this.viewportWidth - elRight - spacing;
    }
    this.updateSlidePos();
  }

  /**
   * Größe und Position des hover-Markers setzen
   * @param {HTMLElement} el - Tabbar-Item, das markiert werden soll
   */
  setMarker (el) {
    const markerStyles = {
      left : el.offsetLeft + 'px',
      width: el.offsetWidth + 'px'
    };
    Object.assign(this.marker.style, markerStyles);
  }

  /**
   * Bevor Elemente vermessen werden können, muss die Tabbar sichtbar sein
   */
  startMeasure () {
    function getParentsHidden (elem, parentSelector) {
      if (parentSelector === undefined) {
        parentSelector = document.body;
      }
      const parents = [];
      let p = elem.parentNode;
      while (p && p !== parentSelector) {
        let o = p;
        /* istanbul ignore next */
        if (o.nodeName === '#document-fragment') {
          o = o.host;
        }
        /* istanbul ignore next */
        if (o.style.display === 'none' || window.getComputedStyle(o).display === 'none') {
          parents.push(o);
        }
        p = o.parentNode;
      }
      return parents;
    }

    const parentsHiddenElems = getParentsHidden(this.domEl);
    /* istanbul ignore next */
    parentsHiddenElems.forEach((elem) => {
      elem.classList.add('ba-unhide-for-measure');
    });
  }

  /**
   * Nach dem Vermessen kann Tabbar wieder unsichtbar werden, wenn sie es vorher war
   */
  endMeasure () {
    let parent = this.domEl.closest('.ba-unhide-for-measure');
    /* istanbul ignore next */
    while (parent !== null) {
      this.domEl.closest('.ba-unhide-for-measure').classList.remove('ba-unhide-for-measure');
      parent = parent.closest('.ba-unhide-for-measure');
    }
  }

  /**
   * Setzt den Tab mit tabId active
   * @param {string} tabId
   * @param {boolean} showPanel
   */
  setActive(tabId, showPanel = true) {
    const target = document.getElementById(tabId);
    if (showPanel) {
      target.click();
      return;
    }
    this.links.forEach(link => {
      link.classList.remove('active');
      link.setAttribute('aria-selected', 'false');
    });
    target.classList.add('active');
    target.setAttribute('aria-selected', 'true');
    const li = target.closest('li');
    this.setMarker(li);
    this.moveIntoViewport(li);
  }
}
