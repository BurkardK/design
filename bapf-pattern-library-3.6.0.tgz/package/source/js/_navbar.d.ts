/**
 * Pattern: Navbar
 * Initialisiert Navbar-Navigation
 * @constructor
 * @param {HTMLElement} element - NavBar Pattern, default: .ba-navbar
 */
export class BaNavbar {
    constructor(element: any);
    scrollFactor: number;
    domEl: any;
    leftPos: number;
    listWidth: number;
    viewportWidth: number;
    viewport: any;
    list: any;
    items: any;
    links: any;
    controls: {
        prev: {
            el: any;
            title: any;
        };
        next: {
            el: any;
            title: any;
        };
    };
    /**
     * Initialisiert die Navbar, wenn sichtbar
     */
    initVisibilityChange(): void;
    /**
     * Elemente vermessen, Marker positionieren
     */
    initUI(): void;
    /**
     * Aktionen und Handler initialisieren
     */
    initActions(): void;
    /**
     * Links/rechts Scrollbuttons initialisieren und aus Tab-Index entfernen
     */
    initControls(): void;
    /**
     * A11y: Reagiert auf Größenänderungen durch interaktive User-Anpassungen (letter-spacing, font-size, ...)
     * Prüfschritt 1.4.12a Textabstände anpassbar (AA)
     */
    initItemResizeObserver(): void;
    /**
     * Auf Größenänderungen und Orientationchange des Browsers reagieren
     */
    initResize(): void;
    /**
     * Touch-Steuerung für Mobile initialisieren
     */
    initTouch(): void;
    /**
     * Touchpad-/MightyMouse-Steuerung initialisieren
     */
    initTouchPad(): void;
    /**
     * Navbar im sichtbaren Bereich verschieben: links, rechts oder Pixelposition
     * @param {string} direction - Mögliche Werte: 'prev', 'next'
     */
    slide(direction: string): void;
    /**
     * Ausrichtung, Overflow, Position und Buttonzustände aktualisieren
     * (initial, nach Resize, nach sichtbarmachen, ...)
     */
    updateUI(): void;
    /**
     * Testen, ob neue Slider-Position korrekt im Viewport liegt,
     * dann auf neue Position sliden und Controls aktualisieren
     */
    updateSlidePos(): void;
    /**
     * Scrollbuttons je nach Scrollposition de/aktivieren
     */
    updateControlStatus(): void;
    /**
     * Prüfen, ob Navbar größer ist als sichtbarer Bereich
     */
    updateOverflow(): void;
    /**
     * Eintrag in den sichtbaren Bereich schieben
     * @param {HTMLElement} el - Navbar-Item
     */
    moveIntoViewport(el: HTMLElement): void;
    /**
     * Bevor Elemente vermessen werden können, muss die Navbar sichtbar sein
     */
    startMeasure(): void;
    /**
     * Nach dem Vermessen kann Navbar wieder unsichtbar werden, wenn sie es vorher war
     */
    endMeasure(): void;
}
