/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _rangeSlider.js */
/**
 * Pattern: Range Slider
 * Fügt Zusatzfrunktionen zu <input type="range"> hinzu
 * @constructor
 * @param {HTMLElement} element - Range slider Pattern, default: .ba-range-slider
 */
export class BaRangeSlider {

  constructor (element) {
    /* istanbul ignore next */
    if (element.hasAttribute('data-initialized')) return;

    this.domEl = element;
    // Safari unterstützt <option> zwar, sie sind aber nicht für CSS sichtbar
    this.optionsStyleable = function () {
      const options = element.querySelectorAll('option');
      return options.length > 0 && options[0].getBoundingClientRect().x !== 0;
    }();
    this.rangeSlider = this.domEl.querySelector('input[type=range]');
    this.thumbSize = 24;
    this.init();

    this.domEl.setAttribute('data-initialized', 'true');
  }

  /**
   * Initialsiert den Range Slider
   */
  init () {
    const rs = this.rangeSlider;

    // CSS Variablen für Chrome Progress-Färbung
    rs.style.setProperty('--min', rs.getAttribute('min'));
    rs.style.setProperty('--max', rs.getAttribute('max'));

    // Handler für Bereichsänderung
    rs.addEventListener('input', this.updateRangeSlider.bind(this));

    // Wenn es eine <datalist> gibt, deren Einträge nach Text durchsuchen und Lookup erstellen (Text dargestellt in Tooltip und aria-valuetext)
    this.generateTextByValueLookup();

    // Slider-Extras initialisieren
    this.update();
    this.initVisibilityChange();
    window.addEventListener('resize', this.update.bind(this));
  }

  /**
   * Aktualisiert den Range-Slider, wenn sichtbar ist
   */
  initVisibilityChange() {
    try {
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.intersectionRatio > 0) {
            this.update();
          }
        });
      });
      observer.observe(this.domEl);
    }
    catch (e) {
      /* istanbul ignore next */
      console.log('IntersectionObserver nicht unterstützt, bitte Browser updaten.'); //NOSONAR
    }
  }

  /**
   * Erstellt Lookup für Tooltip Text by Slider Value
   */
  generateTextByValueLookup () {
    const rs = this.rangeSlider;
    const datalist = rs.parentNode.querySelector('datalist');

    if (datalist) {
      rs.optionTextByValue = [];
      const options = datalist.children;
      for (const option of options) {
        if (option.text) {
          rs.optionTextByValue[option.value] = option.text;
        }
      }
    }
  }

  /**
   * Alles neu aufbauen nach resize
   */
  update () {
    this.updateRangeSlider();
    this.generateScale();
  }

  /**
   * CSS Variablen und aria-* auf eingestellten Wert setzen und Tooltip anzeigen
   */
  updateRangeSlider () {
    const rs = this.rangeSlider;
    const thumbSize = this.thumbSize;
    const offset = this.getValueOffset(rs.value);

    rs.style.setProperty('--val', rs.value); // für Chrome Progress

    // Wert oder, wenn vorhanden, Textwert als Tooltip ausgeben und als aria-valuetext setzen
    const outputText = rs.optionTextByValue && rs.optionTextByValue[rs.value] ? rs.optionTextByValue[rs.value] : rs.value;
    rs.setAttribute('aria-valuenow', rs.value);
    rs.setAttribute('aria-valuetext', outputText);

    // wenn Tooltip angezeigt werden soll: positionieren und Text ausgeben
    const output = rs.parentNode.querySelector('output');
    /* istanbul ignore next */
    if (!output || output.getAttribute('for') !== rs.id) {
      return;
    }

    output.value = outputText;
    output.style.setProperty('transform', 'translateX(' + offset + 'px) translateX(-50%)');

    // prüfen, ob Tooltip links oder rechts übersteht und entsprechend nachpositionieren
    const rsRect = rs.getBoundingClientRect();
    const oRect = output.getBoundingClientRect();
    if (oRect.left < rsRect.left) { // links
      output.style.setProperty('transform', 'translateX(' + (-thumbSize / 2) + 'px)');
    } else if (oRect.left + oRect.width > rsRect.left + rsRect.width) { // rechts
      output.style.setProperty('transform', 'translateX(' + (rsRect.width - oRect.width - thumbSize / 2 - 1) + 'px)');
    }
  }

  /**
   * Skala aus datalist erzeugen
   */
  generateScale () {
    const that = this;
    const rs = this.rangeSlider;
    const datalist = rs.parentNode.querySelector('datalist');

    if (!datalist) {
      return;
    }

    const thumbSize = this.thumbSize;
    const options = datalist.children;

    for (let i = 0; i < options.length; i++) {
      let option = options[i];
      const offset = this.getValueOffset(+option.getAttribute('value'));

      // Safari kennt <datalist> nicht und die darin enthaltenen <option>s sind daher nicht stylebar, deshalb werden sie dort ersetzt durch <span>
      option = this.prepareOption(option);

      option.classList.remove('fix-start', 'fix-end');
      option.style.setProperty('transform', 'translateX(' + offset + 'px)');
      option.addEventListener('click', function () {
        rs.value = this.getAttribute('value');
        that.updateRangeSlider();
      });

      // Prüfen, ob Label links oder rechts übersteht und entsprechend nachpositionieren
      const oWidth = parseFloat(window.getComputedStyle(option, ':after').getPropertyValue('width'));
      if (i === 0 && oWidth > thumbSize) {
        option.classList.add('fix-start');
      } else if (i === options.length - 1 && oWidth > thumbSize) {
        option.classList.add('fix-end');
      }
    }
  }

  /**
   * <option> für Safari in <span> transferieren
   * @param {HTMLElement} option
   * @returns {HTMLElement} Datalist
   */
  /* istanbul ignore next */
  prepareOption (option) {
    if (this.optionsStyleable || option.tagName === 'SPAN') {
      return option;
    }
    const oldOpt = option;
    const newOpt = document.createElement('span');
    const attributes = ['value', 'label', 'style'];
    attributes.forEach((attr) => {
      if (oldOpt.hasAttribute(attr)) {
        newOpt.setAttribute(attr, oldOpt.getAttribute(attr));
      }
    });
    newOpt.innerText = oldOpt.innerText;
    newOpt.classList.add('option');
    oldOpt.parentNode.replaceChild(newOpt, oldOpt);
    return newOpt;
  }

  /**
   * Offset eines Wertes im Bezug zum Regelbereich finden
   * @param {number} value - aktueller Wert
   * @return {number} Position des aktuellen Werts im Regelbereich
   */
  getValueOffset (value) {
    const rs = this.rangeSlider;
    const thumbSize = this.thumbSize;
    const range = rs.offsetWidth - thumbSize; // Regelbereich holen (Sliderbreite - Reglerbreite)
    const fraction = (value - rs.getAttribute('min')) / (rs.getAttribute('max') - rs.getAttribute('min')); // Verhältnis des aktuellen Werts zum Regelbereich
    return fraction * range; // Position des aktuellen Werts im Regelbereich
  }
}
