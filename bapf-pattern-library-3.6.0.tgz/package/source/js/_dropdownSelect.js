/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _dropdownSelect.js */
/**
 * Pattern: Dropdown-Select
 * erweitert Dropdown um Select-Funktion
 * @constructor
 * @param {HTMLElement} element - DropdownSelect Pattern, default: .ba-dropdown-select
 */
import {BaDropdown} from './_dropdown';

export class BaDropdownSelect extends BaDropdown{

  constructor (element) {
    super(element);

    this.domEl = element;
    this.init();
  }

  /**
   * Dropdwon-Helpers für Select-Funktion initialisieren
   */
  init () {
    // Auf Elemente anwenden
    this.applyJsOnDropdown(this.domEl);

    // Click Handler
    const dropdownHandler = (target) => {
      const parentNode = target;
      const dropdownParent = parentNode.closest('.ba-dropdown-select');

      if (target.classList.contains('disabled')) {
        return false;
      }

      const activeNodes = this.domEl.querySelectorAll('.active');

      if ( this.domEl === dropdownParent ) {
        activeNodes.forEach((node) => {
          node.classList.remove('active');
        });
      }

      parentNode.classList.add('active');
      this.updateStates(dropdownParent);
      dropdownParent.querySelector('.dropdown-toggle').focus();

      // Trigger change Event
      const event = document.createEvent('HTMLEvents');
      event.initEvent('change', true, false);
    };

    document.addEventListener('click', function (e) {
      // Geht die Elternelemente durch
      for (let target = e.target; target && target !== this; target = (/** @type{HTMLElement} */(target)).parentNode) {
        if ((/** @type{HTMLElement} */(target)).matches('.ba-dropdown-select ul.dropdown-menu li')) {
          e.preventDefault();
          dropdownHandler(target);
          break;
        }
        /* istanbul ignore next */
        if ((/** @type{HTMLElement} */(target)).matches('.ba-dropdown-select ul.dropdown-menu li.disabled')) {
          return false;
        }
      }
    }, { capture: false });

    /* istanbul ignore next */
    document.addEventListener('mousedown', function (e) {
      // Geht die Elternelemente durch
      for (let target = e.target; target && target !== this; target = (/** @type{HTMLElement} */(target)).parentNode) {
        if ((/** @type{HTMLElement} */(target)).matches('.ba-dropdown-select ul.dropdown-menu li.disabled')) {
          return false;
        }
      }
    }, { capture: false });

  }

  /**
   * Vervollständigt das Dropdown mit allen Events
   * @param {HTMLElement} dropdown ziel Dropdown
   */
  applyJsOnDropdown (dropdown) {
    if (this.isNoActive(dropdown)) {
      dropdown.querySelector('li').classList.add('active');
    }
    this.updateStates(dropdown);
  }

  /**
   * Aktualisiert mögliche States bei Dropdown, abhängig von aktivem Selection
   * @param {HTMLElement} dropdown ziel Dropdown
   */
  updateStates (dropdown) {
    const option = this.getActiveAnchor(dropdown);

    const closestTag = option.closest('li');
    const text = option.textContent;
    const value = closestTag.classList.contains('disabled') ? '' : option.getAttribute('data-value') || text;

    const inputElem = /** @type {HTMLInputElement} */(dropdown.querySelector('.ba-selected-value'));
    const selectedDisplay = dropdown.querySelector('.ba-selected-text');

    // Value & sichtbaren Text setzen
    if (inputElem) inputElem.value = value;
    if (selectedDisplay) selectedDisplay.textContent = text;

    // Titel des Dropdowns, für Braille-Viewer
    const dropdownTitle = dropdown.getAttribute('data-default-aria-label');

    // Setzt das Aria-label für die Liste und den Button
    dropdown.querySelector('ul').setAttribute('aria-label', dropdownTitle);
    dropdown.querySelector('button').setAttribute('aria-label', dropdownTitle + ' ' + text.replace(/---/g, ''));

    // Listen-links (<a>) aria-labels setzen
    option.setAttribute('aria-label', text.replace(/---/g, '') + ' aktuelle Auswahl');
    const parentOptionElem = option.parentNode;
    Array.prototype.filter.call(parentOptionElem.parentNode.children, function (child) {
      if (child !== parentOptionElem) {
        child.querySelector('a').setAttribute('aria-label', child.textContent);
      }
    });

    dropdown.dispatchEvent(new Event('change'));
  }

  /**
   * Gibt aktives <a> Element zurück
   * @param {HTMLElement} dropdown dropdown select element
   * @return {HTMLElement} selected a element
   */
  getActiveAnchor (dropdown) {
    return dropdown.querySelector('ul.dropdown-menu li.active > a');
  }

  /**
   * Prüft, ob kein aktiver Eintrag vorhanden ist
   * @param {HTMLElement} dropdown ziel Dropdown
   * @return {boolean} true wenn dropdown keine aktive selection hat
   */
  isNoActive (dropdown) {
    if (!this.getActiveAnchor(dropdown)) {
      return true;
    }
  }
}
