/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _rangeSlider.js */
/**
 * Pattern: Range Slider
 * Fügt Zusatzfrunktionen zu <input type="range"> hinzu
 * @constructor
 * @param {HTMLElement} element - Range slider Pattern, default: .ba-range-slider
 */
export class BaRangeSlider {
    constructor(element: any);
    domEl: any;
    optionsStyleable: boolean;
    rangeSlider: any;
    thumbSize: number;
    /**
     * Initialsiert den Range Slider
     */
    init(): void;
    /**
     * Aktualisiert den Range-Slider, wenn sichtbar ist
     */
    initVisibilityChange(): void;
    /**
     * Erstellt Lookup für Tooltip Text by Slider Value
     */
    generateTextByValueLookup(): void;
    /**
     * Alles neu aufbauen nach resize
     */
    update(): void;
    /**
     * CSS Variablen und aria-* auf eingestellten Wert setzen und Tooltip anzeigen
     */
    updateRangeSlider(): void;
    /**
     * Skala aus datalist erzeugen
     */
    generateScale(): void;
    /**
     * <option> für Safari in <span> transferieren
     * @param {HTMLElement} option
     * @returns {HTMLElement} Datalist
     */
    prepareOption(option: HTMLElement): HTMLElement;
    /**
     * Offset eines Wertes im Bezug zum Regelbereich finden
     * @param {number} value - aktueller Wert
     * @return {number} Position des aktuellen Werts im Regelbereich
     */
    getValueOffset(value: number): number;
}
