/**
 * Pattern: Scroll-To-Top Button
 * @constructor
 * @param {HTMLElement} element - Button
 */
export class BaScrollToTop {
    constructor(element: any);
    domEl: any;
    /**
     * Initialisiert den Scroll-To-Top Button
     */
    init(): void;
    /**
     * Versteckt oder zeigt scrollToTop Button abhängig von scroll Position
     * @param {HTMLElement} $scrollBtn Scroll-to-top button
     */
    updateScrollBtn($scrollBtn: HTMLElement): void;
}
