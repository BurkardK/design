/**
 * Pattern: Slider
 * @constructor
 * @param {HTMLElement} element - Slider Pattern, default: .ba-slider
 */
export class BaSlider {
    constructor(element: any);
    domEl: any;
    track: HTMLElement;
    slides: NodeListOf<HTMLElement>;
    prevText: any;
    nextText: any;
    currentText: any;
    indexText: any;
    currentMarker: HTMLSpanElement;
    prev: HTMLButtonElement;
    next: HTMLButtonElement;
    liveRegion: HTMLDivElement;
    dots: HTMLElement;
    current: number;
    left: string;
    max: number;
    /**
     * Liveregion für Screenreader hinzufügen
     */
    addLiveRegion(): void;
    /**
     * 'zurück' und 'weiter' - Controls hinzufügen
     */
    addPrevNext(): void;
    /**
     * Navigationspunkte hinzufügen
     */
    addDots(): void;
    /**
     * Positioniert Prev/Next-Buttons und Dots
     */
    positionPrevNextDots(): void;
    /**
     * Dots und Buttons neu positionieren nach Resize
     */
    resizeSlider(): void;
    /**
     * Einzelnes Bild sliden (zurück / vorwärts / index)
     * @param {String|Number} direction 'prev' | 'next' | index
     * @param {Boolean} noAnim Animation ausschalten, Slide sofort umschalten
     * @param {Boolean} setSrText Aktualisiert aria-live mit dem aktuellen Bildunterschrift
     */
    slide(direction: string | number, noAnim?: boolean, setSrText?: boolean, createAriaLive?: boolean): void;
    /**
     * Steuerung mit Pfeiltasten
     */
    initArrowKeys(): void;
    /**
     * Steuerung mit Touch Swipe
     */
    initTouch(): void;
    /**
     * Focus-Handler für Live-Region updates
     */
    initLiveRegion(): void;
    /**
     * Auf Änderung der Sichtbarkeit reagieren - Button- und Dots-Positionen lassen sich nur setzen, wenn Slider sichtbar ist
     */
    initVisibilityChange(): void;
    /**
     * Ersetzt den Text in der Live-Region mit newText
     * @param {string} newText
     */
    setLiveRegionText(newText: string): void;
}
