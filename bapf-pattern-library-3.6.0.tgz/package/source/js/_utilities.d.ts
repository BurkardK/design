/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _utilities.js */
export class Utilities {
    /**
     * Berechnet die Breite des Elements über den Margin
     * @param {HTMLElement} el
     * @return {number} Breite über Margin
     */
    static outerWidth(el: HTMLElement): number;
    /**
     * Überprüft ob das Element versteckt ist oder sich in einem versteckten Container befindet
     * @param {HTMLElement} el
     * @return {boolean}
     */
    static isHidden(el: HTMLElement): boolean;
    /**
     * Erstellt ein DOM-Element, setzt optionale Attribute und Text
     * @param {string} nodeName example 'div'
     * @param {object | undefined} attrsList Beispiel: {'class': 'class1 class2', 'type': 'button'}
     * @param {string | undefined} text
     * @return {HTMLElement}
     */
    static createElem(nodeName: string, attrsList: object | undefined, text: string | undefined): HTMLElement;
    /**
     * Gibt alle fokusierbaren Elemente zurück
     * @param {HTMLElement} element Root Element
     * @return {Array}
     */
    static getFocusableElements(element: HTMLElement): any[];
    /**
     * Get first focusable element
     * Gibt das erste fokusierbare Element zurück
     * @param {HTMLElement} element Root Element
     * @return {HTMLElement}
     */
    static getFirstFocusable(element: HTMLElement): HTMLElement;
    /**
     * Gibt das BA Header DOM-Element aus der WebComponent ShadowDOM (hydriert oder nicht) oder aus dem statischen DOM zurück
     * @return {Promise<any>}
     */
    static getHeader(): Promise<any>;
    /**
     * Gibt das initialisierte Pattern zurück
     * @param {HTMLElement} element Pattern-Element
     * @return {Promise<any>}
     */
    static getInitializedPattern(element: HTMLElement): Promise<any>;
    /**
     * Überprüfe ob der Browser passive Event Listener unterstützt
     * @returns {boolean}
     */
    static supportsPassiveEvent(): boolean;
    /**
     * Füge eine Navigation über Pfeiltasten/Tab hinzu (beispielsweise für Toolbars)
     * @param {HTMLElement} container Toolbar Root-Element
     * @param {NodeListOf<HTMLElement>} items Toolbar Button-Elemente
     */
    static addArrowKeyNavigation(container: HTMLElement, items: NodeListOf<HTMLElement>): void;
    /**
     * Überprüft ob ein Element innerhalb des sichtbaren Bereichs liegt
     * @param {HTMLElement} element
     * @return {boolean}
     */
    static isInViewport(element: HTMLElement): boolean;
    /**
     * Überprüft, ob aktueller Browser Safari ist (iOS, MacOS)
     * @returns {boolean}
     */
    static isSafari(): boolean;
}
