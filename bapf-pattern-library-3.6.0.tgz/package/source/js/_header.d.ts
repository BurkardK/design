/**
 * Pattern: Header
 * Initialisiert die Header-Funktionen
 * @constructor
 * @param {HTMLElement} element - Header Element, default: .ba-header
 */
export class BaHeader {
    constructor(element: any);
    domEl: any;
    /**
     * Initialisiert Bootstrap-Methoden für Menus und Dropdown
     */
    initBootstrap(): void;
    /**
     * Toggle Menu auf Klick
     * @param {HTMLElement} collapseElement
     * @param {HTMLElement} parentElem
     */
    toggleOnClick(collapseElement: HTMLElement, parentElem: HTMLElement): void;
    /**
     * Setzt Höhe und Style des Headers abhängig von Scroll-Position
     */
    initScrollHeader(): void;
    /**
     * Initialisiert Events für Header
     * Events: click, keydown, resize, hide.bs.collapse, shown.bs.collapse
     */
    initListeners(): void;
    /**
     * Update Flyout-Höhe beim Ausklappen.
     * Wenn Flyout größer ist als Viewport, muss im Flyout gescrollt werden, dazu muss max-height korrekt gesetzt werden
     */
    updateMenuHeight(): void;
    /**
     * Alle offenen Flyout-Menus und Collapsibles schließen
     */
    closeFlyouts(): void;
}
