/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _navbar.js */
import { Utilities } from './_utilities';

/**
 * Pattern: Navbar
 * Initialisiert Navbar-Navigation
 * @constructor
 * @param {HTMLElement} element - NavBar Pattern, default: .ba-navbar
 */
export class BaNavbar {

  constructor (element) {
    /* istanbul ignore next */
    if (element.hasAttribute('data-initialized')) return;

    this.scrollFactor = .5; // Anteil des sichtbarer Bereichs, der pro Klick gescrollt wird
    this.domEl = element;
    this.leftPos = 0;
    this.listWidth = 0;
    this.viewportWidth = 0;

    this.viewport = this.domEl.querySelector('.ba-viewport');

    this.list = this.domEl.querySelector('ul');
    this.items = this.domEl.querySelectorAll('ul li');
    this.links = this.domEl.querySelectorAll('ul li a');
    this.controls = {
      prev: {
        el   : this.domEl.querySelector('.ba-prev'),
        title: this.domEl.getAttribute('data-title-prev') || 'zurück'
      },
      next: {
        el   : this.domEl.querySelector('.ba-next'),
        title: this.domEl.getAttribute('data-title-next') || 'weiter'
      }
    };

    this.initVisibilityChange();
    this.initActions();
    this.initControls();
    this.initItemResizeObserver();
    this.initResize();
    this.initTouch();
    this.initTouchPad();

    this.domEl.setAttribute('data-initialized', 'true');
  }

  /**
   * Initialisiert die Navbar, wenn sichtbar
   */
  initVisibilityChange () {
    try {
      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.intersectionRatio > 0) {
            this.initUI();
          }
        });
      });
      observer.observe(this.domEl);
    } catch (e) {
      this.initUI();
      console.log('IntersectionObserver nicht unterstützt, bitte Browser updaten.'); //NOSONAR
    }
  }

  /**
   * Elemente vermessen, Marker positionieren
   */
  initUI () {
    this.startMeasure();
    this.list.classList.add('active'); // Um die max. Größe eines Eintrags zu messen, müssen alle auf aktiv (bold) gestellt werden

    setTimeout(() => {
      this.items.forEach((item) => {
        item.removeAttribute('style');
        item.style.width = item.clientWidth + 'px';
      });

      this.listWidth = this.list.offsetWidth;
      this.list.classList.remove('active'); // Nach dem Messen wieder alle auf Normalzustand
      this.updateUI();

      this.endMeasure();
    }, 0);
  }

  /**
   * Aktionen und Handler initialisieren
   */
  initActions () {
    const navbar = this;
    this.links.forEach((link) => {

      // Link aktiv setzen und in Viewport schieben
      link.addEventListener('click', (e) => {
        const activeTitle = '(aktuelle Auswahl)';
        const activeElem = navbar.domEl.querySelector('.active');
        if (activeElem) {
          const currentTitle = activeElem.getAttribute('title') || '';
          activeElem.setAttribute('title', currentTitle.replace(activeTitle, '').trim());
          activeElem.classList.remove('active');
        }
        e.target.setAttribute('title', e.target.getAttribute('title') ? e.target.getAttribute('title') + ' ' + activeTitle : activeTitle);
        e.target.classList.add('active');

        navbar.moveIntoViewport(e.target.closest('li'));
      });

      // Standard-Verhalten ScrollIntoView verhindern
      function doOnFocus (e) {
        e.preventDefault();
        navbar.viewport.scrollLeft = 0; // Verhindert automatisches Browser focus() scrollIntoView()
      }

      link.addEventListener('focus', doOnFocus);
      link.addEventListener('focusin', doOnFocus);

      // Navigation per Tastatur: focus == mouseenter
      link.addEventListener('focus', () => {
        const entry = link.closest('li');
        navbar.moveIntoViewport(entry);
      });
    });
  }

  /**
   * Links/rechts Scrollbuttons initialisieren und aus Tab-Index entfernen
   */
  initControls () {
    const navbar = this;
    const prevElem = this.controls.prev.el;
    prevElem.setAttribute('tabindex', '-1');
    prevElem.setAttribute('title', this.controls.prev.title);
    prevElem.setAttribute('aria-label', this.controls.prev.title);
    prevElem.addEventListener('click', () => {
      navbar.slide('prev');
    });
    const nextElem = this.controls.next.el;
    nextElem.setAttribute('tabindex', '-1');
    nextElem.setAttribute('title', this.controls.next.title);
    nextElem.setAttribute('aria-label', this.controls.next.title);
    nextElem.addEventListener('click', () => {
      navbar.slide('next');
    });
  }

  /**
   * A11y: Reagiert auf Größenänderungen durch interaktive User-Anpassungen (letter-spacing, font-size, ...)
   * Prüfschritt 1.4.12a Textabstände anpassbar (AA)
   */
  initItemResizeObserver () {
    try {
      const navbar = this;
      const observer = new ResizeObserver((el) => {
        const elementWidth = el[0].contentRect.width;
        const containerWidth = el[0].target.closest('li').clientWidth;
        let iconPadding = 0;

        if (el[0].target.classList.contains('ba-icon')) {
          iconPadding = 24;
        }

        const isEnoughDifference = () => {
          const BOLD_FACTOR = 0.015; // 0.015 ist der Faktor um den sich die Groesse durch bold verändert
          const diff = containerWidth - (elementWidth + iconPadding); // Sollte ~24 sein (2x 12px Container-Padding) ohne Icon und ~48 (36px & 12px Container-Padding)
          return diff < 22 || diff > 26 + elementWidth * BOLD_FACTOR;
        };

        if (elementWidth > 0 && isEnoughDifference()) {
          navbar.initUI();
        }
      });
      // Nur das breiteste Item muss beobachtet werden
      let widestItem = null;
      let maxWidth = 0;
      this.startMeasure();
      navbar.items.forEach((item) => {
        const itemWidth = item.offsetWidth;
        if (itemWidth > maxWidth) {
          maxWidth = itemWidth;
          widestItem = item;
        }
      });
      this.endMeasure();
      if (widestItem) observer.observe((/** @type{HTMLElement} */(widestItem)).querySelector('a'));
    } catch (e) {
      console.log('ResizeObserver nicht unterstützt, bitte Browser updaten.'); //NOSONAR
    }
  }

  /**
   * Auf Größenänderungen und Orientationchange des Browsers reagieren
   */
  initResize () {
    const navbar = this;
    let resizeTimeout = null;
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(navbar.updateUI.bind(navbar), 100);
    });
  }

  /**
   * Touch-Steuerung für Mobile initialisieren
   */
  initTouch () {
    const navbar = this;
    let startPos = 0;
    let startOffsetX = 0;

    // Touchdrag Handler
    navbar.list.addEventListener('touchstart', (e) => {
      navbar.domEl.classList.add('ba-noanim'); // Slide-Transition für touch-drag deaktivieren
      startPos = navbar.leftPos;
      startOffsetX = e.changedTouches[0].pageX;
      window.addEventListener('touchmove', touchDragHandler);
      window.addEventListener('touchend', touchDragEnd);
    }, Utilities.supportsPassiveEvent() ? { passive: true } : false);

    // Handler für während des Drag-Vorgangs
    function touchDragHandler (e) {
      e.stopPropagation();
      const newOffsetX = e.changedTouches[0].pageX;
      const distance = startOffsetX - newOffsetX;
      navbar.leftPos = startPos - distance;
      navbar.updateSlidePos();
    }

    // Handler für nach dem Drag-Vorgang
    function touchDragEnd (e) {
      e.stopPropagation();
      navbar.domEl.classList.remove('ba-noanim'); // Slide-Transition wieder aktivieren
      window.removeEventListener('touchmove', touchDragHandler);
      window.removeEventListener('touchend', touchDragEnd);
    }
  }

  /**
   * Touchpad-/MightyMouse-Steuerung initialisieren
   */
  initTouchPad () {
    const navbar = this;
    const supportsPassive = Utilities.supportsPassiveEvent();
    navbar.domEl.addEventListener('wheel', (e) => {
      if (navbar.listWidth <= navbar.viewportWidth) {
        return;
      }
      if (!supportsPassive) e.preventDefault();
      const delta = e.deltaX;
      if (delta < 0) {
        navbar.slide('prev');
      }
      if (delta > 0) {
        navbar.slide('next');
      }
    }, supportsPassive ? { passive: true } : false);
  }

  /**
   * Navbar im sichtbaren Bereich verschieben: links, rechts oder Pixelposition
   * @param {string} direction - Mögliche Werte: 'prev', 'next'
   */
  slide (direction) {
    let newPos = this.leftPos;
    const distance = this.viewportWidth * this.scrollFactor;
    if (direction === 'prev') {
      newPos = this.leftPos + distance;
    }
    if (direction === 'next') {
      newPos = this.leftPos - distance;
    }
    this.leftPos = newPos;

    this.updateSlidePos();
  }

  /**
   * Ausrichtung, Overflow, Position und Buttonzustände aktualisieren
   * (initial, nach Resize, nach sichtbarmachen, ...)
   */
  updateUI () {
    const isHidden = Utilities.isHidden(this.domEl);

    if (isHidden) {
      this.startMeasure();
    }

    this.domEl.classList.add('ba-noanim');
    this.updateOverflow();
    this.updateSlidePos();
    const activeElem = this.list.querySelector('.active');
    if (activeElem) {
      this.moveIntoViewport(activeElem.closest('li'));
    }
    this.domEl.classList.remove('ba-noanim');

    if (isHidden) {
      this.endMeasure();
    }
  }

  /**
   * Testen, ob neue Slider-Position korrekt im Viewport liegt,
   * dann auf neue Position sliden und Controls aktualisieren
   */
  updateSlidePos () {
    if (this.leftPos > 0) { // Ganz links
      this.leftPos = 0;
    }
    if (this.leftPos < this.viewportWidth - this.listWidth) { // Ganz rechts
      if (this.viewportWidth >= this.listWidth) {
        this.leftPos = 0;
      } else {
        this.leftPos = this.viewportWidth - this.listWidth;
      }
    }
    this.list.style.transform = `translate3d(${this.leftPos}px, 0, 0)`;
    this.updateControlStatus();
  }

  /**
   * Scrollbuttons je nach Scrollposition de/aktivieren
   */
  updateControlStatus () {
    if (this.leftPos >= 0) { // Ganz links
      this.domEl.classList.remove('ba-show-prev');
    } else {
      this.domEl.classList.add('ba-show-prev');
    }
    if (this.leftPos <= this.viewportWidth - this.listWidth) { // Ganz rechts
      this.domEl.classList.remove('ba-show-next');
    } else {
      this.domEl.classList.add('ba-show-next');
    }
  }

  /**
   * Prüfen, ob Navbar größer ist als sichtbarer Bereich
   */
  updateOverflow () {
    let availableWidth;
    if (this.domEl.classList.contains('ba-overflown')) {
      availableWidth = Utilities.outerWidth(this.viewport);
    } else {
      availableWidth = this.viewport.offsetWidth + 1; //
    }
    this.listWidth > availableWidth ? this.domEl.classList.add('ba-overflown') : this.domEl.classList.remove('ba-overflown');
    this.viewportWidth = this.viewport.offsetWidth;
  }

  /**
   * Eintrag in den sichtbaren Bereich schieben
   * @param {HTMLElement} el - Navbar-Item
   */
  moveIntoViewport (el) {
    if (!this.domEl.classList.contains('ba-overflown')) {
      return;
    }
    // Zusätzlicher Abstand damit der Focus-Rahmen komplett im View liegt
    const spacing = 6;
    const elLeft = el.offsetLeft;
    const elRight = elLeft + el.offsetWidth;
    if (this.leftPos < -elLeft) {
      this.leftPos = -elLeft + spacing;
    }
    if (this.leftPos - this.viewportWidth > -elRight) {
      this.leftPos = this.viewportWidth - elRight - spacing;
    }
    this.updateSlidePos();
  }

  /**
   * Bevor Elemente vermessen werden können, muss die Navbar sichtbar sein
   */
  startMeasure () {
    function getParentsHidden (elem, parentSelector) {
      if (parentSelector === undefined) {
        parentSelector = document.body;
      }
      const parents = [];
      let p = elem.parentNode;
      while (p && p !== parentSelector) {
        let o = p;
        if (o.nodeName === '#document-fragment') {
          o = o.host;
        }
        if (o.style.display === 'none' || window.getComputedStyle(o).display === 'none') {
          parents.push(o);
        }
        p = o.parentNode;
      }
      return parents;
    }

    const parentsHiddenElems = getParentsHidden(this.domEl);
    parentsHiddenElems.forEach((elem) => {
      elem.classList.add('ba-unhide-for-measure');
    });
  }

  /**
   * Nach dem Vermessen kann Navbar wieder unsichtbar werden, wenn sie es vorher war
   */
  endMeasure () {
    let parent = this.domEl.closest('.ba-unhide-for-measure');
    while (parent !== null) {
      this.domEl.closest('.ba-unhide-for-measure').classList.remove('ba-unhide-for-measure');
      parent = parent.closest('.ba-unhide-for-measure');
    }
  }
}
