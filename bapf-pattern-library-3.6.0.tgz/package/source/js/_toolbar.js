/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _toolbar.js */
import { Utilities } from './_utilities';

/**
 * Pattern: Toolbar
 * Initialisiert Toolbar-Navigation
 * @constructor
 * @param {HTMLElement} element - Toolbar, default: [role="toolbar"]
 */
export class BaToolbar {
  constructor (element) {
    /* istanbul ignore next */
    if (element.hasAttribute('data-initialized')) return;

    Utilities.addArrowKeyNavigation(element, element.querySelectorAll('.ba-btn'));
    element.setAttribute('data-initialized', 'true');
  }
}
