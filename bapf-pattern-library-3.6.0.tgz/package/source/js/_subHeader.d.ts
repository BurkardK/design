/**
 * Pattern: SubHeader
 * Initialisiert die SubHeader-Funktionen
 * @constructor
 * @param {HTMLElement} element - SubHeader Element, default: .ba-subheader
 */
export class BaSubHeader {
    constructor(element: any);
    domEl: any;
    hasLogo: boolean;
    scrollHandler: any;
    resizeHandler: any;
    resizeTO: number;
    observers: {
        headerClass: any;
        subHeaderCompact: any;
        subHeaderFull: any;
    };
    headerHeight: {
        compact: number;
        full: number;
    };
    scrollPaddingTop: {
        headerOnly: string;
        subheaderSmall: string;
        subheaderLarge: string;
    };
    /**
     * Sucht den Header als WebComponent oder im DOM und initialisiert dann den SubHeader
     */
    init(): Promise<void>;
    header: any;
    /**
     * Observer installieren zur Überwachung von:
     * - Sichtbarkeit Header mobile: wenn Header sichtbar ist, muss SubHeader entsprechend nach unten verschoben werden
     * - Position SubHeader mobile: wenn SubHeader sticky ist, muss Logo ausgeblendet werden
     * - Position SubHeader desktop: wenn SubHeader an Header stößt, wird dieser mit nach oben verschoben, bis SubHeader sticky ist
     */
    initObservers(): void;
    /**
     * Resize/Orientationchange-Handler
     */
    handleResize(): void;
    /**
     * Handler für Y-Positionsänderung SubHeader Compact
     * @param {number} intersectionRatio - SubHeader Überschneidungsrate Header
     */
    handleIntersectionCompact(intersectionRatio: number): void;
    /**
     * Handler für Y-Positionsänderung SubHeader Full
     * @param {boolean} isIntersecting - SubHeader überschneidet Header
     */
    handleIntersectionFull(isIntersecting: boolean): void;
    /**
     * Interaktionen Header <-> SubHeader während Überschneidung
     */
    handleHeaderInteractions(): void;
    /**
     * Schatten des Headers ein/ausschalten, wenn SubHeader darunter/am Header ist
     * @param {boolean} show - Schatten an/aus
     */
    toggleHeaderShadow(show: boolean): void;
    /**
     * Der Header ist compact, wenn die position auf 'fixed' gesetzt ist
     * @return {Boolean}
     */
    isCompactHeader(): boolean;
    /**
     * Alle offenen Flyout-Menus und Collapsibles im Header schließen
     */
    closeFlyouts(): void;
    /**
     * Abstand nach oben setzen für Scrollposition Seitenanker
     */
    setScrollPaddingTop(): void;
    /**
     * Disconnect Observers
     */
    disconnect(): void;
}
