/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _collapse.js */
/**
 * Pattern: collapsible / Ausklappbarer Inhaltsbereich
 * erweitert BS Collapse um A11y-Helfer
 * @constructor
 * @param {HTMLElement} element - Collapse Pattern, default: .ba-collapsible
 */
export class BaCollapse {

  constructor (element) {
    /* istanbul ignore next */
    if (element.hasAttribute('data-initialized')) return;

    this.domEl = element;
    this.init();

    this.domEl.setAttribute('data-initialized', 'true');
  }

  /**
   * A11y-Helfer für Collapse initialisieren
   * Eventlistener erstellen (funktioniert auch für dynamische Elemente)
   */
  init () {
    this.domEl.addEventListener('click', (e) => {
      this.updateAriaLabel(e.target);
    }, { capture: false });
  }

  /**
   * Aria-Label aktualisieren
   * ergänzt aria-label im jeweiligen Zustand (eingeklappt und ausgeklappt)
   * @param {HTMLElement} target - e.target auf Klick
   */
  updateAriaLabel (target) {
    const triggerElement = target.closest('[data-bs-toggle=collapse]');
    const ariaLabelExpanded = `${triggerElement.getAttribute('data-label-expanded')}`;
    const ariaLabelCollapsed = `${triggerElement.getAttribute('data-label-collapsed')}`;

    triggerElement.removeAttribute('aria-expanded');
    if (triggerElement.getAttribute('aria-label') === ariaLabelExpanded) {
      triggerElement.setAttribute('aria-label', ariaLabelCollapsed);
    } else {
      triggerElement.setAttribute('aria-label', ariaLabelExpanded);
    }
  }
}
