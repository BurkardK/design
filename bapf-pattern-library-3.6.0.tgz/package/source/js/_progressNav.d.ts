/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | _progressNav.js */
/**
 * Pattern: Fortschritts-Navigation vertikal/horizontal
 * Initialisiert mobile Interaktion für Navigationseinträge
 * @constructor
 * @param {HTMLElement} element - Progress-Nav Pattern, default: .ba-progress-nav
 */
export class BaProgressNav {
    constructor(element: any);
    domEl: any;
    /**
     * Auf- und zuklappen der progress nav mobile
     */
    init(): void;
}
