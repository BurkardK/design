/**
 * Pattern: tooltip/popover / Interaktives Popover
 * Initialisiert Bootstrap-Popover und erweitert die Funktionalität
 * Optional kann man mit dem Attribute "data-bs-container" den Container für das Tooltip/Popover bestimmen.
 * @constructor
 * @param {HTMLElement} element - Popover Pattern, default: data-bs-toggle: "popover"
 */
export class BaPopover {
    constructor(element: any);
    domEl: any;
    ariaLabels: {
        closed: any;
        expanded: any;
    };
    /**
     * Initialisiert das Popover
     */
    init(): void;
    /**
     * Erweitert mit Mouseover auf Popover-Item
     * Schließt das Popover-Item mit Mouseout
     * Schließt Popover auf Escape-Taste
     */
    initEvents(): void;
    _setupClickOutsideListener(that: any): void;
    _handleClickOutside(e: any): void;
    /**
     * Ändert aria-label
     * @param {string} status - mögliche Werte: expanded, closed
     */
    setAriaLabel(status: string): void;
}
