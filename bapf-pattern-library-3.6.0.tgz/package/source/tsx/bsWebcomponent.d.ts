/**
 * Polyfill zur Wiederherstellung von Bootstrap-Funktionalitäten in WebComponents
 * Verwendung mit Stencil siehe https://confluence.webapp.sdst.sbaintern.de/display/REDD/Webcomponents
 */
/**
 * Erweitert die Funktionalität der DPL3 in WebComponents
 * mit Bootstrap-Eigenschaften (z.b aria-expanded)
 * @param {HTMLElement} elem, beliebiges Parent-Element
 */
export declare class BsWebcomponent {
    private elem;
    private parentElem?;
    constructor(elem: any, parentElem?: any);
    reinitCollapse(elem: any, options: any): void;
    initEventCollapse(): void;
}
