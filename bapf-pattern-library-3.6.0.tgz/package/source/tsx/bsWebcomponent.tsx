/*! @design/bapf-pattern-library v3.6.0 | 11.04.2024 | bsWebcomponent.tsx */
/**
 * Polyfill zur Wiederherstellung von Bootstrap-Funktionalitäten in WebComponents
 * Verwendung mit Stencil siehe https://confluence.webapp.sdst.sbaintern.de/display/REDD/Webcomponents
 */

interface ICollapseOptions {
  toggle: boolean,
  parent?: HTMLElement
}

interface IWindow {
  dpl?: {
    global: {
      init: () => Object;
    };
    tabbar: { init: (selector?) => Object };
    header: { init: (selector?) => Object };
    collapse: { init: (selector?) => Object };
    bs: {
      Alert,
      Collapse,
      Dropdown,
      Modal,
      Popover,
      Tab
    };
  };
}

/**
 * Erweitert die Funktionalität der DPL3 in WebComponents
 * mit Bootstrap-Eigenschaften (z.b aria-expanded)
 * @param {HTMLElement} elem, beliebiges Parent-Element
 */
export class BsWebcomponent {
  private elem: HTMLElement;
  private readonly parentElem?: HTMLElement;

  constructor(elem, parentElem = null) {
    this.elem = elem;
    this.parentElem = parentElem;
    this.initEventCollapse();
    this.initModals();
  }

  // initialisiert Bootstrap-Collapse, wenn es noch keine Instanz gibt
  reinitCollapse(elem, options) {
    if (!elem.hasOwnProperty('bsCollapse')) {
      elem.bsCollapse = (window as unknown as IWindow).dpl.bs.Collapse.getInstance(elem) || new (window as unknown as IWindow).dpl.bs.Collapse(elem, options);
      const triggerEl = this.elem.querySelector(`[data-bs-target="#${elem.getAttribute('id')}"]`);
      triggerEl.addEventListener('click', () => {
        elem.bsCollapse.toggle();
      });
    }
  }

  // Fügt Eventlistener für Collapse um Bootstrap-Collapse nachzubilden
  // Steuert CSS-Klasse collapsed
  // Steuert aria-expnaded Attribute
  initEventCollapse() {
    if (!this.elem.querySelector('.collapse')) {
      return;
    }

    // wenn keinte Instanz vorhanden dann instanzieren
    this.elem.querySelectorAll('.collapse').forEach((collapse: HTMLElement) => {
      if ((window as unknown as IWindow).dpl.bs.Collapse.getInstance(collapse)) {
        return;
      }

      let options: ICollapseOptions = {
        toggle: false
      };

      // init Flyout
      if (!collapse.classList.contains('ba-flyout-collapse')) {
        // init flyout collapsibles
        const flyoutEl: HTMLElement = collapse.closest('.ba-flyout-collapse.collapse');
        if (flyoutEl) options.parent = flyoutEl
        if (this.parentElem) options.parent = this.parentElem;
      }

      this.reinitCollapse(collapse, options);
    })

    const that = this;

    // Eventlistener
    this.elem.addEventListener('show.bs.collapse', function (e) {
      if (!(e.target as HTMLElement).classList.contains('collapse')) {
        return;
      }

      const button = that.elem.querySelector(`[data-bs-target="#${(e.target as HTMLElement).getAttribute('id')}"]`);
      button.setAttribute('aria-expanded', 'true');
      button.classList.remove('collapsed');
    });
    that.elem.addEventListener('hide.bs.collapse', function (e) {
      if (!(e.target as HTMLElement).classList.contains('collapse')) {
        return;
      }

      const button = that.elem.querySelector(`[data-bs-target="#${(e.target as HTMLElement).getAttribute('id')}"]`);
      button.setAttribute('aria-expanded', 'false');
      button.classList.add('collapsed');
    });
  }

  initModals() {
    const modalElemts = this.elem.querySelectorAll('.modal');

    modalElemts.forEach(modalElem => {
      let parent, modal;

      // Vor öffnen eines BS-Modals: modal und parent merken
      modalElem.addEventListener('show.bs.modal', (e) => {
        parent = (e.target as HTMLElement).parentElement;
        modal = e.target;
      });

      // Nach öffnen: modal wieder an sein parent anhängen (=zurück in's Shadow-DOM holen)
      modalElem.addEventListener('shown.bs.modal', () => {
        parent.append(modal);
      });

      // Nach öffnen eines BS-Modals: erstes fokussierbares Element im Modal fokussieren
      if (!modalElem.hasAttribute('data-prevent-autofocus')) {
        modalElem.addEventListener('shown.bs.modal', (e) => {
          this.getFirstFocusable(e.target as HTMLElement).focus();
        });
      }

      const that = this;
      modalElem.addEventListener('keydown', (e: KeyboardEvent) => {
        that.preventFocusOutOfModal(e, modalElem);
      });
    });
  }

  // Modal kann per Tab-Taste nicht mehr verlassen werden (Focus-Falle)
  preventFocusOutOfModal(event, modal) {
    if (!event.shiftKey && event.key === 'Tab') {
      const focusables = this.getFocusableElements(modal);
      if (focusables[focusables.length - 1] === event.target) {
        event.preventDefault();
        focusables[0].focus();
      }
    }
  }

  getFirstFocusable(element) {
    const focusables = this.getFocusableElements(element);
    return focusables.length ? focusables[0] : element;
  }

  getFocusableElements(element) {
    const arrFocusables = [];
    element.querySelectorAll('a[href], button, input:not([type=hidden]), textarea, select, details, [tabindex]:not([tabindex="-1"])').forEach((elem) => arrFocusables.push(elem));
    return arrFocusables.filter(el => !el.hasAttribute('disabled') && !el.getAttribute('aria-hidden'));
  }
}
